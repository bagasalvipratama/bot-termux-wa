﻿/*KASIH NAMA AUTOR NYA LAH ANJENG

KALAU MAU RECODE KASIH NAMA GUA YE

KALAU MAU BELI FITUR PREMIUM CHAT GUA AJA YE
wa.me/6285717337679
*/




const
{
   WAConnection,
   MessageType,
   Presence,                                                                         
      MessageOptions,
   Mimetype,
   WALocationMessage,                                                                     
 WA_MESSAGE_STUB_TYPES,
   ReconnectMode,
   ProxyAgent,
   GroupSettingChange,
   waChatKey,
   mentionedJid,
   processTime,
} = require("@adiwajshing/baileys")
const qrcode = require("qrcode-terminal")
const moment = require("moment-timezone")
const fs = require("fs")
const ms = require('parse-ms')
const toMs = require('ms')
const { color, bgcolor } = require('./lib/color')
const { help } = require('./lib/help')
const { donasi } = require('./lib/donasi')
const { fetchJson } = require('./lib/fetcher')
const { recognize } = require('./lib/ocr')
const { wait, simih, getBuffer, uploadImages, kepo, generateMessageID, getGroupAdmins, getRandom, banner, start, info, success, close } = require('./lib/functions')
const tiktod = require('tiktok-scraper')
const axios = require("axios")
const emojiUnicode = require('emoji-unicode')
const ffmpeg = require('fluent-ffmpeg')
const imageToBase64 = require('image-to-base64');
const base64ToImage = require('base64-to-image');
var base64Img = require('base64-img');
const { removeBackgroundFromImageFile } = require('remove.bg')
const fetch = require('node-fetch')
const kasar = JSON.parse(fs.readFileSync('./src/antibadword.json'))
const _ban = JSON.parse(fs.readFileSync('./src/banned.json'))                       
//const Math_js = require('mathjs')
const speed = require('performance-now')
//const speedTest = require('@lh2020/speedtest-net');
const { Utils_1 } = require('./node_modules/@adiwajshing/baileys/lib/WAConnection/Utils')
const time = moment().tz('Asia/Jakarta').format("HH:mm:ss")
const _registered = JSON.parse(fs.readFileSync('./database/bot/registered.json'))
const welkom = JSON.parse(fs.readFileSync('./database/json/welkom.json'))
const nsfw = JSON.parse(fs.readFileSync('./database/bot/nsfw.json'))
const setiker = JSON.parse(fs.readFileSync('./src/stik.json'))
const videonye = JSON.parse(fs.readFileSync('./src/video.json'))
const audionye = JSON.parse(fs.readFileSync('./src/audio.json'))
const imagenye = JSON.parse(fs.readFileSync('./src/image.json'))
const samih = JSON.parse(fs.readFileSync('./database/bot/simi.json'))
const antilink = JSON.parse(fs.readFileSync('./src/antilink.json'))
const bad = JSON.parse(fs.readFileSync('./database/group/bad.json'))
const _afk = JSON.parse(fs.readFileSync('./src/afk.json'))
const badword = JSON.parse(fs.readFileSync('./database/group/badword.json'))
const _limit = JSON.parse(fs.readFileSync('./database/json/limit.json'))
const user = JSON.parse(fs.readFileSync('./database/json/user.json'))
const { ind } = require('./language')
const date = moment.tz('Asia/Jakarta').format('DD/MM/YY')
const uang = JSON.parse(fs.readFileSync('./database/user/uang.json'))
const {
	listzodiak,
	aries,
	taurus,
	gemini,
	cancer,
	Leo,
	Virgo,
	Libra,
	Scorpio,
	Sagittarius,
	Capricorn,
	Aquarius,
	Pisces
} = require('./src/listzodiak')

const vcard = 'BEGIN:VCARD\n' 
            + 'VERSION:3.0\n' 
            + 'FN:Bagas\n' 
            + 'ORG: Pengembang Bot;\n' 
            + 'TEL;type=CELL;type=VOICE;waid=6285717337679:+62 857-1733-7679\n' 
            + 'END:VCARD' 

prefix = '#'
fake = '_*Verifed-ByWhatsApp*_'
numbernye = '0'
targetprivate = '0'
blocked = []
memberlimit = 5
limitawal = 100
banChats = false
monospace = '```'
waktuafk = `${time}`
const arrayBulan = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 
'September', 'Oktober', 'November', 'Desember']

const bulan = arrayBulan[moment().format('MM') - 1]

function kyun(seconds){
  function pad(s){
    return (s < 10 ? '0' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var seconds = Math.floor(seconds % 60);                                                            
  //return pad(hours) + ':' + pad(minutes) + ':' + pad(seconds)                                  
   return `${pad(hours)}Jam ${pad(minutes)}Menit ${pad(seconds)}Detik`
}
function clamp(value, min, max) {
        return Math.min(Math.max(min, value), max)
}                                                                                                    
function speedText(speed) {
    let bits = speed * 8;
    const units = ['', 'K', 'M', 'G', 'T'];
    const places = [0, 1, 2, 3, 3];
    let unit = 0;
    while (bits >= 2000 && unit < 4) {
      unit++;                                                                             
      bits /= 1000;                                                                                      }

    return `${bits.toFixed(places[unit])} ${units[unit]}bps`;
}

const { exec } = require("child_process")

const client = new WAConnection()

client.on('qr', qr => {
   qrcode.generate(qr, { small: true })
   console.log(`[ ${time} ] QR code is ready`)
})

client.on('credentials-updated', () => {
   const authInfo = client.base64EncodedAuthInfo()
   console.log(`credentials updated!`)

   fs.writeFileSync('./novia.json', JSON.stringify(authInfo, null, '\t'))
})

fs.existsSync('./novia.json') && client.loadAuthInfo('./novia.json')

client.connect();

client.on('group-participants-update', async (anu) => {
		if (!welkom.includes(anu.jid)) return
		try {
			const mdata = await client.groupMetadata(anu.jid)
			console.log(anu)
			if (anu.action == 'add') {
				num = anu.participants[0]
				try {
					ppimg = await client.getProfilePicture(`${anu.participants[0].split('@')[0]}@c.us`)
				} catch {
					ppimg = 'https://i.ibb.co/XSQfPhN/ab73026ecbdc.jpg'
				}
				teks = `[ NEW MEMBER IN GROUP ${mdata.subject} ]

------------
@${num.split('@')[0]}
_*INTRO*_
Nama :
Umur :
Askot :
Selamat bergabung semoga betah
------------

_By Bot R_`
				let buff = await getBuffer(ppimg)
				client.sendMessage(mdata.id, buff, MessageType.image, {caption: teks, contextInfo: {"mentionedJid": [num]}})
			} else if (anu.action == 'remove') {
				num = anu.participants[0]
				try {
					ppimg = await client.getProfilePicture(`${num.split('@')[0]}@c.us`)
				} catch {
					ppimg = 'https://i.ibb.co/XSQfPhN/ab73026ecbdc.jpg'
				}
				teks = `Sayonara @${num.split('@')[0]}`
				let buff = await getBuffer(ppimg)
				client.sendMessage(mdata.id, buff, MessageType.image, {caption: teks, contextInfo: {"mentionedJid": [num]}})
			}
		} catch (e) {
			console.log('Error : %s', color(e, 'red'))
		}
	})
	client.on('CB:Blocklist', json => {
		if (blocked.length > 2) return
	    for (let i of json[1].blocklist) {
	    	blocked.push(i.replace('c.us','s.whatsapp.net'))
	    }
	})
client.on('message-new', async (mek) => {
        try {
                const txt = mek.message.conversation
                if (!mek.message) return
                if (mek.key && mek.key.remoteJid == 'status@broadcast') return
                let infoMSG = JSON.parse(fs.readFileSync('./src/dat/msg.data.json'))
                infoMSG.push(JSON.parse(JSON.stringify(mek)))
                fs.writeFileSync('./src/dat/msg.data.json', JSON.stringify(infoMSG, null, 2))
                const urutan_pesan = infoMSG.length
                if (urutan_pesan > 5000) {
                        infoMSG.splice(0, 5000)
                        fs.writeFileSync('./src/dat/msg.data.json', JSON.stringify(infoMSG, null, 2))
                }
                global.prefix
                global.blocked
                const content = JSON.stringify(mek.message)
                const from = mek.key.remoteJid
                const type = Object.keys(mek.message)[0]
                const barbarkey = 'YOUR-APIKEY'
                const naufalkey = 'YOUR-APIKEY'
                const zekskey = 'YOUR-APIKEY'
                const vhtearkey = 'YOUR-APIKEY'
                const { text, extendedText, contact, location, liveLocation, image, video, sticker, document, audio, product } = MessageType
                const time = moment.tz('Asia/Jakarta').format('HH:mm:ss')
                body = (type === 'conversation' && mek.message.conversation.startsWith(prefix)) ? mek.message.conversation : (type == 'imageMessage') && mek.message.imageMessage.caption.startsWith(prefix) ? mek.message.imageMessage.caption : (type == 'videoMessage') && mek.message.videoMessage.caption.startsWith(prefix) ? mek.message.videoMessage.caption : (type == 'extendedTextMessage') && mek.message.extendedTextMessage.text.startsWith(prefix) ? mek.message.extendedTextMessage.text : ''
                budy = (type === 'conversation') ? mek.message.conversation : (type === 'extendedTextMessage') ? mek.message.extendedTextMessage.text : ''
                const command = body.slice(1).trim().split(/ +/).shift().toLowerCase()
                const args = body.trim().split(/ +/).slice(1)
                const isCmd = body.startsWith(prefix)
                const createSerial = require('./src/serial')
                const q = args.join(' ')
                

                const botNumber = client.user.jid
                const ownerNumber = ["6285717337679@s.whatsapp.net"] // ganti nomer lu
                const isGroup = from.endsWith('@g.us')
                const sender = isGroup ? mek.participant : mek.key.remoteJid
                pushname = client.contacts[sender] != undefined ? client.contacts[sender].vname || client.contacts[sender].notify : undefined
                const groupMetadata = isGroup ? await client.groupMetadata(from) : ''
                const groupName = isGroup ? groupMetadata.subject : ''
                const groupId = isGroup ? groupMetadata.jid : ''
                const groupMembers = isGroup ? groupMetadata.participants : ''
                const groupDesc = isGroup ? groupMetadata.desc : ''
                const groupOwner = isGroup ? groupMetadata.owner : ''
                const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''
                //const isRegistered = register.checkRegisteredUser(sender, _registered)
                const isUser = user.includes(sender)
                const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
                const isGroupAdmins = groupAdmins.includes(sender) || false
                const isAntiLink = isGroup ? antilink.includes(from) : false
                const isKasar = isGroup ? kasar.includes(from) : false
                const isWelkom = isGroup ? welkom.includes(from) : false
                const isNsfw = isGroup ? nsfw.includes(from) : false
                const isSimi = isGroup ? samih.includes(from) : false
                //const isPrem = _premium.includes(sender)
                const isOwner = ownerNumber.includes(sender)
                const isBanned = _ban.includes(sender)
                const gm = args.join(' ')
                client.chatRead(from)
        const chats = type == 'conversation' || type == 'extendedTextMessage'
                const isUrl = (url) => {
                        return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%.+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%+.~#?&/=]*)/, 'gi'))
                }
                const reply = (teks) => {
                        client.sendMessage(from, teks, text, { quoted: mek })
                }
                const sendMess = (hehe, teks) => {
                        client.sendMessage(hehe, teks, text)
                }
                //mentioned = mek.message.mentionedJid
                const mentions = (teks, memberr, id) => {
                        (id == null || id == undefined || id == false) ? client.sendMessage(from, teks.trim(), extendedText, { contextInfo: {"mentionedJid": memberr } }) : client.sendMessage(from, teks.trim(), extendedText, { quoted: mek, contextInfo: { "mentionedJid": memberr } })
                }
                const sendPtt = (teks) => {
                          client.sendMessage(from, audio, mp3, {quoted: mek})
        }
        
        mess = {
				wait: '⌛ Sedang di Prosess ⌛',
				success: '✔️ Berhasil ✔️',
				error: {
					stick: '[❗] Gagal, terjadi kesalahan saat mengkonversi gambar ke sticker ❌',
					Iv: '❌ Link tidak valid ❌'
				},
				only: {
					group: '[❗] Perintah ini hanya bisa di gunakan dalam group! ❌',
					ownerG: '[❗] Perintah ini hanya bisa di gunakan oleh owner group! ❌',
					ownerB: '[❗] Perintah ini hanya bisa di gunakan oleh owner bot! ❌',
					admin: '[❗] Perintah ini hanya bisa di gunakan oleh admin group! ❌',
					//premium: `Premium user only bruh...\nMau jadi user premium?\nChat wa.me/6285717337679`,
					Badmin: '[❗] Perintah ini hanya bisa di gunakan ketika bot menjadi admin! ❌',
                                        daftarB: `Kamu belum terdaftar di database!\n\nSilahkan mendaftar dengan format:\n${prefix}daftar nama | umur`,
				}
			}
        
        const addATM = (sender) => {
        	const obj = {id: sender, uang : 0}
            uang.push(obj)
            fs.writeFileSync('./database/user/uang.json', JSON.stringify(uang))
        }
        
        const addKoinUser = (sender, amount) => {
            let position = false
            Object.keys(uang).forEach((i) => {
                if (uang[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                uang[position].uang += amount
                fs.writeFileSync('./database/user/uang.json', JSON.stringify(uang))
            }
        }
        
        const checkATMuser = (sender) => {
        	let position = false
            Object.keys(uang).forEach((i) => {
                if (uang[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                return uang[position].uang
            }
        }
        
        const bayarLimit = (sender, amount) => {
        	let position = false
            Object.keys(_limit).forEach((i) => {
                if (_limit[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                _limit[position].limit -= amount
                fs.writeFileSync('./database/json/limit.json', JSON.stringify(_limit))
            }
        }
        	
        const confirmATM = (sender, amount) => {
        	let position = false
            Object.keys(uang).forEach((i) => {
                if (uang[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                uang[position].uang -= amount
                fs.writeFileSync('./database/user/uang.json', JSON.stringify(uang))
            }
        }
        
         const limitAdd = (sender) => {
             let position = false
            Object.keys(_limit).forEach((i) => {
                if (_limit[i].id == sender) {
                    position = i
                }
            })
            if (position !== false) {
                _limit[position].limit += 1
                fs.writeFileSync('./database/json/limit.json', JSON.stringify(_limit))
            }
        }     
        
        const sleep = async (ms) => {
    return new Promise(resolve => setTimeout(resolve, ms));
}

          //function check limit
          const checkLimit = (sender) => {
          	let found = false
                    for (let lmt of _limit) {
                        if (lmt.id === sender) {
                            let limitCounts = limitawal - lmt.limit
                            if (limitCounts <= 0) return client.sendMessage(from,`Limit request anda sudah habis\n\n_Note : limit bisa di dapatkan dengan cara ${prefix}buylimit_`, text,{ quoted: mek})
                            client.sendMessage(from, ind.limitcount(limitCounts), text, { quoted : mek})
                            found = true
                        }
                    }
                    if (found === false) {
                        let obj = { id: sender, limit: 0 }
                        _limit.push(obj)
                        fs.writeFileSync('./database/json/limit.json', JSON.stringify(_limit))
                        client.sendMessage(from, ind.limitcount(limitCounts), text, { quoted : mek})
                    }
				}
				
			//funtion limited
           const isLimit = (sender) => {
		      let position = false
              for (let i of _limit) {
              if (i.id === sender) {
              	let limits = i.limit
              if (limits >= limitawal ) {
              	  position = true
                    client.sendMessage(from, ind.limitend(pushname), text, {quoted: mek})
                    return true
              } else {
              	_limit
                  position = true
                  return false
               }
             }
           }
           if (position === false) {
           	const obj = { id: sender, limit: 1 }
                _limit.push(obj)
                fs.writeFileSync('./database/json/limit.json',JSON.stringify(_limit))
           return false
       }
     }
           
            /*if (isGroup) {
				try {
					const getmemex = groupMembers.length
					    if (getmemex <= memberlimit) {
                            client.groupLeave(from)
					    }
		       } catch (err) { console.error(err)  }
        }*/
        
        
        if (txt.includes("://chat.whatsapp.com/")) {
                if (!isGroup) return
                if (!isAntiLink) return
                if (isGroupAdmins) return reply('Kamu admin grup jadi ngga di kick :)')
                client.updatePresence(from, Presence.composing)
                var kic = `${sender.split("@")[0]}@s.whatsapp.net`
                reply(`*「 ANTI GROUP LINK 」*\n\nKamu mengirim link group chat!\nMaaf tapi kami harus mengeluarkan mu...\nSelamat tinggal~`)
                client.groupRemove(from, [kic]).catch((e)=>{reply(`ERR:* ${e}`)})
                }
                                

const h2k = (number) => {
    var SI_POSTFIXES = ["", " K", " M", " G", " T", " P", " E"]
    var tier = Math.log10(Math.abs(number)) / 3 | 0
    if(tier == 0) return number
    var postfix = SI_POSTFIXES[tier]
    var scale = Math.pow(10, tier * 3)
    var scaled = number / scale
    var formatted = scaled.toFixed(1) + ''
    if (/\.0$/.test(formatted))
      formatted = formatted.substr(0, formatted.length - 2)
    return formatted + postfix
} 
      
            //function balance
            if (isUser && !isBanned) {
            const checkATM = checkATMuser(sender)
            try {
                if (checkATM === undefined) addATM(sender)
                const uangsaku = Math.floor(Math.random() * 10) + 60
                addKoinUser(sender, uangsaku)
            } catch (err) {
                console.error(err)
            }
        }

                colors = ['red', 'white', 'black', 'blue', 'yellow', 'green']
                const isMedia = (type === 'imageMessage' || type === 'videoMessage')
                const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
                const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
                const isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')
                const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')

            //Ignore ban user
                if (isBanned && !isGroup && !isCmd) console.log(color('[BAN]', 'red'), time, color('Message'), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
                if (!isCmd && isBanned && isGroup) console.log(color('[BAN]', 'red'), time, color('Message'), 'from', color(sender.split('@')[0]), 'in', color(groupName), 'args :', color(args.length))

                //Message & Using
                if (!isGroup && isCmd) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mEXEC\x1b[1;37m]', time, color(command), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
                if (!isGroup && !isCmd) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mRECV\x1b[1;37m]', time, color('Message'), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
                if (isCmd && isGroup) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mEXEC\x1b[1;37m]', time, color(command), 'from', color(sender.split('@')[0]), 'in', color(groupName), 'args :', color(args.length))
                if (!isCmd && isGroup) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mRECV\x1b[1;37m]', time, color('Message'), 'from', color(sender.split('@')[0]), 'in', color(groupName), 'args :', color(args.length))
                if (isOwner && mek.key.fromMe) console.log(color('Owner lewat', 'cyan'))

                //Anti virus function
                if (isGroup && !mek.key.fromMe && isKasar && isBotGroupAdmins) {
                    if (txt.length > 5000) {
                                 client.sendMessage(from, `「 *PETUGAS PEMBERSIH* 」\n\nKamu nakal si! Ngapain kirim virus? \nMaaf tapi aku harus mengeluarkan kamu...\nSelamat tinggal~`, text, {quoted: mek})
                                 console.log(color('[KICK]', 'red'), color('Received a virus text!', 'yellow'))
                                 var kic = `${sender.split("@")[0]}@s.whatsapp.net`
                                 client.groupRemove(from, [kic])
                                }
                        }

                    /*if (txt.includes('Iri')) {
                        iri = await getBuffer('https://sji.ijjiii.is/08a1c78e33e18dbc9c6d57cfb97af39d/XC7cDn26syY/cenwcoaweicwcmc')
                        client.sendMessage(from, iri, audio, {mimetype: 'audio/mp4', quoted: mek, ptt:true})
                                }*/

                        /*f (txt.includes('#unafk')) {
                        if (isAfk && isGroup) {
                        _afk.slice(sender, 1)
                        fs.writeFileSync('./src/afk.json', JSON.stringify(_afk))
                        reply('*Berhasil mematikan afk!*')
                            }
                        }*/
                
            let authorname = client.contacts[from] != undefined ? client.contacts[from].vname || client.contacts[from].notify : undefined	
			if (authorname != undefined) { } else { authorname = groupName }	
			
			function addMetadata(packname, author) {	
				if (!packname) packname = 'By'; if (!author) author = 'Bagas';	
				author = author.replace(/[^a-zA-Z0-9]/g, '');	
				let name = `${author}_${packname}`
				if (fs.existsSync(`./src/stickers/${name}.exif`)) return `./src/stickers/${name}.exif`
				const json = {	
					"sticker-pack-name": packname,
					"sticker-pack-publisher": author,
				}
				const littleEndian = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00])	
				const bytes = [0x00, 0x00, 0x16, 0x00, 0x00, 0x00]	

				let len = JSON.stringify(json).length	
				let last	

				if (len > 256) {	
					len = len - 256	
					bytes.unshift(0x01)	
				} else {	
					bytes.unshift(0x00)	
				}	

				if (len < 16) {	
					last = len.toString(16)	
					last = "0" + len	
				} else {	
					last = len.toString(16)	
				}	

				const buf2 = Buffer.from(last, "hex")	
				const buf3 = Buffer.from(bytes)	
				const buf4 = Buffer.from(JSON.stringify(json))	

				const buffer = Buffer.concat([littleEndian, buf2, buf3, buf4])	

				fs.writeFile(`./src/stickers/${name}.exif`, buffer, (err) => {	
					return `./src/stickers/${name}.exif`	
				})	

			}

                // Automate
             //premium.expiredCheck(_premium)
                    //Ban function
                        if (isCmd && isBanned) return
                        //Afk function
                        //if (isCmd && isAfk) return reply(`*Kamu masih afk sejak ${waktuafk}\nKetik ${prefix}unafk untuk mematikan afk*`)
                        //Public&Self Function
                    if (!mek.key.fromMe && banChats === true) return 

                        switch(command) {
case 'hidetag':
                                        if (!isUser) return reply(mess.only.daftarB)
                                        if (!isGroup) return reply(mess.only.group)
                                        if (!isOwner && !mek.key.fromMe && !isGroupAdmins) return reply(mess.only.admin)
					//if (!isBotGroupAdmins) return reply(mess.only.Badmin)
                                        if (args.length < 1) return reply(`Kirim perintah ${prefix}hidetag teks\nContoh : ${prefix}hidetag Pia cans`)
                                       members_id = []
					teks = (args.length > 1) ? body.slice(9).trim() : `${body.slice(8)}`
					for (let mem of groupMembers){
					members_id.push(mem.jid)
					}
					mentions(teks, members_id, MessageType.text)
					break
                                 case 'bal':
                                 case 'uang':
                                        if (!isUser) return reply(mess.only.daftarB)
                                        //if (isLimit(sender)) return 
                                        const kantong = checkATMuser(sender)
                                        reply(ind.uangkau(pushname, sender, kantong))
                                        //limitAdd(sender)
                                        break
                                case 'buylimit':
                                        if (!isUser) return reply(mess.only.daftarB)
                                        if (isGroup) return reply('Untuk membeli limit hanya bisa digunakan di private chat')
                                        if (args.length < 1) return reply(`Berapa limit yang mau di beli kak? Pastiin uang kakak cukup juga kak! \n\nCara cek uang: ${prefix}bal\nCek harga: ${prefix}shop`)
                                        payout = body.slice(10)
                                        const koinPerlimit = 1000
                                        const total = koinPerlimit * payout
                                        if ( checkATMuser(sender) <= total) return reply(`Maaf uang kamu belum mencukupi. silahkan kumpulkan dan beli nanti`)
                                        if ( checkATMuser(sender) >= total ) {
                                                confirmATM(sender, total)
                                                bayarLimit(sender, payout)
                                                await reply(`*「 PEMBAYARAN BERHASIL 」*\n\n*Pengirim* : Admin\n*Penerima* : ${pushname}\n*Nominal Pembelian* : ${payout} \n*Harga limit* : ${koinPerlimit}/limit\n*Sisa uang mu* : ${checkATMuser(sender)}\n\n*Proses berhasil dengan kode pembayaran* : ${createSerial(15)}`)
                                        }
                                        break
                                   case 'profile':
                                 if (!isUser) return reply(mess.only.daftarB)
                             try {
						anu = await client.getProfilePicture(sender)   
                       } catch {
                       anu = 'https://i.ibb.co/XSQfPhN/ab73026ecbdc.jpg'
                       }                                            
                                 teks = `             「 *USER INFO* 」\n\n- *Username* : ${pushname}\n- *Admin* : ${isGroupAdmins ? 'yes' : 'no'}\n\n================\n\n`
                                 buffer = await getBuffer(anu)
                                 client.sendMessage(from, buffer, image, { caption: teks, quoted: mek})
                                break
                                case 'limit':
                                        if (!isUser) return reply(mess.only.daftarB)
                                        //if (isLimit(sender)) return reply(ind.limitend(pusname))
                                        checkLimit(sender)
                                        //limitAdd(sender)
                                        break
                                        case 'qrcode':
				if (!isUser) return reply(mess.only.daftarB)
				if (isLimit(sender)) return 
					const tex = encodeURIComponent(body.slice(8))
					if (!tex) return client.sendMessage(from, 'MASUKAN URL/TEKS UNTUK DI JADIKAN QR', text, {quoted: mek})
					const buff = await getBuffer(`https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${tex}`)
					client.sendMessage(from, buff, image, {quoted: mek})
					limitAdd(sender)
					break                  
                                case 'listuser':
					client.updatePresence(from, Presence.composing) 
					if (!isUser) return reply(mess.only.daftarB)
					if (!isOwner) return reply(mess.only.ownerB)    
					teks = `╭────「 *TOTAL USER* 」\n`
					no = 0
					for (let hehehe of user) {
						no += 1
						teks += `[${no.toString()}] @${hehehe.split('@')[0]}\n`
					}
					teks += `│+ Total Pengguna : ${user.length}\n╰──────*⎿ *BOT* ⏋*────`
					client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": user}})
					break 
                      case 'gift':
				if (!isUser) return reply(mess.only.daftarB)
				if (!q.includes('|')) return  reply(`Fitur untuk gift bal/uang\nContoh : ${prefix}gift 6285717337679|500`)
                const tujuan = q.substring(0, q.indexOf('|') - 0) 
                const jumblah = q.substring(q.lastIndexOf('|') + 1)
                if(isNaN(jumblah)) return await reply('jumlah harus berupa angka!!')
                if (jumblah < 1000 ) return reply(`Minimal transfer 1000`)
                if (jumblah > 50000 ) return reply(`Maksimal transfer 50000`)
                if (checkATMuser(sender) < jumblah) return reply(`uang mu tidak mencukupi untuk melakukan transfer`)
                const tujuantf = `${tujuan.replace("@", '')}@s.whatsapp.net`
                fee = 0.000 *  jumblah
                hasiltf = jumblah - fee
                addKoinUser(tujuantf, hasiltf)
                confirmATM(sender, jumblah)
                addKoinUser('6285717337679@s.whatsapp.net', fee)
                reply(`*「 SUKSES 」*\n\nPengiriman Uang Telah Berhasil\nDari : ${sender.split("@")[0]}\nke : ${tujuan}\nJumlah : ${jumblah}`)
                break
                                case 'mutual':
                 if (!isUser) return reply(mess.only.daftarB)
                if (isGroup) return  reply( 'Command ini tidak bisa digunakan di dalam grup,silahkan gunakan di private chat bot')
                const anug = fs.readFileSync('./database/json/user.json')
                const anugJson = JSON.parse(anug)
                const rondIndox = Math.floor(Math.random() * anugJson.length)
                const rondKoy = anugJson[rondIndox]
                await reply('Looking for a partner...')
                await sleep(3000)
                await reply(`wa.me/${rondKoy.split("@")[0]}`)
                await sleep(1000)
                await reply( `Partner found: 🙉\n*${prefix}next* — find a new partner`)
            break
               case 'giftlimit': 
               if (!isUser) return reply(mess.only.daftarB)
				if (!isOwner && !mek.key.fromMe) return reply(mess.only.ownerB)                              
				  if (args.length < 1) return reply(`Contoh : ${prefix}giftlimit @tagmember 10`)
				const nomerr = args[0].replace('@','')
                const jmla = args[1]
                if (jmla <= 1) return reply(`minimal gift limit adalah 1`)
                if (isNaN(jmla)) return reply(`limit harus berupa angka`)
                if (!nomerr) return reply(`maaf format salah\nmasukan parameter yang benar\ncontoh : ${prefix}giftlimit @tagmember 20`)
                const cysz = nomerr + '@s.whatsapp.net'
                var found = false
                        Object.keys(_limit).forEach((i) => {
                            if(_limit[i].id === cysz){
                                found = i
                            }
                        })
                        if (found !== false) {
                            _limit[found].limit -= jmla
                            const updated = _limit[found]
                            const result = `Gift kuota limit sukses dengan SN: ${createSerial(8)} pada ${moment().format('DD/MM/YY HH:mm:ss')}
*「 GIFT KUOTA LIMIT 」*

• User : ${updated.id.replace('@s.whatsapp.net','')}
• Limit: ${limitawal-updated.limit}`
                            console.log(_limit[found])
                            fs.writeFileSync('./database/json/limit.json',JSON.stringify(_limit));
                            reply(result)
                        } else {
                                reply(`Maaf, nomor ${nomerr} tidak terdaftar di database!`)
                        }
                break
				case 'listzodiak':
					if (!isUser) return reply(mess.only.daftarB)
					if (isLimit(sender)) return
					client.sendMessage(from, listzodiak(prefix) , text, { quoted: mek })
					await limitAdd(sender)
					break
					case 'zodiak':
					if (!isUser) return reply(mess.only.daftarB)
					if (isLimit(sender)) return
	if (args.length === 0) {
	reply(`Kirim perintah ${prefix}zodiak [zodiak]\nContoh : ${prefix}zodiak aries\nUntuk mengecek semua zodiak ketik ${prefix}listzodiak`)
	} else if (args.includes('aries')) {
	client.sendMessage(from, aries(), text)
	} else if (args.includes('taurus')) {
	client.sendMessage(from, taurus(), text)
	} else if (args.includes('gemini')) {
	client.sendMessage(from, gemini(), text)
	} else if (args.includes('cancer')) {
	client.sendMessage(from, cancer(), text)
	} else if (args.includes('leo')) {
	client.sendMessage(from, Leo(), text)
	} else if (args.includes('virgo')) {
	client.sendMessage(from, Virgo(), text)
	} else if (args.includes('libra')) {
	client.sendMessage(from, Libra(), text)
	} else if (args.includes('scorpio')) {
	client.sendMessage(from, Scorpio(), text)
	} else if (args.includes('sagittarius')) {
	client.sendMessage(from, Sagittarius(), text)
	} else if (args.includes('capricorn')) {
	client.sendMessage(from, Capricorn(), text)
	} else if (args.includes('aquarius')) {
	client.sendMessage(from, Aquarius(), text)
	} else if (args.includes('pisces')) {
	client.sendMessage(from, Pisces(), text)
	} else {
	reply(`Zodiak tidak ada di ${prefix}listzodiak\nAtau gunakan huruf kecil`)
	}
	await limitAdd(sender)
	break
case 'xnxx':
                                        reply('Premium fitur,chat me to buy wa.me/6285717337679')
                                        break
case 'xvideosdl':
                                        reply('Premium fitur,chat me to buy wa.me/6285717337679')
                                        break
case 'xvideos':
                                         reply('Premium fitur,chat me to buy wa.me/6285717337679')
                                        break
case 'xnxxdl':
                                        reply('Premium fitur,chat me to buy wa.me/6285717337679')
                                        break
case 'spekhp':
                                if (!isUser && !mek.key.fromMe)return reply(mess.only.daftarB)
                                  if (args.length < 1) return reply(`Kirim perintah ${prefix}spekhp teks\nContoh : ${prefix}spekhp Realme C15`)
                                  if (isLimit(sender)) return
                                hp = body.slice(8)
            anu = await fetchJson(`https://api.vhtear.com/gsmarena?query=${hp}&apikey=${vhtearkey}`, {method: 'get'})
            buffer = await getBuffer(anu.result.image)
            teks = `*Spekifikasi Hp ${hp}* \n➸ *Nama HP* : ${anu.result.title} \n➸ *Spekifikasi* : ${anu.result.spec}`
                client.sendMessage(from, buffer, image, {quoted: mek, caption: teks})
                await limitAdd(sender)
                break
case 'heroml':
                                if (!isUser && !mek.key.fromMe)return reply(mess.only.daftarB)
                                if (args.length < 1) return reply(`Kirim perintah ${prefix}heroml hero\nContoh : ${prefix}heroml Fanny`)
                                if (isLimit(sender)) return
                                anu = await fetchJson(`https://api.vhtear.com/herodetail?query=${body.slice(8)}&apikey=${vhtearkey}`, {method: 'get'})
                                    teks = `➸ *Hero* : ${anu.result.title} \n➸ *Quotes* : ${anu.result.quotes}\n➸ *Info* : ${anu.result.info}\n➸ *Attributes* : ${anu.result.attributes}`
                                                        buffer = await getBuffer(anu.result.pictHero)
                                    client.sendMessage(from, buffer, image, {quoted: mek, caption: teks})
                                    await limitAdd(sender)
                                                         break
case 'cersex':
                                if (!isUser && !mek.key.fromMe)return reply(mess.only.daftarB)
                                //f (!isOwner && !mek.key.fromMe && !isPrem) return reply(mess.only.premium)                              
                                if (isGroup) return reply('Fitur ini hanya bisa digunakan di private chat')
                                if (isLimit(sender)) return
                                        cers = await fetchJson(`https://api.vhtear.com/cerita_sex&apikey=${vhtearkey}`, {method: 'get'})
                                        teks = `Judul: ${cers.result.judul}\n${cers.result.cerita}`
                                        buffer = await getBuffer(cers.result.image)
                                        client.sendMessage(from, buffer, MessageType.image, { caption: teks, quoted: mek })
                                        await limitAdd(sender)
                                        break
 case 'wolflogo':
                                if (!isUser && !mek.key.fromMe)return reply(mess.only.daftarB)
                                if (isLimit(sender)) return
                                        var gh = body.slice(10)
                                        var teks1 = gh.split("|")[0];
                                        var teks2 = gh.split("|")[1];
                                        if (args.length < 1) return reply(`Kirim perintah ${prefix}wolflogo teks|teks\nContoh : ${prefix}wolflogo Bagas|R`)
                                        buffer = await getBuffer(`https://api.vhtear.com/avatarwolf?text1=${teks1}&text2=${teks2}&apikey=${vhtearkey}`)
                                        client.sendMessage(from, buffer, image, {quoted: mek})
                                        await limitAdd(sender)
                                        break
case 'cekpasangan':
                                if (!isUser&& !mek.key.fromMe)return reply(mess.only.daftarB)
                                //if (!isOwner && !ben.key.fromMe && !isPremium) return reply(mess.only.premium)
                                if (args.length < 1) return reply(`Kirim perintah ${prefix}cekpasangan Cowo|Cewe\nContoh : ${prefix}cekpasangan Bagas|R`)
                                if (isLimit(sender)) return
                                var asu = body.slice(13)
                                        var teks8 = asu.split("|")[0];
                                        var teks9 = asu.split("|")[1];
                                        anu = await fetchJson(`http://scrap.terhambar.com/jodoh?n1=${teks8}&n2=${teks9}`, {method: 'get'})
                                        teks = `*Pasangan dengan data:*\n- *Nama cowok* : ${anu.result.nama_anda}\n- *Nama cewek* : ${anu.result.nama_pasangan}\n\n*Sisi:*\n- *Positif* : ${anu.result.sisi.positif}\n- *Negatif* : ${anu.result.sisi.negatif}`
                        buffer = await getBuffer(anu.result.gambar)
                        client.sendMessage(from, buffer, image, { caption: teks, quoted: mek})
                        await limitAdd(sender)
                  break
case 'customtahta':
                                if (!isUser && !mek.key.fromMe)return reply(mess.only.daftarB)
                                //f (!isOwner && !mek.key.fromMe && !isPrem) return reply(mess.only.premium)                              
                                //if (!isOwner && !ben.key.fromMe && !isPremium) return reply(mess.only.premium)
                                var ghs = body.slice(13)
                                        var teks3 = ghs.split("|")[0];
                                        var teks4 = ghs.split("|")[1];
                                        var teks5 = ghs.split("|")[2];
                                        if (args.length < 1) return reply(`Kirim perintah ${prefix}customtahta teks1|teks2|teks3\nContoh : ${prefix}customtahta Bagas|Gans|Valid`)
                                          if (isLimit(sender)) return
                                        anu = await getBuffer(`https://naufalhoster.xyz/textmaker/hartatahta_custom?apikey=${naufalkey}&text1=${teks3}&text2=${teks4}&text3=${teks5}`)
                                        client.sendMessage(from, anu, image, { quoted: mek})
                                        await limitAdd(sender)
                                        break
case 'blood':
                                 if (!isUser && !mek.key.fromMe) return reply(mess.only.daftarB)
                                 if (args.length < 1) return reply(`Kirim perintah ${prefix}blood teks\nContoh : ${prefix}blood Bagas`)
                                   if (isLimit(sender)) return
                            teks = body.slice(7)
                                 blood = await getBuffer(`https://naufalhoster.xyz/textmaker/blood?apikey=${naufalkey}&text=${teks}`)
                                 client.sendMessage(from, blood, MessageType.image, { caption: `BLOOD ${teks}`, quoted: mek })
                                 await limitAdd(sender)
                                 break
         case 'matrix':
                                 if (!isUser && !mek.key.fromMe) return reply(mess.only.daftarB)
                                 if (args.length < 1) return reply(`Kirim perintah ${prefix}matrix teks\nContoh : ${prefix}matrix Bagas`)
                                 if (isLimit(sender)) return
                            teks = body.slice(8)
                                 blood = await getBuffer(`https://naufalhoster.xyz/textmaker/matrix?apikey=${naufalkey}&text=${teks}`)
                                 client.sendMessage(from, blood, MessageType.image, { caption: `MATRIX ${teks}`, quoted: mek })
                                 await limitAdd(sender)
                                 break
case 'jadwaltv':
                    if (!isUser && !mek.key.fromMe) return reply(mess.only.daftarB)
            if (args.length < 1) return reply(`Kirim perintah *${prefix}jadwaltv [channel]*`)
            if (isLimit(sender)) return
            tv = body.slice(10)
            anu = await fetchJson(`https://api.zeks.xyz/api/jadwaltv?channel=${tv}&apikey=apivinz`, {method: 'get'})
                        if (anu.status === false) return reply(anu.message)
            reply(`*Jadwal TV* : ${tv} \n${anu.result}\n`)
            await limitAdd(sender)
            break
case 'listsurah':
                        if (!isUser&& !mek.key.fromMe) return reply(mess.only.daftarB)
                        if (isLimit(sender)) return
             reply (`Berikut ini Daftar Nomor Surah\nUntuk mencari ketik ${prefix}quran 1

1. Al-Fatihah الفاتحة
2. Al-Baqarah البقرة
3. Ali ‘Imran آل عمران
4. An-Nisa’ النّساء
5. Al-Ma’idah المآئدة
6. Al-An’am الانعام
7. Al-A’raf الأعراف
8. Al-Anfal الأنفال
9. At-Taubah التوبة
10. Yunus ينوس
11. Hud هود
12. Yusuf يسوف
13. Ar-Ra’d الرّعد
14. Ibrahim إبراهيم
15. Al-Hijr الحجر
16. An-Nahl النّحل
17. Al-Isra’ بني إسرائيل
18. Al-Kahf الكهف
19. Maryam مريم
20. Ta Ha طه
21. Al-Anbiya الأنبياء
22. Al-Hajj الحجّ
23. Al-Mu’minun المؤمنون
24. An-Nur النّور
25. Al-Furqan الفرقان
26. Asy-Syu’ara’ الشّعراء
27. An-Naml النّمل
28. Al-Qasas القصص
29. Al-‘Ankabut العنكبوت
30. Ar-Rum الرّوم
31. Luqman لقمان
32. As-Sajdah السّجدة
33. Al-Ahzab الْأحزاب
34. Saba’ سبا
35. Fatir فاطر
36. Ya Sin يس
37. As-Saffat الصّافات
38. Sad ص
39. Az-Zumar الزّمر
40. Al-Mu’min المؤمن
41. Fussilat فصّلت
42. Asy-Syura الشّورى
43. Az-Zukhruf الزّخرف
44. Ad-Dukhan الدّخان
45. Al-Jasiyah الجاثية
46. Al-Ahqaf الَأحقاف
47. Muhammad محمّد
48. Al-Fath الفتح
49. Al-Hujurat الحجرات
50. Qaf ق
51. Az-Zariyat الذّاريات
52. At-Tur الطّور
53. An-Najm النّجْم
54. Al-Qamar القمر
55. Ar-Rahman الرّحْمن
56. Al-Waqi’ah الواقعه
57. Al-Hadid الحديد
58. Al-Mujadilah المجادلة
59. Al-Hasyr الحشْر
60. Al-Mumtahanah الممتحنة
61. As-Saff الصّفّ
62. Al-Jumu’ah الجمعة
63. Al-Munafiqun المنافقون
64. At-Tagabun التّغابن
65. At-Talaq الطّلاق
66. At-Tahrim التّحريم
67. Al-Mulk الملك
68. Al-Qalam القلم
69. Al-Haqqah الحآقّة
70. Al-Ma’arij المعارج
71. Nuh نوح
72. Al-Jinn الجنّ
73. Al-Muzzammil المزمّل
74. Al-Muddassir المدشّر
75. Al-Qiyamah القيمة
76. Al-Insan الْاٍنسان
77. Al-Mursalat المرسلات
78. An-Naba’ النّبا
79. An-Nazi’at النّازعات
80. ‘Abasa عبس
81. At-Takwir التّكوير
82. Al-Infitar الانفطار
83. Al-Tatfif المطفّفين
84. Al-Insyiqaq الانشقاق
85. Al-Buruj البروج
86. At-Tariq الطّارق
87. Al-A’la الْأعلى
88. Al-Gasyiyah الغاشية
89. Al-Fajr الفجر
90. Al-Balad البلد
91. Asy-Syams الشّمس
92. Al-Lail الّيل
93. Ad-Duha الضحى
94. Al-Insyirah الانشراح
95. At-Tin التِّينِ
96. Al-‘Alaq العَلَق
97. Al-Qadr الْقَدْرِ
98. Al-Bayyinah الْبَيِّنَةُ
99. Az-Zalzalah الزلزلة
100. Al-‘Adiyat العاديات
101. Al-Qari’ah القارعة
102. At-Takasur التكاثر
103. Al-‘Asr العصر
104. Al-Humazah الهُمَزة                                            
105. Al-Fil الْفِيلِ                                                    
106. Quraisy قُرَيْشٍ
107. Al-Ma’un الْمَاعُونَ                                                
108. Al-Kausar الكوثر
109. Al-Kafirun الْكَافِرُونَ                                              
110. An-Nasr النصر
111. Al-Lahab المسد                                                  
112. Al-Ikhlas الإخلاص
113. Al-Falaq الْفَلَقِ                                      
114. An-Nas نَاسِ`)
await limitAdd(sender)
break
                      case 'quran':
                      if (!isUser&& !mek.key.fromMe) return reply(mess.only.daftarB)
                      if (args.length < 1) return reply(`Kirim perintah ${prefix}quran angka\nContoh : ${prefix}quran 1`)
                      if (isLimit(sender)) return
     surah = body.slice(7)                                            
     anu = await fetchJson(`https://api.zeks.xyz/api/quran?no=${surah}&apikey=apivinz`, {method: 'get'})                                         
      quran = `Surah Al-Qur\`an Nomor: ${surah}\nSurah: ${anu.surah}\nDiturunkan Dikota: ${anu.type}\nJumlah Ayat: ${anu.jumlah_ayat}\n\n${anu.ket}                                                                  
                \n==========================\n`
              for (let surah of anu.ayat) {                                                 
         quran += `${surah.number}\n${surah.text}\n${surah.translation_id}                                                                   
        \n================\n`}                                               
        //lagu = await getBuffer(anu.audio)                                    
         //client.sendMessage(from, lagu, audio, {mimetype: 'audio/mp3', ptt:true})                                                                     
        reply(quran.trim())
        await limitAdd(sender)
                                   break 
          case 'playvideo':
       if (!isUser && !mek.key.fromMe) return reply(mess.only.daftarB)                
        //if (!isPrem) return reply(mess.prem)
        if (args.length < 1) return reply(`Kirim perintah ${prefix}playvideo teks\nContoh : ${prefix}playvideo savior`)
        if (isLimit(sender)) return 
        reply(mess.wait)
        anu = await fetchJson(`https://naufalhoster.xyz/dl/ytplayvideo?apikey=${naufalkey}&query=${body.slice(11)}`, {method:'get'})
        bum = await getBuffer(anu.result.thumbnail)
        mm = await getBuffer(anu.result.video)
        tem = `*Data Video Berhasil Di Dapat!!*\n*Name*: ${anu.result.title}\n*Durasi*: ${anu.result.duration}\n*Like*: ${anu.result.likeCount}\n*Dislike*: ${anu.result.dislikeCount}\n*Filesize*: ${anu.result.filesize}\n*Sedang Di Kirim Kak ^_^*`
        reply(tem)
        client.sendMessage(from, mm, video, { mimetype: 'video/mp4', quoted:mek,caption:'nih'})
        await limitAdd(sender)
        break 
        case 'citlimit':
				if (!isUser) return reply(mess.only.daftarB)
				if (!isOwner && !mek.key.fromMe) return reply(mess.only.ownerB)                              
				if (args.length < 1) return reply(`Kirim perintah ${prefix}citlimit angka\nContoh : ${prefix}citlimit 1000`)
				payout = body.slice(10)
				if(isNaN(payout)) return await reply('limit harus berupa angka!!')
				//payout = body.slice(10)
                      const koinPerlimit0 = 0
                 const totall = koinPerlimit0 * payout
                   //uf ( checkATMuser(sender) <= totall) return reply(`Maaf uang kamu belum mencukupi. silahkan kumpulkan dan beli nanti`)
                    if ( checkATMuser(sender) >= totall ) {
                           confirmATM(sender, totall)
                      bayarLimit(sender, payout)
					await reply(`*✓Pembayaran Berhasil✓*\n\n*⋟Pengirim* : Admin\n*⋟Penerima* : Tuanku\n*⋟Nominal pembelian* : ${payout} \n*⋟Harga limit* : ${koinPerlimit0}/Limit\n*⋟Sisa uang mu* : ${checkATMuser(sender)}\n\nProses berhasil dengan kode pembayaran\n${createSerial(15)}`)
				} 
				break
       case 'wiki':
       case 'wikipedia':  
       if (isLimit(sender)) return 
       if (!isUser) return reply(mess.only.daftarB)
	 if (args.length < 1) return reply(`Kirim perintah ${prefix}wiki teks\nContoh ${prefix}wiki Albert Einstein`)
      anu = await fetchJson(`https://api.vhtear.com/wikipedia?query=${body.slice(4)}&apikey=${vhtearkey}`, {method: 'get'})
      teks = `_❕Ini yang saya temukan di wiki_\n\n${anu.result.Info}`
      reply(teks) 
      await limitAdd(sender)
      break
case 'pantun':   
       if (isLimit(sender)) return 
       if (!isUser && !mek.key.fromMe) return reply(mess.only.daftarB)                
       anu = await fetchJson(`https://api.vhtear.com/random_pantun&apikey=${vhtearkey}`, {method: 'get'})
       reply(anu.result.pantun)  
       await limitAdd(sender)
       break 
       case 'artinama':
       if (!isUser && !mek.key.fromMe) return reply(mess.only.daftarB)                
       if (args.length < 1) return reply(`Kirim perintah ${prefix}artinama nama\nContoh : ${prefix}artinama Bagas`)
         if (isLimit(sender)) return 
       anu = await fetchJson(`https://naufalhoster.xyz/tools/artinama?apikey=${naufalkey}&nama=${body.slice(9)}`, {method:'GET'})
       var ggk = `*《ARTINAMA》*\n*NAMA*: ${anu.result.nama}\n${anu.result.arti}`
       reply(ggk)
       await limitAdd(sender)
       break
       case 'quotes':   
       if (isLimit(sender)) return 
       if (!isUser && !mek.key.fromMe) return reply(mess.only.daftarB)                
       anu = await fetchJson(`https://api.vhtear.com/quoteid&apikey=${vhtearkey}`, {method: 'get'})
       reply(anu.result.kata) 
       await limitAdd(sender)
       break
       case 'cuaca':   
       if (isLimit(sender)) return 
       if (!isUser && !mek.key.fromMe) return reply(mess.only.daftarB)                
       if (args.length < 1) return reply(`Kirim perintah ${prefix}cuaca teks\nContoh : ${prefix}cuaca Jakarta`)
       reply(mess.wait)
       cfc = body.slice(6)
       anu = await fetchJson(`https://api.vhtear.com/weather?city=${body.slice(6)}&apikey=${vhtearkey}`, {method: 'get'})
       teks = `_🔎Menurut Cuaca Bmkg Kota : ${cfc}_\n\n*≻CUACA*:${anu.result.weather}\n*≻LOKASI*:${anu.result.location}`
       reply(teks)	 
       await limitAdd(sender)
       break
case 'emoji':  
       if (isLimit(sender)) return reply(limitend(pusname))
       if (!isUser) return reply(mess.verify)
       if (args.length < 1) return reply(mess.txt)
       teks = emojiUnicode(gm).trim()
       anu = await getBuffer(`https://api.zeks.xyz/api/emoji-image?apikey=apivinz&emoji=${teks}`) 
       reply(mess.wait)
       client.sendMessage(from, anu, image, {quoted:mek,caption:'nih'}) 
       await limitAdd(sender)
       break
case 'infogempa':
                                if (!isUser && !mek.key.fromMe) return reply(mess.only.daftarB)
                                if (isLimit(sender)) return
                                anu = await fetchJson(`https://api-zefian.glitch.me/api/infogempa`, {method: 'get'})
                                teks = `*${anu.waktu}*\n📍 *Lokasi* : *${anu.lokasi}*\n〽 *Kedalaman* : *${anu.kedalaman}*\n💢 *Magnitude* : *${anu.magnitude}*\n🔘 *Potensi* : *${anu.potensi}*\n📍 *Koordinat* : *${anu.koordinat}*`
                                buffer = await getBuffer(anu.map)
                                client.sendMessage(from, buffer, image, {quoted: mek, caption: teks})
                                await limitAdd(sender)
                                break
case 'quotesnime':
                                 if (!isUser && !mek.key.fromMe) return reply(mess.only.daftarB)
                                 if (isLimit(sender)) return
                                   anu = await fetchJson(`https://api-zefian.glitch.me/api/quotesnime/random`, {method: 'get'})
                                   teks = `- *Anime* : ${anu.data.anime}\n- *Karakter* : ${anu.data.character}\n- *Quotes* : ${anu.data.quote} `
                                   client.sendMessage(from, teks, text, { quoted: mek})
                                   await limitAdd(sender)
                                 break
case 'naruto':
 if (!isUser && !mek.key.fromMe) return reply(mess.only.daftarB)
                if (isLimit(sender)) return 
                //if (isBanned) return reply(mess.only.benned)
                nar = `${body.slice(7)}`
                     if (args.length < 1) return reply(`Kirim perintah ${prefix}naruto teks\nContoh : ${prefix}naruto Bagas`)
                     burtff = await getBuffer(`https://videfikri.com/api/textmaker/narutobanner/?text=${nar}`, {method: 'get'})
                     client.sendMessage(from, burtff, image, {quoted: mek})
                  await limitAdd(sender) 
                  break
case 'chat':                                                               
                            if (!isUser && !mek.key.fromMe) return reply(mess.only.daftarB)
                            if (!isOwner) return 
                                        if (args.length < 1) return reply(`Kirim perintah ${prefix}chat nomor|pesan\nContoh : ${prefix}chat 6285717337679|hai ganteng`) 
                                        //if (isLimit(sender)) return 
                                        var cie = body.slice(6)
                                        var ajk = cie.split("|")[0];
                                        var chatnya = cie.split("|")[1];
                                        sendMess(`${ajk}@s.whatsapp.net`, `Anonymous\nPesan : ${chatnya}`)
                                        //await limitAdd(sender)
                                        break
                                        break
case 'phcomment':
                                reply('Premium fitur,chat me to buy wa.me/6285717337679')
                                        break
case 'bikinmeme':                                                                                                       
                                   reply('Premium fitur,chat me to buy wa.me/6285717337679')
                                        break
case 'rip':
                                         if (!isUser && !mek.key.fromMe) return reply(mess.only.daftarB)  
                                                if (isLimit(sender)) return                                                                                                                    
                                        // if (!isOwner &&!ben.key.fromMe && !isPremium) return reply(mess.only.premium)                                        
                                         var imgbb = require('imgbb-uploader')
                                         if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
                                         ger = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
                                         owgi = await client.downloadAndSaveMediaMessage(ger)                                                                                                                      
                                        anu = await imgbb("68cb5bee517bce4f74b0e910a5d96346", owgi)                                           
                                        teks = `${anu.display_url}`                                                                                               
                                        buffer = await getBuffer(`https://naufalhoster.xyz/textmaker/rip?apikey=${naufalkey}&url=${teks}`)                                                                                                                                                                   
                                        client.sendMessage(from, buffer, image, { caption: 'Neh..', quoted: mek})
                                        } else {
                                        	reply('Reply potonya')
                                        }
                                        await limitAdd(sender)
                                        break
case 'bokeh':
                        if (!isUser && !mek.key.fromMe) return reply(mess.only.daftarB)
                        if (args.length < 1) return reply(`Kirim perintah ${prefix}bokeh teks\nContoh : ${prefix}bokeh Bagas`)
                        if (isLimit(sender)) return                                                
                        tekss = body.slice(7)
                        buffer = await getBuffer(`https://naufalhoster.xyz/textmaker/bokeh?apikey=${naufalkey}&text=${tekss}`)
                        teks = `BOKEH ${tekss}`
                        client.sendMessage(from, buffer, image, { caption: teks, quoted: mek })
                        await limitAdd(sender)
                                 break
case 'imagetourl':
case 'imgtourl':
                                   reply('Premium fitur,chat me to buy wa.me/6285717337679')
                                        break
case 'imagetopdf':                                                                                                      
                       reply('Premium fitur,chat me to buy wa.me/6285717337679')
                                        break
case 'imagecartoon':                                                                       
                           reply('Premium fitur,chat me to buy wa.me/6285717337679')
                                        break
case 'imagecomic':
                                        reply('Premium fitur,chat me to buy wa.me/6285717337679')
                                        break 
case 'imagefire':                                              
                                         reply('Premium fitur,chat me to buy wa.me/6285717337679')
                                        break
case 'imagegrafitti':
case 'imagegrafiti':                                               
                                 reply('Premium fitur,chat me to buy wa.me/6285717337679')
                                        break
case 'imagenegative':
case 'imagenegatif':                                                                                   
                                  reply('Premium fitur,chat me to buy wa.me/6285717337679')
                                        break
case 'imagedistortion':
                                   reply('Premium fitur,chat me to buy wa.me/6285717337679')
                                        break
case 'imagenightvision':
case 'imagenv':
                                   reply('Premium fitur,chat me to buy wa.me/6285717337679')
                                        break
case 'imagewanted':
                                   reply('Premium fitur,chat me to buy wa.me/6285717337679')
                                        break
case 'imagewasted':
                                       reply('Premium fitur,chat me to buy wa.me/6285717337679')
                                        break
case 'imagefisheye':
                                reply('Premium fitur,chat me to buy wa.me/6285717337679')
                                        break
case 'qouteit2':
case 'quoteit2':
                                 if (!isUser  && !mek.key.fromMe) return reply(mess.only.daftarB)
                                 if (args.length < 1) return reply(`Kirim perintah ${prefix}quoteit2 teks`)
                                 if (isLimit(sender)) return                   
                                 var teks = body.slice(10)
                                 buffer = await getBuffer(`https://naufalhoster.xyz/textmaker/quoteslife?apikey=${naufalkey}&quotes=${teks}`)
                                 client.sendMessage(from, buffer, image, { caption: 'Nih!!', quoted: mek })
                                 await limitAdd(sender)
                                 break
case 'deface':
                                       reply('Premium fitur,chat me to buy wa.me/6285717337679')
                                        break
case 'hekweb':
                                   reply('Premium fitur,chat me to buy wa.me/6285717337679')
                                        break
case 'ytcomment':
                                reply('Premium fitur,chat me to buy wa.me/6285717337679')
                                        break
         case 'tebakgambar':
				if (!isUser) return reply(mess.only.daftarB)
				if (isLimit(sender)) return
					anu = await fetchJson(`https://api.vhtear.com/tebakgambar&apikey=${vhtearkey}`, {method: 'get'})
					bufferkkk = await getBuffer(anu.result.soalImg)
					setTimeout( () => {
					client.sendMessage(from, '*➸ Jawaban :* '+anu.result.jawaban, text, {quoted: mek}) // ur cods
					}, 30000) // 1000 = 1s,
					setTimeout( () => {
					client.sendMessage(from, '_10 Detik lagi…_', text) // ur cods
					}, 20000) // 1000 = 1s,
					setTimeout( () => {
					client.sendMessage(from, '_20 Detik lagi_…', text) // ur cods
					}, 10000) // 1000 = 1s,
					setTimeout( () => {
					client.sendMessage(from, '_30 Detik lagi_…', text) // ur cods
					}, 2500) // 1000 = 1s,
					setTimeout( () => {
					client.sendMessage(from, bufferkkk, image, { caption: '_Jelaskan Apa Maksud Gambar Ini_', quoted: mek }) // ur cods
					}, 0) // 1000 = 1s,
					await limitAdd(sender)
					break
case 'tiktok':
                                                if (!isUser && !mek.key.fromMe) return reply(mess.only.daftarB)
                                                        if (args.length < 1) return reply(`Kirim perintah ${prefix}tiktok link\nContoh : ${prefix}tiktok https://vt.tiktok.com/ZSwsQCgN/`)
                                                        if(!isUrl(args[0]) && !args[0].includes('tiktok')) return reply(mess.error.Iv)
                                                        if (isLimit(sender)) return
                                                        anu = await fetchJson(`https://naufalhoster.xyz/dl/tiktok?apikey=${naufalkey}&url=${args[0]}`, {method: 'get'})
                                                        teks = `*Username* : ${anu.result.username}\n*Nickname* : ${anu.result.nickname}\n*Caption* : ${anu.result.caption}\n\n*_By Bot R_*`
                                                        thumb = await getBuffer(anu.result.thumbnail)
                                                        //client.sendMessage(from, thumb, image, {quoted: mek, caption: teks})
                                                        buffer = await getBuffer(anu.result.videoNoWatermark)
                                                        client.sendMessage(from, buffer,video, {mimetype: 'video/mp4', filename: `${anu.title}.mp4`, quoted: mek, caption: teks})
                                                        await limitAdd(sender)
                                                           break
case 'phlogo':
                                if (!isUser && !mek.key.fromMe) return reply(mess.only.daftarB)
                                        gh = body.slice(8)
                                        teks1 = gh.split("|")[0];
                                        teks2 = gh.split("|")[1];
                                        if (args.length < 1) return reply(`Kirim perintah ${prefix}phlogo teks|teks\nContoh : ${prefix}phlogo Bagas|R`)
                                        if (isLimit(sender)) return
                                        buffer = await getBuffer(`https://naufalhoster.xyz/textmaker/pornhub?apikey=${naufalkey}&text1=${teks1}&text2=${teks2}`)
                                        client.sendMessage(from, buffer, image, {quoted: mek })
                                        await limitAdd(sender)
                                        break
            case 'next':
                if (!isUser) return reply(mess.only.daftarB)
                if (isGroup) return  reply( 'Command ini tidak bisa digunakan di dalam grup,silahkan gunakan di private chat bot')
                const aanug = fs.readFileSync('./database/json/user.json')
                const aanugJson = JSON.parse(aanug)
                const rondIndoxx = Math.floor(Math.random() * aanugJson.length)
                const rondKoyy = aanugJson[rondIndoxx]
                await reply('Looking for a partner...')
                await sleep(3000)
                await reply(`wa.me/${rondKoyy.split("@")[0]}`)
                await sleep(1000)
                await reply( `Partner found: 🙉\n*${prefix}next* — find a new partner`)
            break
                                case 'daftar':
					client.updatePresence(from, Presence.composing)
					if (isUser) return reply('Kamu sudah terdaftar')
					if (args.length < 1) return reply(`Parameter Salah\nCommand : ${prefix}daftar nama|umur\nContoh : ${prefix}daftar Bagas|15`)
					var reg = body.slice(8)
					var jeneng = reg.split("|")[0];
					var umure = reg.split("|")[1];
                    if (jeneng.length < 1) return reply(`Parameter Salah\nCommand : ${prefix}daftar nama|umur\nContoh : ${prefix}daftar Bagas|15`)
					if (umure.length < 1) return reply(`Parameter Salah\nCommand : ${prefix}daftar nama|umur\nContoh : ${prefix}daftar Bagas|15`)
					teks = `_Pendaftaran berhasil dengan_\n_SN_:${createSerial(15)}\n_Pada ${date} ${time}_\n\n_Nama:_ ${jeneng}\n_Umur:_ ${umure}\n_Tag: @${sender.split('@')[0]}_\n_Nomor: wa.me/${sender.split("@")[0]}_\n\n_Sebelum menggunakan bot ketik ${prefix}readme terlebih dahulu_\n_Ketik ${prefix}help untuk menampilkan menu_\n\n_User terdaftar: ${user.length}_`
						user.push(sender)
						fs.writeFileSync('./database/json/user.json', JSON.stringify(user))
						try {
						anu = await client.getProfilePicture(sender)   
                       } catch {
                       anu = 'https://i.ibb.co/XSQfPhN/ab73026ecbdc.jpg'
                       }                         
                        buffer = await getBuffer(anu)                                                         
						client.sendMessage(from, buffer, image, { contextInfo: {mentionedJid: [sender]}, caption: teks, quoted : mek })
					break
/*case 'verify':
                    client.updatePresence(from, Presence.composing)
					if (isUser) return reply('kamu sudah terdaftar 🙂')
					user.push(sender)
					fs.writeFileSync('./database/json/user.json', JSON.stringify(user))
					try {
					ppimg = await client.getProfilePicture(`${sender.split('@')[0]}@s.whatsapp.net`)
					} catch {
					ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
					}
					captionnya = `_Pendaftaran berhasil dengan_\n_SN_:${createSerial(15)}\n_Pada ${date} ${time}_\n\n_Nama: ${pushname}_\n_Nomor: wa.me/${sender.split("@")[0]}_\n\n_Sebelum menggunakan bot ketik ${prefix}readme terlebih dahulu_\n_Ketik ${prefix}help untuk menampilkan menu_\n\n_User terdaftar: ${user.length}_`
					img = await getBuffer(ppimg)
					client.sendMessage(from, img, image, {quoted: mek, caption: captionnya})
					break*/
        case 'fitnah':
                 if (!isUser) return reply(mess.only.daftarB)
                if (!isOwner && !mek.key.fromMe) return reply(mess.only.ownerB)                              
				if (args.length < 1) return reply(`Usage :\n${prefix}fitnah @tag|pesan|balasanbot\n\nEx : \n${prefix}fitnah @tagmember|hai|hai juga`)
				var gh = body.slice(7)
				mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					var replace = gh.split("|")[0];
					var targett = gh.split("|")[1];
					var bot = gh.split("|")[2];
					client.sendMessage(from, `${bot}`, text, {quoted: { key: { fromMe: false, participant: `${mentioned}`, ...(from ? { remoteJid: from } : {}) }, message: { conversation: `${targett}` }}})
					break                              
				case 'shota':
				    try{
						res = await fetchJson(`https://tobz-api.herokuapp.com/api/randomshota?apikey=BotWeA`, {method: 'get'})
						buffer = await getBuffer(res.result)
                                                if (!isUser) return reply(mess.only.daftarB)
                                                if (isLimit(sender)) return reply(ind.limitend(pusname))
						client.sendMessage(from, buffer, image, {quoted: mek, caption: 'Nich'})
                                                await limitAdd(sender)
					} catch (e) {
						console.log(`Error :`, color(e,'red'))
						reply('❌ *ERROR* ❌')
					}
					break
				case 'brainly':
                                        if (args.length < 1) return client.sendMessage(from, `Kirim perintah ${prefix}brainly teks\nContoh : ${prefix}brainly arti Pancasila`, MessageType.text, brainlyy)
                                        if (isLimit(sender)) return 
					var teks = body.slice(9)
					axios.get(`https://api.vhtear.com/branly?query=${teks}&apikey=${vhtearkey}`).then((res) => {
					 let hasil = ` ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ${res.data.result.data}`;
						client.sendMessage(from, hasil ,MessageType.text, { quoted: mek } );

                                        limitAdd(sender)
					})
				break
				case 'group':
				case 'grup':
                                        if (!isUser) return reply(mess.only.daftarB)
					if (!isOwner && !mek.key.fromMe && !isGroupAdmins) return reply(mess.only.admin)
                                        if (!isGroup) return reply(mess.only.group)
					if (!isBotGroupAdmins) return reply(mess.only.Badmin)
					if (args[0] === 'open') {
					reply(`[ *SUCCES OPEN GRUP* ]`)
					client.groupSettingChange(from, GroupSettingChange.messageSend, false)
					} else if (args[0] === 'close') {
					await client.groupSettingChange(from, GroupSettingChange.messageSend, true)
					reply(`[ *SUCCES CLOSE GRUP* ]`)
					}
					break
                  case 'tagme':
                                                                if (!isUser) return reply(mess.only.daftarB)
                                                                if (!isGroup) return reply(mess.only.group)
                                                                if (isLimit(sender)) return
                                        var niom = mek.participant
                                        const tag = {
                                        text: `@${niom.split("@s.whatsapp.net")[0]}`,
                                        contextInfo: { mentionedJid: [niom] }
                                        }
                                        client.sendMessage(from, tag, text, {quoted: mek})
                                        await limitAdd(sender)
                                        break
				/*case 'wiki':
					var itsme = `${numbernye}@s.whatsapp.net`
					var split = `*𝐖𝐈𝐊𝐈*`
					// var taged = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
					const wimki = {
					contextInfo: {
					participant: itsme,
					quotedMessage: {
					extendedTextMessage: {
					text: split,
									}
								}
							}
						}
                                        if (args.length < 1) return client.sendMessage(from, `Kirim perintah ${prefix}wiki teks\nContoh : ${prefix}wiki Albert Einstein`, MessageType.text, wimki)
                                        if (isLimit(sender)) return
					var teks = body.slice(6)
					axios.get(`https://alfians-api.herokuapp.com/api/wiki?q=${teks}`).then((res) => {
						let hasil = `Menurut Wikipedia:\n\n${res.data.result}`;
						client.sendMessage(from, hasil ,MessageType.text, wimki);

                                          limitAdd(sender)
					})
					break*/
				case 'gcname':
                                        if (!isUser) return reply(mess.only.daftarB)
                                        if (!isGroup) return reply(mess.only.group)
                                        if (!isOwner && !mek.key.fromMe && !isGroupAdmins) return reply(mess.only.admin)
					if (!isBotGroupAdmins) return reply(mess.only.Badmin)
					await client.groupUpdateSubject(from, `${body.slice(8)}`)
					reply(`「 *CHANGE TO ${body.slice(8)}* 」`)
					break
				case 'gcdesk':
                                        if (!isUser) return reply(mess.only.daftarB)
                                        if (!isGroup) return reply(mess.only.group)
                                        if (!isOwner && !mek.key.fromMe && !isGroupAdmins) return reply(mess.only.admin)
					if (!isBotGroupAdmins) return reply(mess.only.Badmin)
					await client.groupUpdateDescription(from, `${body.slice(8)}`)
					reply(`「 *CHANGE TO ${body.slice(8)}* 」`)
					break
               case 'say':
                                        if (!isUser) return reply(mess.only.daftarB)
                                        teks = body.slice(5)
                                        if (args.length < 1) return reply('Teksnya mana kak?')
                                        if (isLimit(sender)) return
                                        saying = teks
                                        client.sendMessage(from, saying, text)
                                        limitAdd(sender)
                                        break
				case 'tinyurl':

                                        if (!isUser) return reply(mess.only.daftarB)
                                        if (args.length < 1) return client.sendMessage(from, `Urlnya mana?`, MessageType.text, srotlink)
                                        if (isLimit(sender)) return
                                        const tinyurl = body.slice(9)
					axios.get(`https://tobz-api.herokuapp.com/api/tinyurl?url=${tinyurl}&apikey=BotWeA`).then((res) => {
						let hasil = `${res.data.result}`;
						reply(hasil)
                                          limitAdd(sender)
				})
				break
				case 'runtime':
					runtime = process.uptime()
					teks = `${kyun(runtime)}`
					var itsme = `${numbernye}@s.whatsapp.net`
					var split = `${fake}`
					const rtimebro = {
					contextInfo: {
					participant: itsme,
					quotedMessage: {
					extendedTextMessage: {
					text: split,
									}
								}
							}
						}
                                        if (!isUser) return reply(mess.only.daftarB)
					client.sendMessage(from, `Bot Telah Berjalan Selama\n${teks}`, MessageType.text, rtimebro)
					break
					case 'joox':
                                        if (!isUser) return reply(mess.only.daftarB)
                                        if (args.length < 1) return reply(`Kirim perintah ${prefix}joox teks\nContoh : ${prefix}joox savior`)
                                        if (isLimit(sender)) return
					data = await fetchJson(`https://tobz-api.herokuapp.com/api/joox?q=${body.slice(6)}&apikey=BotWeA`, {method: 'get'})
					teks = '-「 *Play Musik From Joox* 」-\n'
					const joox = data.result
						teks += `\n- *Judul* : ${joox.title}\n- *Album* : ${joox.album}\n- *Publish At* : ${joox.dipublikasi}\n\n_*Musik sedang dikirim,mungkin butuh waktu beberapa menit*_`
					thumb = await getBuffer(joox.thumb)
					client.sendMessage(from, thumb, image, {quoted: mek, caption: teks})
					buffer = await getBuffer(joox.mp3)
					client.sendMessage(from, buffer, audio, {mimetype: 'audio/mp4', filename: `${joox.title}.mp3`, quoted: mek})
                                        limitAdd(sender)
					break
					case 'play':
						var itsme = `${numbernye}@s.whatsapp.net`
						var split = `𝙋𝙡𝙖𝙮 𝙎𝙤𝙣𝙜 𝙁𝙧??𝙢 𝙔𝙤𝙪𝙩𝙪𝙗𝙚`
						var selepbot = {
						contextInfo: {
						participant: itsme,
						quotedMessage: {
						extendedTextMessage: {
						text: split,
										}
									}
								}
							}
                                                if (!isUser) return reply(mess.only.daftarB)
                                                if (args.length < 1) return client.sendMessage(from, `Kirim perintah ${prefix}play teks\nContoh : ${prefix}play savior`, MessageType.text, selepbot)
                                                //if (!isOwner && !mek.key.fromMe && !isPrem) return reply(mess.only.premium)                              
                                                if (isLimit(sender)) return
						data = await fetchJson(`https://api.vhtear.com/ytmp3?query=${body.slice(6)}&apikey=${vhtearkey}`, {method: 'get'})
						teks = '-「 *Play Musik From Youtubes* 」-\n'
						const play = data.result
							teks += `\n- *Judul* : ${play.title}\n- *Durasi* : ${play.duration}\n- *Size* : ${play.size}\n- *Link* : ${play.mp3}\n\n_*Musik sedang dikirim,mungkin butuh waktu beberapa menit.*_`
						thumb = await getBuffer(play.image)
						client.sendMessage(from, thumb, image, {quoted: mek, caption: teks})
						buffer = await getBuffer(play.mp3)
						client.sendMessage(from, buffer, audio, {mimetype: 'audio/mp4', filename: `${play.title}.mp3`, quoted: mek})
                                                limitAdd(sender)
						break
                                                 case 'play2':
						var itsme = `${numbernye}@s.whatsapp.net`
						var split = `𝙋𝙡𝙖𝙮 𝙎𝙤𝙣𝙜 𝙁𝙧𝙤𝙢 𝙔𝙤𝙪𝙩𝙪𝙗𝙚`
						var selepbot = {
						contextInfo: {
						participant: itsme,
						quotedMessage: {
						extendedTextMessage: {
						text: split,
										}
									}
								}
							}
                                                if (!isUser) return reply(mess.only.daftarB)
                                                if (args.length < 1) return client.sendMessage(from, `Kirim perintah ${prefix}play teks\nContoh : ${prefix}play savior`, MessageType.text, selepbot)
                                                if (isLimit(sender)) return
						data = await fetchJson(`https://api.zeks.xyz/api/ytplaymp3?q=${body.slice(6)}&apikey=apivinz`, {method: 'get'})
						teks = '-「 *Play Musik From Youtubes* 」-\n'
						const playy = data.result
							teks += `\n- *Judul* : ${playy.title}\n- *Durasi* : ${playy.duration}\n- *Size* : ${playy.size}\n\n_*Musik sedang dikirim,mungkin butuh waktu beberapa menit.*_`
						thumb = await getBuffer(playy.image)
						client.sendMessage(from, thumb, image, {quoted: mek, caption: teks})
						buffer = await getBuffer(playy.mp3)
						client.sendMessage(from, buffer, audio, {mimetype: 'audio/mp4', filename: `${play.title}.mp3`, quoted: mek})
                                                limitAdd(sender)
						break
						case 'pinterest':
							var itsme = `${numbernye}@s.whatsapp.net`
							var split = `𝙎𝙚𝙖𝙧𝙘𝙝𝙞𝙣𝙜 𝙄𝙢𝙖𝙜𝙚 _*From Pinterest*_`
							var selepbot = {
							contextInfo: {
							participant: itsme,
							quotedMessage: {
							extendedTextMessage: {
							text: split,
											}
										}
									}
								}
                                                          if (!isUser) return reply(mess.only.daftarB)
                                                        	if (args.length < 1) return client.sendMessage(from, `Kirim perintah ${prefix}pinterest teks\nContoh : ${prefix}pinterest eren`, MessageType.text, selepbot)
                                                         if (isLimit(sender)) return
							const papapale = body.slice(11)
							data = await fetchJson(`https://api.vhtear.com/pinterest?query=${body.slice(11)}&apikey=${vhtearkey}`, {method: 'get'})
							if (data.error) return reply(data.error)
							for (let i of data.result) {
								const amsulah = data.result
								const pimterest = amsulah[Math.floor(Math.random() * amsulah.length)]
								thumb = await getBuffer(pimterest)
							}
							client.sendMessage(from, thumb, image, selepbot)
                                                        limitAdd(sender)
							break
                                                       case 'googleimage':
							var itsme = `${numbernye}@s.whatsapp.net`
							var split = `_*Searching Image From Google*_`
							var selepbot = {
							contextInfo: {
							participant: itsme,
							quotedMessage: {
							extendedTextMessage: {
							text: split,
											}
										}
									}
								}
                                                       if (!isUser) return reply(mess.only.daftarB)
                                                        	if (args.length < 1) return client.sendMessage(from, `Kirim perintah ${prefix}googleimage teks\nContoh : ${prefix}googleimage eren`, MessageType.text, selepbot)
                                                        if (isLimit(sender)) return
							const pappapale = body.slice(11)
							data = await fetchJson(`https://api.vhtear.com/pinterest?query=${body.slice(11)}&apikey=${vhtearkey}`, {method: 'get'})
							if (data.error) return reply(data.error)
							for (let i of data.result) {
								const amsulah = data.result
								const pimterest = amsulah[Math.floor(Math.random() * amsulah.length)]
								thumb = await getBuffer(pimterest)
							}
							client.sendMessage(from, thumb, image, selepbot)
                                                        limitAdd(sender)
							break
                                                       case 'delete':
                                                       case 'unsend':
                                                       if (!isUser) return reply(mess.only.daftarB)
                                                       if (!isOwner && !mek.key.fromMe && !isGroupAdmins) return reply(mess.only.admin)
                                                      if (!isGroup) return reply(mess.only.group)
				try {
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply(mess.only.replyB)
					    if (isGroupAdmins || isOwner && mek.message.extendedTextMessage.contextInfo.participant === client.user.jid){
				            client.deleteMessage(from, {id: mek.message.extendedTextMessage.contextInfo.stanzaId, remoteJid: from, fromMe: true})
				                   } else {
					                           reply(mess.only.admin)
					                   }
				       } catch (e){
					         reply(mess.only.admin)
					}
				break 
                                                       case 'tiktok2': 
                                        if (!isUser) return reply(mess.only.daftarB)
					if (args.length < 1) return reply(`Kirim perintah ${prefix}tiktok link\nContoh : ${prefix}tiktok https://vt.tiktok.com/ZSwsQCgN/`)
                                        if (isLimit(sender)) return
					if (!isUrl(args[0]) && !args[0].includes('tiktok.com')) return reply(mess.error.Iv)
					//reply(mess.wait)
					anu = await fetchJson(`https://mhankbarbar.tech/api/tiktok?url=${args[0]}&apiKey=${barbarkey}`, {method: 'get'})
					if (anu.error) return reply(anu.error)
					buffer = await getBuffer(anu.result)
					client.sendMessage(from, buffer, video, {quoted: mek})
                                        limitAdd(sender)
					break
                               /*case 'tiktok':
				//if (isBanned) return reply(mess.only.benned)    
				if (!isUser) return reply(mess.only.userB)
				if (isLimit(sender)) return 
					if (args.length < 1) return reply('Urlnya mana gan?')
					if (!isUrl(args[0]) && !args[0].includes('tiktok.com')) return reply(mess.error.Iv)
					//reply(mess.wait)
					anu = await fetchJson(`https://api.vhtear.com/tiktokdl?link=${args[0]}&apikey=${vhtearkey}`, {method: 'get'})
					if (anu.error) return reply(anu.error)
					buffer = await getBuffer(anu.result)
					client.sendMessage(from, buffer, video, {quoted: mek})
					limitAdd(sender)
					break*/
				case 'nulis2': 
				case 'tulis':
                                        if (!isUser) return reply(mess.only.daftarB)
					if (args.length < 1) return reply('𝗧𝗲𝗸𝘀𝗻𝘆𝗮 𝗺𝗮??𝗮 𝘁𝗲𝗸𝘀?')
                                        if (isLimit(sender)) return
					teks = body.slice(7)
					//reply(mess.wait)
					anu = await fetchJson(`https://mhankbarbar.tech/nulis?text=${teks}&apiKey=${barbarkey}`, {method: 'get'})
					if (anu.error) return reply(anu.error)
					bufffff = await getBuffer(anu.result)
					client.sendMessage(from, bufffff, image, {quoted: mek, caption: mess.success})
                                        limitAdd(sender)
					break
                                  case 'readall':
                                          if (!isUser) return reply(mess.only.daftarB)
					if (!isOwner) return reply('Fitur ini hanya untuk owner')
					var chhats= await client.chats.all()
                    chhats.map( async ({ jid }) => {
                          await client.chatRead(jid)
                    })
					teks = `\`\`\`Berhasil membaca ${chhats.length} Chat !\`\`\``
					await client.sendMessage(from, teks, MessageType.text, {quoted: mek})
					console.log(chats.length)
					break
                                       case 'setstatus':
                                if (!isUser) return reply(mess.only.daftarB)
                                if (!isOwner) return reply('Fitur ini hanya untuk owner')
				client.setStatus(`${body.slice(10)}`)
   				.then(data => {
        			reply('Status berhasil diubah')
    				}).catch(err => console.log(err))
    				break
                                    case 'fordward2':
                                    if (isGroup) return reply('Fitur ini hanya bisa digunakan di private chat')
                                   if (!isUser) return reply(mess.only.daftarB)
                                   if (args.length < 1) return reply(`Kirim perintah ${prefix}fordward2 teks\nContoh : ${prefix}fordward2 Bagas gans`)
                                   if (isLimit(sender)) return
	   client.sendMessage(from, `${body.slice(10)}`, MessageType.text, {contextInfo: { forwardingScore: 508, isForwarded: true }})
           limitAdd(sender)
           break
            case 'fordward':
             if (isGroup) return reply('Fitur ini hanya bisa digunakan di private chat')
            if (!isUser) return reply(mess.only.daftarB)
            if (args.length < 1) return reply(`Kirim perintah ${prefix}fordward teks\nContoh : ${prefix}fordward Bagas gans`)
            if (isLimit(sender)) return
           client.sendMessage(from, `${body.slice(10)}`, MessageType.text, {contextInfo: { forwardingScore: 2, isForwarded: true }})
           limitAdd(sender)
           break
                                  case 'randomquran':
                        if (!isUser) return reply(mess.only.daftarB)
                         if (isLimit(sender)) return
			data = await fetchJson(`https://api.zeks.xyz/api/randomquran`)
			teks = `Nama: ${data.result.nama}\nArti: ${data.result.arti}\nayat: ${data.result.ayat}\nAsma: ${data.result.asma}\nRukuk: ${data.result.rukuk}\nNomor: ${data.result.nomor}\nType: ${data.result.type}\nKeterangan: ${data.result.keterangan}`
			buffs = await getBuffer(data.result.audio)
			client.sendMessage(from, `${teks}`, MessageType.text, {quoted: mek})
			client.sendMessage(from, buffs, audio, {mimetype: 'audio/mp4', filename: `quran.mp3`, quoted: mek})
                        limitAdd(sender)
			break
                        case 'puisi':
                     if (!isUser) return reply(mess.only.daftarB)
                     if (isLimit(sender)) return
                buuuuff = await getBuffer(`https://api.vhtear.com/puisi_image&apikey=${vhtearkey}`)
				client.sendMessage(from, buuuuff, image, {quoted: mek})
                              limitAdd(sender)
				break
		case 'kapankah':
                                        if (!isUser) return reply(mess.only.daftarB)
                                        if (args.length < 1) return reply(`Kirim perintah ${prefix}kapankah pertanyaan`)
					const kapan1 = body.slice(1)
					const kapan2 = [
					'Hari ini',

					'Mungkin besok',

					'1 Minggu lagi',

					'Masih lama',

					'3 Bulan lagi',

					'7 Bulan lagi',

					'3 Tahun lagi',

					'4 Bulan lagi',

					'2 Bulan lagi',

					'1 Tahun lagi',

					'1 Bulan lagi',

					'Coba ulangi',

					]

					const kpnkh = kapan2[Math.floor(Math.random() * (kapan2.length))]
					const jawab1 = `Pertanyaan : *${kapan1}*\n\nJawaban: ${kpnkh}`
					client.sendMessage(from, jawab1, text, {quoted: mek})
					break
                        case 'bolehkah':
                client.updatePresence(from, Presence.composing) 
              if (!isUser) return reply(mess.only.daftarB)
              if (args.length < 1) return reply(`Kirim perintah ${prefix}bolehkah pertanyaan`)
              const bolehkah = ['Boleh','Tidak boleh','Iya','Sangat di anjurkan','Tidak','Mingkin','Mungkin tidak','Jangan','Tentu saja','Coba tanyakan lagi']
                random = bolehkah[Math.floor(Math.random() * (bolehkah.length))]
  	
			   hasil = `Pertanyaan : *${body.slice(1)}*\n\nJawaban : *${random}*`
			   reply(hasil)
			   break
               case 'rate':
              client.updatePresence(from, Presence.composing) 
              if (!isUser) return reply(mess.only.daftarB)
              if (args.length < 1) return reply(`Kirim perintah ${prefix}rate teks`)
                random = `${Math.floor(Math.random() * 100)}`
               hasil = `Pertanyaan : *${body.slice(1)}*\n\nJawaban : *${random}%*`
              reply(hasil)
                break
			case 'apakah':
                                        if (!isUser) return reply(mess.only.daftarB)
                                        if (args.length < 1) return reply(`Kirim perintah ${prefix}apakah pertanyaan`)
					const tanya = body.slice(1)
					const apa = [
					'Ya',

					'Mungkin',

					'Tidak',

					'Coba Ulangi',

					]

					const apkh = apa[Math.floor(Math.random() * (apa.length))]

					const jawab = `Pertanyaan : *${tanya}*\n\nJawaban: ${apkh}`

					client.sendMessage(from, jawab, text, {quoted: mek})
					break
			    case 'darkjoke':
                                if (!isUser) return reply(mess.only.daftarB)
                                if (isLimit(sender)) return
                                data = await fetchJson(`https://api.zeks.xyz/api/darkjokes?apikey=${zekskey}`)
                                dark = data.result
                                thumb = await getBuffer(dark)
                                client.sendMessage(from, thumb, image, {quoted: mek})
                                limitAdd(sender)
                                break
                                 case 'lovetext':
                                if (!isUser) return reply(mess.only.daftarB)
                                if (args.length < 1) return reply(`Kirim perintah ${prefix}lovetext teks\nContoh : ${prefix}lovetext bagas`)
                                if (isLimit(sender)) return
                bruuff = await getBuffer(`https://api.vhtear.com/lovemessagetext?text=${body.slice(10)}&apikey=${vhtearkey}`)
				client.sendMessage(from, bruuff, image, {quoted: mek})
                                limitAdd(sender)
				break
                              case 'holoh': 
                                        if (!isUser) return reply(mess.only.daftarB)
					if (args.length < 1) return reply(`Kirim perintah ${prefix}holoh teks\nContoh : ${prefix}holoh Bagas gans`)
                                        if (isLimit(sender)) return
					anu = await fetchJson(`https://shirayuki-api.herokuapp.com/api/v1/holoh?kata=${body.slice(7)}`, {method: 'get'})
					reply(anu.result)
                                        limitAdd(sender)
					break
                                   case 'ytsearch': 
                                        if (!isUser) return reply(mess.only.daftarB)
					if (args.length < 1) return reply(`Kirim perintah ${prefix}ytsearch teks\nContoh ${prefix}ytsearch Gustixa terpesona`)
                                        if (isLimit(sender)) return
					anu = await fetchJson(`https://mhankbarbar.tech/api/ytsearch?q=${body.slice(10)}&apiKey=${barbarkey}`, {method: 'get'})
					if (anu.error) return reply(anu.error)
					teks = '=================\n'
					for (let i of anu.result) {
						teks += `*Title* : ${i.title}\n*Channel* : ${i.channel}\n*Id* : ${i.id}\n*Published* : ${i.publishTime}\n*Duration* : ${i.duration}\n*Views* : ${h2k(i.views)}\n*Link* : ${i.link}\n=================\n`
					}
					reply(teks.trim())
                                        limitAdd(sender)
					break
				case 'hilih':
                                        if (!isUser) return reply(mess.only.daftarB)
					if (args.length < 1) return reply(`Kirim perintah ${prefix}hilih teks\nContoh : ${prefix}hilih Bagas gans`)
                                        if (isLimit(sender)) return
					anu = await fetchJson(`https://mhankbarbar.tech/api/hilih?teks=${body.slice(7)}`, {method: 'get'})
					reply(anu.result)
                                        limitAdd(sender)
					break
                                 case 'yt2mp3':
                                        if (!isUser) return reply(mess.only.daftarB)
					if (args.length < 1) return reply('Urlnya mana um?')
                                        if (isLimit(sender)) return
					if(!isUrl(args[0]) && !args[0].includes('youtu')) return reply(mess.error.Iv)
					anu = await fetchJson(`https://mhankbarbar.tech/api/yta?url=${args[0]}&apiKey=${barbarkey}`, {method: 'get'})
					if (anu.error) return reply(anu.error)
					teks += `*Title* : ${anu.title}\n*Filesize* : ${anu.filesize}`
					thumb = await getBuffer(anu.thumb)
					client.sendMessage(from, thumb, image, {quoted: mek, caption: teks})
					buffer = await getBuffer(anu.result)
					client.sendMessage(from, buffer, audio, {mimetype: 'audio/mp4', filename: `${anu.title}.mp3`, quoted: mek})
                                        limitAdd(sender)
					break
                                          case 'yt2mp4': 
                                        if (!isUser) return reply(mess.only.daftarB)
					if (args.length < 1) return reply('𝘂𝗿𝗹𝗻𝘆𝗮 𝗺𝗮𝗻𝗮?')
                                        if (isLimit(sender)) return
					if(!isUrl(args[0]) && !args[0].includes('youtube.com')) return reply(mess.error.Iv)
					anu = await fetchJson(`https://mhankbarbar.tech/api/ytv?url=${args[0]}&apiKey=${barbarkey}`, {method: 'get'})
					if (anu.error) return reply(anu.error)
					teks += `*Title* : ${anu.title}\n*Filesize* : ${anu.filesize}`
					thumb = await getBuffer(anu.thumb)
					client.sendMessage(from, thumb, image, {quoted: mek, caption: teks})
					buffer = await getBuffer(anu.result)
					client.sendMessage(from, buffer, video, {mimetype: 'video/mp4', filename: `${anu.title}.mp4`, quoted: mek})
                                        limitAdd(sender)
					break
				case 'setppgc': 
                       if (!isUser) return reply(mess.only.daftarB)
                       if (!isGroup) return reply(mess.only.group)
                       if (!isOwner && !mek.key.fromMe && !isGroupAdmins) return reply(mess.only.admin)
		       if (!isBotGroupAdmins) return reply(mess.only.Badmin)
                       media = await client.downloadAndSaveMediaMessage(mek)
                         await client.updateProfilePicture (from, media)
                        reply('𝗦𝘂𝗸𝘀𝗲𝘀 𝗺??𝗻𝗴𝗴??𝗻𝘁𝗶 𝗶𝗰𝗼𝗻 𝗚𝗿𝘂𝗽')
                                        break	
                 /*case 'tagall2':
                                       if (!isUser) return reply(mess.only.daftarB)
                                       if (!isGroup) return reply(mess.only.group)
                                       if (!isGroupAdmins) return reply(mess.only.admin)
					members_id = []
					teks = (args.length > 1) ? body.slice(8).trim() : ''
					teks += '\n\n'
					for (let mem of groupMembers) {
						teks += `╠➥ https://wa.me/${mem.jid.split('@')[0]}\n`
						members_id.push(mem.jid)
					}
					client.sendMessage(from, teks, text, {detectLinks: false, quoted: mek})
					break*/
                                      /*case 'ytmp3':
						var itsme = `${numbernye}@s.whatsapp.net`
						var split = `𝙋𝙡𝙖𝙮 𝙎𝙤𝙣𝙜 𝙁𝙧𝙤𝙢 𝙔𝙤𝙪𝙩𝙪𝙗𝙚`
						var selepbot = {
						contextInfo: {
						participant: itsme,
						quotedMessage: {
						extendedTextMessage: {
						text: split,
										}
									}
								}
							}
                                                if (!isUser) return reply(mess.only.daftarB)
                                                if (args.length < 1) return client.sendMessage(from, `Urlnya mana um?`, MessageType.text, selepbot)
                                                if (isLimit(sender)) return
                                                //if(!isUrl(args[0]) && !args[0].includes('youtu')) return reply(mess.error.Iv)
						data = await fetchJson(`https://api.vhtear.com/ytmp3?query=${body.slice(6)}&apikey=${vhtearkey}`, {method: 'get'})
						teks = '-「 *Downloader Musik From Youtubes* 」-\n'
						const platy = data.result
							teks += `\n- *Judul* : ${platy.title}\n- *Durasi* : ${platy.duration}\n- *Size* : ${platy.size}\n\n_*Musik sedang dikirim,mungkin butuh waktu beberapa menit.*_`
						thumb = await getBuffer(platy.image)
						client.sendMessage(from, thumb, image, {quoted: mek, caption: teks})
						buffer = await getBuffer(platy.mp3)
						client.sendMessage(from, buffer, audio, {mimetype: 'audio/mp4', filename: `${platy.title}.mp3`, quoted: mek})
                                                limitAdd(sender)
						break*/
                                                case 'ytmp3':
                                        if (!isUser) return reply(mess.only.daftarB)
                                                if (args.length < 1) return reply('Urlnya mana um?')
                                        if (isLimit(sender)) return 
					if(!isUrl(args[0]) && !args[0].includes('youtu')) return reply(mess.error.Iv)
					data = await fetchJson(`https://api.vhtear.com/ytdl?link=${args[0]}&apikey=${vhtearkey}`, {method: 'get'})
						teks = '-「 *Downloader Musik From Youtubes* 」-\n'
						const ytmp44 = data.result
							teks += `*Title* : ${ytmp44.title}\n *Size* : ${ytmp44.size}\n *Link* : ${ytmp44.UrlMp3}\n\n_*Audio sedang dikirim,mungkin butuh waktu beberapa menit*_`
						thumb = await getBuffer(ytmp44.imgUrl)
						client.sendMessage(from, thumb, image, {quoted: mek, caption: teks})
						buffer = await getBuffer(ytmp44.UrlMp3)
						client.sendMessage(from, buffer, audio, {mimetype: 'audio/mp4', filename: `${ytmp44.title}.mp3`, quoted: mek})
                                                limitAdd(sender)
					break
					case 'readme':
					 reply(`═══ ?? *README* 𒍮 ═══

✪  Sebelum menggunakan bot pastikan kamu sudah terdaftar.
✪  Jika belum, kamu dapat mendaftar dengan cara ketik ${prefix}daftar nama|umur
✪  Jika sudah terdaftar, silahkan baca rules dengan mengirimkan ${prefix}rules.
✪  Lalu untuk menampilkan menu silahkan kirim ${prefix}help atau ${prefix}menu untuk melihat semua fitur.
✪  Dilarang keras untuk spam dan call bot atau kamu akan diblokir.
✪  Bot memiliki limit bulanan sebanyak 100.
✪  Limit adalah banyak request untuk menggunakan bot, sederhananya kamu tidak dapat menggunakan bot jika limit kamu habis.
✪  Gimana untuk membuat sticker?
	✪  Jika media kamu berupa gambar silahkan kirim gambar atau reply gambar dengan caption ${prefix}sticker
	✪  Jika media berupa video/gif silahkan kirim video atau reply video dengan caption ${prefix}stickergif
✪  Bagaimana kalau bot tidak menjawab?
	✪  Apabila bot tidak menjawab, ada kemungkinan sedang terjadi delay atau bot sedang offline atau nomor bot terblokir
	✪ Makanya itu join gc bot ya,untuk mendapatkan link group bot ketik ${prefix}botgroup.
	✪  Yang penting jangan spam bot
	
═══ 《 *Araa Bot* 》 ═══`)
break
                                        case 'rules':
                                        reply(`
*RULES BAGI PENGGUNA BOT*
    
➤ Tolong Gunakan Delay Jangan Spam Saat Menggunakan Bot, Mentang Mentang Gratis Diborong semua.
➤ Jangan Call/VC Bot Kalau Tidak aktif.

*Konsekuensi Bila Melanggar Rules*
Bot Akan Memblokir Kamu Atau Keluar Dari Grup Yang Kamu Kelola.

Rules ini untuk kenyamanan semua yang memakai
bot ini 
1. Jangan spam bot. 
Sanksi: *WARN/SOFT BLOCK*

2. Jangan telepon bot.
Sanksi: *SOFT BLOCK*

3. Jangan mengeksploitasi bot.
Sanksi: *PERMANENT BLOCK*

Jika sudah dipahami rules-nya, silakan ketik *${prefix}menu* untuk memulai!`)
                                         break
                                              case'ig':
                                              case 'instagram':
                                                 if (!isUser) return reply(mess.only.daftarB)
                                                 if (args.length < 1) return reply(`Kirim perintah ${prefix}ig link\nContoh : ${prefix}ig https://www.instagram.com/p/CKOIH31l_f1/?igshid=plsducyhiy3k`)
                                                 if (isLimit(sender)) return
                                                  if(!isUrl(args[0]) && !args[0].includes('instagram.com')) return
                                                 reply('Sedang di proses,jika tidak bisa berarti server sedang eror atau akunnya private')
                                                 anu = await fetchJson(`https://mhankbarbar.tech/api/ig?url=${args[0]}&apiKey=${barbarkey}`, {method: 'get'})
                                                 if (anu.error) return reply('Terjadi kesalahan,mungkin server sedang eror atau akunnya private')
                                                buffer = await getBuffer(anu.result)
                                                 client.sendMessage(from, buffer, video, {mimetype: 'video/mp4', quoted: mek})
                                                limitAdd(sender)
                                                 //if (anu.error) return reply('Terjadi kesalahan,mungkin karna akunnya private')
                                          break
                                                case 'fb':
                                                case 'facebook':
                                                 if (!isUser) return reply(mess.only.daftarB)
                                                 if (args.length < 1) return reply(`Kirim perintah ${prefix}fb link\nContoh : ${prefix}fb https://www.facebook.com/NasDailyBahasaIndonesia/videos/2640143126240530/`)
                                                 if (isLimit(sender)) return
                                                if(!isUrl(args[0]) && !args[0].includes('facebook.com')) return
                                                 //reply('Sedang di proses,jika tidak bisa berarti server sedang eror atau akunnya private')
                                                 anu = await fetchJson(`https://mhankbarbar.tech/api/epbe?url=${args[0]}&apiKey=${barbarkey}`, {method: 'get'})
                                                 if (anu.error) return reply('Terjadi kesalahan,mungkin server sedang eror atau akunnya private')
                                                buffer = await getBuffer(anu.result)
                                                client.sendMessage(from, buffer, video, {mimetype: 'video/mp4', quoted: mek})
                                                 limitAdd(sender)
                                          break
                                                case 'ytmp4':
                                        if (!isUser) return reply(mess.only.daftarB)
                                                if (args.length < 1) return reply('Urlnya mana um?')
                                        if (isLimit(sender)) return 
					if(!isUrl(args[0]) && !args[0].includes('youtu')) return reply(mess.error.Iv)
					data = await fetchJson(`https://api.vhtear.com/ytdl?link=${args[0]}&apikey=${vhtearkey}`, {method: 'get'})
						teks = '-「 *Downloader From Youtubes* 」-\n'
						const ytmp4 = data.result
							teks += `*Title* : ${ytmp4.title}\n- *Size* : ${ytmp4.size}\n *Link Download* : ${ytmp4.UrlVideo}`
						thumb = await getBuffer(ytmp4.imgUrl)
						client.sendMessage(from, thumb, image, {quoted: mek, caption: teks})
						buffer = await getBuffer(ytmp4.UrlVideo)
						client.sendMessage(from, buffer, video, {mimetype: 'video/mp4', filename: `${ytmp4.title}.mp4`, quoted: mek})
                                                limitAdd(sender)
					break
             case 'nulis':
            if (!isUser) return reply(mess.only.daftarB)
                if (args.length < 1) return reply(`Kirim perintah ${prefix}nulis2 nama|kelas|text\nContoh : ${prefix}nulis2 Bagas|9A|Gatau apa dah`)
                if (isLimit(sender)) return 
				var mnulis = body.slice(8)

				var mnama = mnulis.split('|')[0]

				var mkelas = mnulis.split('|')[1]

				var mtext = mnulis.split('|')[2]

				var mtinta = mnulis.split('|')[3]

				reply('Tunggu sebentar....')

				data = await getBuffer(`https://api.zeks.xyz/api/magernulis?nama=${mnama}&kelas=${mkelas}&text=${mtext}&tinta=${mtinta}`)

				tesk = `=> Nama : ${mnama}\n=> Kelas : ${mkelas}\n\n_By Bot R_`

				client.sendMessage(from, data, image, {quoted: mek, caption: tesk})

				await limitAdd(sender)
				break
                case 'truth':
                                        if (!isUser) return reply(mess.only.daftarB)
                                        if (isLimit(sender)) return
					const trut =['Pernah suka sama siapa aja? berapa lama?','Kalau boleh atau kalau mau, di gc/luar gc siapa yang akan kamu jadikan sahabat?(boleh beda/sma jenis)','apa ketakutan terbesar kamu?','pernah suka sama orang dan merasa orang itu suka sama kamu juga?','Siapa nama mantan pacar teman mu yang pernah kamu sukai diam diam?','pernah gak nyuri uang nyokap atau bokap? Alesanya?','hal yang bikin seneng pas lu lagi sedih apa','pernah cinta bertepuk sebelah tangan? kalo pernah sama siapa? rasanya gimana brou?','pernah jadi selingkuhan orang?','hal yang paling ditakutin','siapa orang yang paling berpengaruh kepada kehidupanmu','hal membanggakan apa yang kamu dapatkan di tahun ini','siapa orang yang bisa membuatmu sange','siapa orang yang pernah buatmu sange','(bgi yg muslim) pernah ga solat seharian?','Siapa yang paling mendekati tipe pasangan idealmu di sini','suka mabar(main bareng)sama siapa?','pernah nolak orang? alasannya kenapa?','Sebutkan kejadian yang bikin kamu sakit hati yang masih di inget','pencapaian yang udah didapet apa aja ditahun ini?','kebiasaan terburuk lo pas di sekolah apa?']
					const ttrth = trut[Math.floor(Math.random() * trut.length)]
					truteh = await getBuffer(`https://i.ibb.co/305yt26/bf84f20635dedd5dde31e7e5b6983ae9.jpg`)
					client.sendMessage(from, truteh, image, { caption: '*Truth*\n\n'+ ttrth, quoted: mek })
                                        limitAdd(sender)
					break
				/*case 'dare':
                                        if (!isUser) return reply(mess.only.daftarB)
                                        if (isLimit(sender)) return
					const dare =['Kirim pesan ke mantan kamu dan bilang "aku masih suka sama kamu','telfon crush/pacar sekarang dan ss ke pemain','pap ke salah satu anggota grup','Bilang "KAMU CANTIK BANGET NGGAK BOHONG" ke cowo','ss recent call whatsapp','drop emot "🦄💨" setiap ngetik di gc/pc selama 1 hari','kirim voice note bilang can i call u baby?','drop kutipan lagu/quote, terus tag member yang cocok buat kutipan itu','pake foto sule sampe 3 hari','ketik pake bahasa daerah 24 jam','ganti nama menjadi "gue anak lucinta luna" selama 5 jam','chat ke kontak wa urutan sesuai %batre kamu, terus bilang ke dia "i lucky to hv you','prank chat mantan dan bilang " i love u, pgn balikan','record voice baca surah al-kautsar','bilang "i hv crush on you, mau jadi pacarku gak?" ke lawan jenis yang terakhir bgt kamu chat (serah di wa/tele), tunggu dia bales, kalo udah ss drop ke sini','sebutkan tipe pacar mu!','snap/post foto pacar/crush','teriak gajelas lalu kirim pake vn kesini','pap mukamu lalu kirim ke salah satu temanmu','kirim fotomu dengan caption, aku anak pungut','teriak pake kata kasar sambil vn trus kirim kesini','teriak " anjimm gabutt anjimmm " di depan rumah mu','ganti nama jadi " BOWO " selama 24 jam','Pura pura kerasukan, contoh : kerasukan maung, kerasukan belalang, kerasukan kulkas, dll']
					const der = dare[Math.floor(Math.random() * dare.length)]
					tod = await getBuffer(`https://i.ibb.co/305yt26/bf84f20635dedd5dde31e7e5b6983ae9.jpg`)
					client.sendMessage(from, tod, image, { quoted: mek, caption: '*Dare*\n\n'+ der })
                                        limitAdd(sender)
					break*/
				case 'setreply':
				case 'setfake':
                                        var itsme = `${numbernye}@s.whatsapp.net`
					var split = `${fake}`
					// var taged = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
					const fakke = {
					contextInfo: {
					participant: itsme,
					quotedMessage: {
					extendedTextMessage: {
					text: split,
									}
								}
							}
						}
                                        if (!isUser) return reply(mess.only.daftarB)
                                        if (!isOwner) return reply('Fitur ini hanya untuk owner')
					if (args.length < 1) return client.sendMessage(from, `Kirim perintah ${prefix}setprely teks\nContoh : ${prefix} _*WhatsApp-SelfBot*_`, MessageType.text, fakke)
					fake = args[0]
					client.sendMessage(from, `berhasil ubah Fake reply menjadi : ${fake}`, MessageType.text, fakke)
					break
                                        case 'shop':
                                          if (!isUser) return reply(mess.only.daftarB)
                                        reply(`Your Info
 ❏ Nama : ${pushname}
 ❏ Balance : $${checkATMuser(sender)}

Game Shop
 ❏ ${prefix}buylimit 1 [harga: $1000]
 ❏ ${prefix}buylimit 10 [harga: $10000]
 ❏ ${prefix}buylimit 20 [harga: $20000]
 ❏ ${prefix}buylimit 30 [harga: $30000]
 ❏ ${prefix}buylimit 40 [harga: $40000]
 ❏ ${prefix}buylimit 50 [harga: $50000]

NB : Limit berlaku selama sebulan full`)
                                       break
                                        case 'chord':
                                        if (!isUser) return reply(mess.only.daftarB)
					if (args.length < 1) return reply(`Kirim perintah ${prefix}chord teks\nContoh : ${prefix}chord senja`)
					  if (isLimit(sender)) return
					tels = body.slice(7)					
					anu = await fetchJson(`https://arugaz.herokuapp.com/api/chord?q=${tels}`, {method: 'get'})
					reply(anu.result)
					limitAdd(sender)
					break
                                        /*case 'lirik':
                                        if (!isUser) return reply(mess.only.daftarB)
					if (args.length < 1) return reply(`Kirim perintah ${prefix}lirik teks\nContoh : ${prefix}lirik story of my life`)
					  if (isLimit(sender)) return
					tels = body.slice(7)
					anu = await fetchJson(`https://arugaz.herokuapp.com/api/lirik?judul=${tels}`, {method: 'get'})
					reply(anu.result)
					limitAdd(sender)
					break*/
					case 'lirik':
                                //if (!isRegistered && !ben.key.fromMe) return reply(mess.only.Registered)
                                tekss = body.slice(7)
                                anu = await fetchJson(`https://scrap.terhambar.com/lirik?word=${tekss}`, {method: 'get'})
                                teks = `- *Lagu* : ${tekss}\n- *Lirik* : ${anu.result.lirik}`
                                client.sendMessage(from, teks, text, { quoted: mek})
                                break
                                        case 'infonomor':
               client.updatePresence(from, Presence.composing) 
                 if (!isUser) return reply(mess.only.daftarB)
                 if (args.length < 1) return reply(`Masukan Nomor\nContoh : ${prefix}infonomor 085717337679`)
                   if (isLimit(sender)) return
                data = await fetchJson(`https://docs-jojo.herokuapp.com/api/infonomor?no=${body.slice(11)}`)
                if (data.error) return reply(data.error)
                if (data.result) return reply(data.result)
                hasil = `╠➥ nomor : ${data.nomor}\n╠➥ operator : ${data.op}`
                reply(hasil)
                limitAdd(sender)
                break
                                       /*case 'artinama':
                 if (!isUser) return reply(mess.only.daftarB)
                   if (isLimit(sender)) return
                  client.updatePresence(from, Presence.composing) 
                    data = await fetchJson(`https://arugaz.herokuapp.com/api/artinama?nama=${body.slice(10)}`)
                   reply(data.result)
                   limitAdd(sender)
                   break*/
                                       /*case 'wiki':
                                       if (!isUser) return reply(mess.only.daftarB)
					if (args.length < 1) return reply(`Kirim perintah ${prefix}wiki teks\nContoh${prefix}wiki Albert Einstein`)
					  if (isLimit(sender)) return
					tels = body.slice(6)				
					anu = await fetchJson(`https://tobz-api.herokuapp.com/api/wiki?q=${tels}&apikey=BotWeA`, {method: 'get'})
					reply(anu.result)
					limitAdd(sender)
					break*/	
				case 'setnumber':
                                        var itsme = `${numbernye}@s.whatsapp.net`
					var split = `${fake}`
					// var taged = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
					const nummber = {
					contextInfo: {
					participant: itsme,
					quotedMessage: {
					extendedTextMessage: {
					text: split,
									}
								}
							}
						}
                                        if (!isUser) return reply(mess.only.daftarB)
                                        if (!isOwner) return reply('Fitur ini hanya untuk owner')
					if (args.length < 1) return client.sendMessage(from, `Kirim perintah ${prefix}setnumber 62xxx\nContoh : ${prefix}setnumber 6285717337579`, MessageType.text, nummber)
					numbernye = args[0]
					client.sendMessage(from, `berhasil ubah Number reply menjadi : ${numbernye}`, MessageType.text, nummber)
					break
				case 'cr1':
						// licensed by aex-bot -> namabotnte
				var split = args.join(' ').replace(/@|\d/gi, '').split('|')
				var taged = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
				const target = {
				contextInfo: {
				participant: taged,
				quotedMessage: {
				extendedTextMessage: {
				text: split[0]
									}
								}
							}
						}
				client.sendMessage(from, `${split[1]}`, MessageType.text, target)
				break
				case 'settarget':
                                        var itsme = `${numbernye}@s.whatsapp.net`
					var split = `${fake}`
					// var taged = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
					const tarrget = {
					contextInfo: {
					participant: itsme,
					quotedMessage: {
					extendedTextMessage: {
					text: split,
									}
								}
							}
						}
                                        if (!isUser) return reply(mess.only.daftarB)
                                        if (!isOwner) return reply('Fitur ini hanya untuk owner')
					if (args.length < 1) return client.sendMessage(from, `Kirim perintah ${prefix}settarget 62xxx\nContoh : ${prefix}settarget 628571733769`, MessageType.text, tarrget)
					targetprivate = args[0]
					client.sendMessage(from, `Succes Mengganti target Private Fake Reply : ${targetprivate}`, MessageType.text, tarrget)
					break
				/*case 'cr2':
					jids = `${targetprivate}@s.whatsapp.net` // nomer target
					var split = args.join(' ').replace(/@|\d/gi, '').split('|')
					var taged = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
					const options = {
					contextInfo: {
					quotedMessage: {
					extendedTextMessage: {
					text: split[0]
										}
									}
								}
							}
					const responye = await client.sendMessage(jids, `${split[1]}`, MessageType.text, options)
					await client.deleteMessage (jids, {id: responye.messageID, remoteJid: jids, fromMe: true})
					break*/
					case 'kbbi':
					var itsme = `${numbernye}@s.whatsapp.net`
					var split = `${fake}`
					// var taged = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
					const kbbigan = {
					contextInfo: {
					participant: itsme,
					quotedMessage: {
					extendedTextMessage: {
					text: split,
									}
								}
							}
						}
                                        if (!isUser) return reply(mess.only.daftarB)
                                        if (args.length < 1) return client.sendMessage(from, `Kirim perintah ${prefix}kbbi teks\nContoh : ${prefix}kbbi aku`, MessageType.text, kbbigan)
                                          if (isLimit(sender)) return
					var kbbi = body.slice(6)
					axios.get(`https://tobz-api.herokuapp.com/api/kbbi?kata=${kbbi}&apikey=BotWeA`).then((res) => {
						let hasil = `「 *HASIL* 」\n${res.data.result}`;
						//client.sendMessage(from, '_Otewe !_', MessageType.text)
						client.sendMessage(from, hasil, MessageType.text, kbbigan);
						limitAdd(sender)
					})
				break
				case 'linkgc':
				case 'linkgroup':
				var itsme = `${numbernye}@s.whatsapp.net`
				var split = `${fake}`
						// var taged = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
						const linkgcgan = {
						contextInfo: {
						participant: itsme,
						quotedMessage: {
						extendedTextMessage: {
						text: split,
										}
									}
								}
							}
                                if (!isUser) return reply(mess.only.daftarB)
				if (!isGroup) return reply(mess.only.group)
				if (!isBotGroupAdmins) return reply(mess.only.Badmin)
				const linkgc = await client.groupInviteCode (from) 
				client.sendMessage(from, `https://chat.whatsapp.com/${linkgc}`, MessageType.text, linkgcgan)
				break 
                                case 'blackpink':
                                         if (!isUser) return reply(mess.only.daftarB)
                                         if (args.length < 1) return reply(`Kirim perintah ${prefix}blackpink teks\nContoh : ${prefix}blackpink Novia`)
                                         if (isLimit(sender)) return
                bf = await getBuffer(`https://api.vhtear.com/blackpinkicon?text=${body.slice(11)}&apikey=${vhtearkey}`)
				client.sendMessage(from, bf, image, {quoted: mek})
                                limitAdd(sender)
				break
                            case 'family100':
                //if (isBanned) return reply(mess.only.benned)    
				if (!isUser) return reply(mess.only.daftarB)
				if (isLimit(sender)) return 
					anu = await fetchJson(`https://api.vhtear.com/family100&apikey=${vhtearkey}`, {method: 'get'})
					family = `*${anu.result.soal}*`
					setTimeout( () => {
					client.sendMessage(from, '*➸ Jawaban :* '+anu.result.jawaban, text, {quoted: mek}) // ur cods
					}, 30000) // 1000 = 1s,
					setTimeout( () => {
					client.sendMessage(from, '_10 Detik lagi…_', text) // ur cods
					}, 20000) // 1000 = 1s,
					setTimeout( () => {
					client.sendMessage(from, '_20 Detik lagi_…', text) // ur cods
					}, 10000) // 1000 = 1s,
					setTimeout( () => {
					client.sendMessage(from, '_30 Detik lagi_…', text) // ur cods
					}, 2500) // 1000 = 1s,
					setTimeout( () => {
					client.sendMessage(from, family, text, {quoted: mek }) // ur cods
					}, 0) // 1000 = 1s,
					limitAdd(sender) 
					break 
                            case 'caklontong':
                //if (isBanned) return reply(mess.only.benned)    
				if (!isUser) return reply(mess.only.daftarB)
				if (isLimit(sender)) return 
					anu = await fetchJson(`https://api.vhtear.com/funkuis&apikey=${vhtearkey}`, {method: 'get'})
					caklontong = `*${anu.result.soal}*`
					setTimeout( () => {
					client.sendMessage(from, '*➸ Jawaban :* '+anu.result.jawaban+ '\n\n• *Penjelasan* : '+ anu.result.desk+'', text, {quoted: mek}) // ur cods
					}, 30000) // 1000 = 1s,
					setTimeout( () => {
					client.sendMessage(from, '_10 Detik lagi…_', text) // ur cods
					}, 20000) // 1000 = 1s,
					setTimeout( () => {
					client.sendMessage(from, '_20 Detik lagi_…', text) // ur cods
					}, 10000) // 1000 = 1s,
					setTimeout( () => {
					client.sendMessage(from, '_30 Detik lagi_…', text) // ur cods
					}, 2500) // 1000 = 1s,
					setTimeout( () => {
					client.sendMessage(from, caklontong, text, {quoted: mek}) // ur cods
					}, 0) // 1000 = 1s,
					limitAdd(sender) 
					break 
                            case 'quoteit':
			    //if (isBanned) return reply(mess.only.benned)
			        if (isLimit(sender)) return 
			    if (!isUser) return reply(mess.only.daftarB)
                            if (args.length < 1) return reply(`Usage: \n${prefix}quoteit teks|watermark|theme\n\nEx :\n${prefix}quoteit imkan|bagas|random`)
					gh = `${body.slice(9)}`
					quote = gh.split("|")[0];
					wm = gh.split("|")[1];
					bg = gh.split("|")[2];
					const preef = `Usage: \n${prefix}quoteit teks|watermark|theme\n\nEx :\n${prefix}quoteit bagas|imkan|random`
					if (args.length < 1) return reply(pref)
					anu = await fetchJson(`https://terhambar.com/aw/qts/?kata=${quote}&author=${wm}&tipe=${bg}`, {method: 'get'})
					buffer = await getBuffer(anu.result)
					client.sendMessage(from, buffer, image, {quoted: mek})
					limitAdd(sender) 
					break 
                            case 'igstalk':
                    //if (isBanned) return reply(mess.only.benned)    
   					if (!isUser) return reply(mess.only.daftarB)
   					if (isLimit(sender)) return
                        if (args.length < 1) return reply(`Kirim perintah ${prefix}igstalk username\nContoh : ${prefix}igstalk juicee90y`) 
                        anu = await fetchJson(`https://mhankbarbar.tech/api/stalk?username=${body.slice(9)}&apiKey=${barbarkey}`, {method: 'get'})
                     buffer = await getBuffer(anu.Profile_pic)
                     //reply(mess.wait)
                     hasil = `「 *INSTAGRAM STALKER* 」\n\n• Username : ${anu.Username}\n• Fullname : ${anu.Name}\n• Following : ${anu.Jumlah_Followers}\n• Followers : ${anu.Jumlah_Following}\n• Jumlah Postingan: ${anu.Jumlah_Post}\n• Bio : ${anu.Biodata}`
                    client.sendMessage(from, buffer, image, {quoted: mek, caption: hasil})
                    limitAdd(sender) 
                    break 
                             case 'meme':
				//if (isBanned) return reply(mess.only.benned)    
				if (!isUser) return reply(mess.only.daftarB)
				if (isLimit(sender)) return 
				//reply(mess.wait) 
					memein = await fetchJson(`https://api.zeks.xyz/api/memeindo?apikey=${zekskey}`)
					buffer = await getBuffer(memein.result)
					client.sendMessage(from, buffer, image, {quoted: mek, caption: '.......'})
				        limitAdd(sender)
					break 
                               case 'fire':
                                if (!isUser) return reply(mess.only.daftarB)
                                if (args.length < 1) return reply(`Kirim perintah ${prefix}fire teks\nContoh : ${prefix}fire Novia`)
                                    if (isLimit(sender)) return
                buf= await getBuffer(`https://api.vhtear.com/fire_maker?text=${body.slice(5)}&apikey=${vhtearkey}`)
				client.sendMessage(from, buf, image, {quoted: mek})
                                limitAdd(sender)
				break
                                case 'metal':
                                         if (!isUser) return reply(mess.only.daftarB)
                                         if (args.length < 1) return reply(`Kirim perintah ${prefix}metal teks\nContoh : ${prefix}metal Novia`)
                                         if (isLimit(sender)) return
                bff = await getBuffer(`https://api.vhtear.com/metal_maker?text=${body.slice(6)}&apikey=${vhtearkey}`)
				client.sendMessage(from, bff, image, {quoted: mek})
                                limitAdd(sender)
				break
                               case 'alok':
                                       if (!isUser) return reply(mess.only.daftarB)
                                       if (args.length < 1) return reply(`Kirim perintah ${prefix}alok teks\nContoh : ${prefix}alok Novia`)
                                       if (isLimit(sender)) return
                bufrf = await getBuffer(`https://api.vhtear.com/logoff?hero=alok&text=${body.slice(5)}&apikey=${vhtearkey}`)
				client.sendMessage(from, bufrf, image, {quoted: mek})
                                limitAdd(sender)
				break
                                case 'miya':
                                    if (!isUser) return reply(mess.only.daftarB)
                                    if (args.length < 1) return reply(`Kirim perintah ${prefix}miya teks\nContoh : ${prefix}miya Novia`)
                                    if (isLimit(sender)) return
                buffer = await getBuffer(`https://api.vhtear.com/logoml?hero=miya&text=${body.slice(5)}&apikey=${vhtearkey}`)
				client.sendMessage(from, buffer, image, {quoted: mek})
                                limitAdd(sender)
				break
                                case 'motor':
                                if (!isUser) return reply(mess.only.daftarB)
                                var gh = body.slice(6)
					var text1 = gh.split("|")[0];
					var text2 = gh.split("|")[1];
                                        if (args.length < 1) return reply(`Kirim perintah ${prefix}motor teks|teks\nContoh : ${prefix}motor Bagas|Pia`)
                                        if (isLimit(sender)) return
                                        buffer = await getBuffer(`https://api.vhtear.com/genmeme?text1=${text1}&text2=${text2}&url=https://obs.line-apps.com/os/p/u46b09bb376a7eedb39aebffd1863a050&apikey=${vhtearkey}`)
                                         client.sendMessage(from, buffer, image, {quoted: mek})
                                        limitAdd(sender)
                                        break
                                        /*case 'cersex':
                                   if (isGroup) return reply('Fitur ini hanya bisa digunakan di private chat')
                                   if (!isUser) return reply(mess.only.daftarB)
                                   if (isLimit(sender)) return
			data = await fetchJson(`https://api.vhtear.com/cerita_sex&apikey=${vhtearkey}`)
			teks = `Judul: ${data.result.judul}\nCerita: ${data.result.cerita}`
			buffs = await getBuffer(data.result)
			client.sendMessage(from, `${teks}`, MessageType.text, {quoted: mek})
                             limitAdd(sender)
                                  break*/
                                case 'glitch':
                                        var gh = body.slice(7)
					var text1 = gh.split("|")[0];
					var text2 = gh.split("|")[1];
                                        if (args.length < 1) return reply(`Kirim perintah ${prefix}glitch teks|teks\nContoh : ${prefix}glitch Bagas|Pia`)
                                        if (isLimit(sender)) return
                                        buffer = await getBuffer(`https://api.vhtear.com/glitchtext?text1=${text1}&text2=${text2}&apikey=${vhtearkey}`)
                                        client.sendMessage(from, buffer, image, {quoted: mek})
                                        limitAdd(sender)
                                        break
                                /*case 'pornhub':
                                        if (!isUser) return reply(mess.only.daftarB)
					var gh = body.slice(8)
					var text1 = gh.split("|")[0];
					var text2 = gh.split("|")[1];
					if (args.length < 1) return reply(`Kirim perintah ${prefix}pornhub teks|teks\nContoh : ${prefihub Bagas|Pia`)
                                        if (isLimit(sender)) return
					//reply(mess.wait)
					buffer = await getBuffer(`https://api.vhtear.com/pornlogo?text1=${text1}&text2=${text2}&apikey=${vhtearkey}`)
					client.sendMessage(from, buffer, image, {quoted: mek})
                                        limitAdd(sender)
					break*/
					case 'loli':
                                        gatauda = body.slice(6)
                                        if (!isUser) return reply(mess.only.daftarB)
                                        if (isLimit(sender)) return 
                                        //reply(mess.wait)
                                        anu = await fetchJson(`https://tobz-api.herokuapp.com/api/randomloli?apikey=BotWeA`, {method: 'get'})
                                        buffer = await getBuffer(anu.result)
                                        client.sendMessage(from, buffer, image, {quoted: mek})
                                        await limitAdd(sender)
                                        break
       case 'husbu':
					gatauda = body.slice(13)
					//reply(mess.wait)
                                        if (!isUser) return reply(mess.only.daftarB)
                                        if (isLimit(sender)) return
					anu = await fetchJson(`https://tobz-api.herokuapp.com/api/husbu2?apikey=BotWeA`, {method: 'get'})
					buffer = await getBuffer(anu.result)
					client.sendMessage(from, buffer, image, {quoted: mek})
					limitAdd(sender)
					break
				 case 'tahta':
					var itsme = `${numbernye}@s.whatsapp.net`
					var split = `??𝘼𝙍𝙏?? 𝙏𝘼𝙃𝙏𝘼 𝘼𝙋𝘼`
					// var taged = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
					const tahta = {
					contextInfo: {
					participant: itsme,
					quotedMessage: {
					extendedTextMessage: {
					text: split,
									}
								}
							}
						}
                                        if (!isUser) return reply(mess.only.daftarB)
                                        if (args.length < 1) return client.sendMessage(from, `Kirim perintah ${prefix}tahta teks\nContoh : ${prefix}tahta novia`, MessageType.text, tahta)
                                         if (isLimit(sender)) return
					var teks = encodeURIComponent(body.slice(7))
					if (!teks) return client.sendMessage(from, 'Input teks yang ingin di tulis', msgType.text, {quoted: mek})
				var buffer = await getBuffer(`https://api.vhtear.com/hartatahta?text=${teks}&apikey=${vhtearkey}`)
				client.sendMessage(from, buffer, MessageType.image, tahta)
                                 limitAdd(sender)
				 break
				 case 'map':
					var itsme = `${numbernye}@s.whatsapp.net`
					var split = `${fake}`
					const maping = {
					contextInfo: {
					participant: itsme,
					quotedMessage: {
					extendedTextMessage: {
					text: split,
									}
								}
							}
						}
                                        if (!isUser) return reply(mess.only.daftarB)
                                        if (args.length < 1) return client.sendMessage(from, `Kirim perintah ${prefix}map teks\nContoh : ${prefix}map jakarta`, MessageType.text, maping)
                                         if (isLimit(sender)) return
					var teks = body.slice(5)
					axios.get('https://mnazria.herokuapp.com/api/maps?search='+teks)
					.then((res) => {
					  imageToBase64(res.data.gambar)
						.then(
						  (ress) => {
							var buf = Buffer.from(ress, 'base64')
							client.sendMessage(from, buf, MessageType.image, maping)
                                                        limitAdd(sender)
						})
					})
					break
				 case 'thunder':
					var itsme = `${numbernye}@s.whatsapp.net`
					var split = `${fake}`
					// var taged = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
					const thunder = {
					contextInfo: {
					participant: itsme,
					quotedMessage: {
					extendedTextMessage: {
					text: split,
									}
								}
							}
						}
                                        if (!isUser) return reply(mess.only.daftarB)
					var teks = encodeURIComponent(body.slice(9))
					if (!teks) return client.sendMessage(from, `Kirim perintah ${prefix}thunder teks\nContoh : ${prefix}thunder Novia`, MessageType.text, thunder)
                                         if (isLimit(sender)) return
				var buffer = await getBuffer(`https://api.vhtear.com/thundertext?text=${teks}&apikey=${vhtearkey}`)
				client.sendMessage(from, buffer, MessageType.image, thunder)
                                      limitAdd(sender)
					 break
					 case 'otakulast':
                                                if (!isUser) return reply(mess.only.daftarB)
                                                 if (isLimit(sender)) return
						anu = await fetchJson(`https://api.vhtear.com/otakulatest&apikey=${vhtearkey}`, {method: 'get'})
						if (anu.error) return reply(anu.error)
						teks = '=================\n\n'
						for (let i of anu.result.data) {
							teks += `*Title* : ${i.title}\n*Link* : ${i.link}\n*Published* : ${i.datetime}\n\n=================\n\n`
						}
						reply(teks.trim())
                                                limitAdd(sender)
						break
				case 'randomhentai':
					var itsme = `${numbernye}@s.whatsapp.net`
					var split = `${fake}`
					var selepbot = {
					contextInfo: {
					participant: itsme,
					quotedMessage: {
					extendedTextMessage: {
					text: split,
									}
								}
							}
						}
                                        if (isGroup) return reply('Fitur ini hanya bisa digunakan di private chat')
                                        if (!isUser) return reply(mess.only.daftarB)
                                         if (isLimit(sender)) return
					gatauda = body.slice(6)
					anu = await fetchJson(`https://tobz-api.herokuapp.com/api/hentai?apikey=BotWeA`, {method: 'get'})
					buffer = await getBuffer(anu.result)
					client.sendMessage(from, buffer, image, selepbot)
                                        limitAdd(sender)
					break
				case 'nsfwneko':
					var itsme = `${numbernye}@s.whatsapp.net`
					var split = `${fake}`
					var selepbot = {
					contextInfo: {
					participant: itsme,
					quotedMessage: {
					extendedTextMessage: {
					text: split,
									}
								}
							}
						}
                                        if (isGroup) return reply('Fitur ini hanya bisa digunakan di private chat')
                                        if (!isUser) return reply(mess.only.daftarB)
                                         if (isLimit(sender)) return
					gatauda = body.slice(6)
					anu = await fetchJson(`https://tobz-api.herokuapp.com/api/nsfwneko?apikey=BotWeA`, {method: 'get'})
					buffer = await getBuffer(anu.result)
					client.sendMessage(from, buffer, image, selepbot)
                                        limitAdd(sender)
					break
                                case 'ttp':
				//if (isBanned) return reply(mess.only.benned)    
				//if  (!isOwner) return 
				 if (!isUser) return reply(mess.only.daftarB)
					if (args.length < 1) return reply('*Textnya mana om?*')
					ranp = getRandom('.png')
					rano = getRandom('.webp')
					teks = body.slice(5).trim()
					anu = await fetchJson(`https://mhankbarbar.tech/api/text2image?text=${teks}&apiKey=${barbarkey}`, {method: 'get'})
					if (anu.error) return reply(anu.error)
					exec(`wget ${anu.result} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
						fs.unlinkSync(ranp)
						if (err) return reply(mess.error.stick)
						bufferhgf = fs.readFileSync(rano)
						client.sendMessage(from, bufferhgf, sticker, {quoted: mek})
						fs.unlinkSync(rano)
					})
					break
				case 'nsfwtrap':
					var itsme = `${numbernye}@s.whatsapp.net`
					var split = `${fake}`
					var selepbot = {
					contextInfo: {
					participant: itsme,
					quotedMessage: {
					extendedTextMessage: {
					text: split,
									}
								}
							}
						}
                                        if (isGroup) return reply('Fitur ini hanya bisa digunakan di private chat')
                                        if (!isUser) return reply(mess.only.daftarB)
                                         if (isLimit(sender)) return
					gatauda = body.slice(6)
					anu = await fetchJson(`https://tobz-api.herokuapp.com/api/nsfwtrap?apikey=BotWeA`, {method: 'get'})
					buffer = await getBuffer(anu.result)
					client.sendMessage(from, buffer, image, selepbot)
                                        limitAdd(sender)
					break
				case 'nsfwblowjob':
                                case 'randomblowjob':
					var itsme = `${numbernye}@s.whatsapp.net`
					var split = `${fake}`
					var selepbot = {
					contextInfo: {
					participant: itsme,
					quotedMessage: {
					extendedTextMessage: {
					text: split,
									}
								}
							}
						}
                                         if (isGroup) return reply('Fitur ini hanya bisa digunakan di private chat')
                                        if (!isUser) return reply(mess.only.daftarB)
                                         if (isLimit(sender)) return
					gatauda = body.slice(6)
					anu = await fetchJson(`https://tobz-api.herokuapp.com/api/nsfwblowjob?apikey=BotWeA`, {method: 'get'})
					buffer = await getBuffer(anu.result)
					client.sendMessage(from, buffer, image, selepbot)
                                        limitAdd(sender)
					break
case 'blowjob':
			        if (!isUser) return reply(mess.only.daftarB)
			    if (isGroup) return reply('Fitur ini hanya bisa digunakan di private chat')
				if (isLimit(sender)) return 
				//if (!isNsfw) return reply(ind.nsfwoff())
					ranp = getRandom('.gif')
					rano = getRandom('.webp')
					anu = await fetchJson('https://tobz-api.herokuapp.com/api/nsfwblowjob?apikey=BotWeA', {method: 'get'})
					if (anu.error) return reply(anu.error)
					exec(`wget ${anu.result} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
						fs.unlinkSync(ranp)
						//if (err) return reply(ind.stikga())
						buffer = fs.readFileSync(rano)
						client.sendMessage(from, buffer, sticker, {quoted: mek})
						fs.unlinkSync(rano)
					})
					limitAdd(sender)
					break
case 'nangis':
				if (!isUser) return reply(mess.only.daftarB)
				if (isLimit(sender)) return 
					ranp = getRandom('.gif')
					rano = getRandom('.webp')
					anu = await fetchJson('https://tobz-api.herokuapp.com/api/cry?apikey=BotWeA', {method: 'get'})
					if (anu.error) return reply(anu.error)
					exec(`wget ${anu.result} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
						fs.unlinkSync(ranp)
						//if (err) return reply(ind.stikga())
						buffer = fs.readFileSync(rano)
						client.sendMessage(from, buffer, sticker, {quoted: mek})
						fs.unlinkSync(rano)
					})
					await limitAdd(sender)
					break
case 'cium':
				if (!isUser) return reply(mess.only.daftarB)
				if (isLimit(sender)) return 
				//if (!isNsfw) return reply(ind.nsfwoff())
					ranp = getRandom('.gif')
					rano = getRandom('.webp')
					anu = await fetchJson('https://tobz-api.herokuapp.com/api/kiss?apikey=BotWeA', {method: 'get'})
					if (anu.error) return reply(anu.error)
					exec(`wget ${anu.result} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
						fs.unlinkSync(ranp)
						//if (err) return reply(ind.stikga())
						buffer = fs.readFileSync(rano)
						client.sendMessage(from, buffer, sticker, {quoted: mek})
						fs.unlinkSync(rano)
					})
					limitAdd(sender)
					break
	case 'peluk':
				if (!isUser) return reply(mess.only.daftarB)
				if (isLimit(sender)) return reply(ind.limitend(pusname))
				//if (!isNsfw) return reply(ind.nsfwoff())
					ranp = getRandom('.gif')
					rano = getRandom('.webp')
					anu = await fetchJson('https://tobz-api.herokuapp.com/api/hug?apikey=BotWeA', {method: 'get'})
					if (anu.error) return reply(anu.error)
					exec(`wget ${anu.result} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
						fs.unlinkSync(ranp)
						//if (err) return reply(ind.stikga())
						buffer = fs.readFileSync(rano)
						client.sendMessage(from, buffer, sticker, {quoted: mek})
						fs.unlinkSync(rano)
					})
					limitAdd(sender)
					break
case 'animehug':
	var itsme = `${numbernye}@s.whatsapp.net`
	var split = `${fake}`
	var selepbot = {
	contextInfo: {
	participant: itsme,
	quotedMessage: {
	extendedTextMessage: {
	text: split,
				}
			}
		}
	}
        if (!isUser) return reply(mess.only.daftarB)
        if (isLimit(sender)) return
	gatauda = body.slice(6)
	anu = await fetchJson(`https://tobz-api.herokuapp.com/api/hug?apikey=BotWeA`, {method: 'get'})
	buffer = await getBuffer(anu.result)
	client.sendMessage(from, buffer, image, selepbot)
        limitAdd(sender)
	break
case 'waifu':
					gatauda = body.slice(7)
					//reply(mess.wait)
                                        if (!isUser) return reply(mess.only.daftarB)
                                        if (isLimit(sender)) return 
					anu = await fetchJson(`https://arugaz.herokuapp.com/api/nekonime`, {method: 'get'})
					buffer = await getBuffer(anu.result)
					client.sendMessage(from, buffer, image,{quoted: mek})
					limitAdd(sender)
					break
      case 'botgroup':
      case 'groupbot':
      case 'botgrup':
      case 'grupbot':
        reply(`Jangan lupa join ya kak ${pushname}\nGroup Bot : https://chat.whatsapp.com/KMktCwXnk3TAdcc0MPTDvX`)
     break
      case 'game':
      reply(`Sebelum bermain berjanjilah akan melaksanakan apapun perintah yang diberikan. Ga Ush Curang😤
*GA BERANI NGELAKUIN TANTANGAN GA USH MAIN!!....*

Silahkan Pilih Yang Tersedia :
├> ${prefix}truth
├> ${prefix}dare`)
       break
case 'admin':
            case 'owner':
            case 'creator':
                  if (!isUser) return reply(mess.only.daftarB)
                  client.sendMessage(from, {displayname: "Jeff", vcard: vcard}, MessageType.contact, { quoted: mek})
       //client.sendMessage(from, 'Owner paling ganteng,fix no debat',MessageType.text, { quoted: mek} )
           break  
case 'menu':
case 'help':
       //if (isBanned) return
        if (!isUser) return reply(mess.only.daftarB)
             semm = sender.replace('@s.whatsapp.net','')
	runtime = process.uptime()
	teks = `${kyun(runtime)}`
	var itsme = `${numbernye}@s.whatsapp.net`
	var split = `${fake}`
	// var taged = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
	const bruhhhh = {
	contextInfo: {
	participant: itsme,
	quotedMessage: {
	extendedTextMessage: {
	text: split,
			}
		   }
	    }
	}
	menunye = `「 𝗕𝗼𝘁 」

◪ Info User
  ❏ Nama : ${pushname}
  ❏ Tag : @${sender.split('@')[0]}
  ❏ Bal : $${checkATMuser(sender)}
  ❏ Link : wa.me/${semm}

◪ Info Bot
  ❏ Ver : Baileys
  ❏ Prefix :「 ${prefix} 」
  ❏ Runtime : ${teks}
  ❏ User Terdaftar : ${user.length}
  
_Bot masuk group?Only 10K_\n_Chat owner wa.me/6285717337679_

◪ Group Menu
  │
  ├─ ❏ ${prefix}hidetag
  ├─ ❏ ${prefix}listadmin
  ├─ ❏ ${prefix}tagall
  ├─ ❏ ${prefix}antidelete
  ├─ ❏ ${prefix}antivirtext
  ├─ ❏ ${prefix}antilink
  ├─ ❏ ${prefix}tagme
  ├─ ❏ ${prefix}grup close|open
  ├─ ❏ ${prefix}gcname <teks>
  ├─ ❏ ${prefix}gcdesk <teks>
  ├─ ❏ ${prefix}add 62xxx
  ├─ ❏ ${prefix}kick 62xxx
  ├─ ❏ ${prefix}promote @tag
  ├─ ❏ ${prefix}demote @tag
  ├─ ❏ ${prefix}welcome
  ├─ ❏ ${prefix}delete <reply>
  ├─ ❏ ${prefix}setppgc <gambar>
  ├─ ❏ ${prefix}leave
  ├─ ❏ ${prefix}infogc
  └─ ❏ ${prefix}linkgc

◪ New Fitur
  │
  ├─ ❏ ${prefix}deface
  ├─ ❏ ${prefix}hekweb
  ├─ ❏ ${prefix}giftlimit
  ├─ ❏ ${prefix}citlimit
  ├─ ❏ ${prefix}fitnah
  ├─ ❏ ${prefix}customtahta
  ├─ ❏ ${prefix}imagetourl
  ├─ ❏ ${prefix}imagetopdf
  ├─ ❏ ${prefix}imagecartoon
  ├─ ❏ ${prefix}imagecomic
  ├─ ❏ ${prefix}imagefire
  ├─ ❏ ${prefix}imagegrafitti
  ├─ ❏ ${prefix}imagewanted
  ├─ ❏ ${prefix}imagewasted
  ├─ ❏ ${prefix}imagefisheye
  ├─ ❏ ${prefix}imagenegative
  ├─ ❏ ${prefix}imagedistortion
  └─ ❏ ${prefix}imagenightvision

◪ Game Menu
  │
  ├─ ❏ ${prefix}gift
  ├─ ❏ ${prefix}bal
  ├─ ❏ ${prefix}shop
  ├─ ❏ ${prefix}buylimit
  ├─ ❏ ${prefix}game
  ├─ ❏ ${prefix}caklontong
  ├─ ❏ ${prefix}tebakgambar
  └─ ❏ ${prefix}family100

◪ Friend Menu
  │
  ├─ ❏ ${prefix}mutual
  └─ ❏ ${prefix}next

◪ 18+ Menu
  │
  ├─ ❏ ${prefix}randomblowjob
  ├─ ❏ ${prefix}randomhentai
  ├─ ❏ ${prefix}blowjob
  ├─ ❏ ${prefix}nsfwneko
  ├─ ❏ ${prefix}nsfwtrap
  ├─ ❏ ${prefix}xnxx
  ├─ ❏ ${prefix}xnxxdl
  ├─ ❏ ${prefix}xvideos
  ├─ ❏ ${prefix}xvideosdl
  └─ ❏ ${prefix}cersex

◪ Maker Menu
  │
  ├─ ❏ ${prefix}quoteit
  ├─ ❏ ${prefix}quoteit2
  ├─ ❏ ${prefix}phcomment
  ├─ ❏ ${prefix}ytcomment 
  ├─ ❏ ${prefix}bikinmeme 
  ├─ ❏ ${prefix}blackpink
  ├─ ❏ ${prefix}lovetext
  ├─ ❏ ${prefix}wolflogo
  ├─ ❏ ${prefix}phlogo
  ├─ ❏ ${prefix}blood
  ├─ ❏ ${prefix}bokeh
  ├─ ❏ ${prefix}tahta
  ├─ ❏ ${prefix}matrix
  ├─ ❏ ${prefix}thunder
  ├─ ❏ ${prefix}naruto
  ├─ ❏ ${prefix}fire
  ├─ ❏ ${prefix}metal
  ├─ ❏ ${prefix}alok
  ├─ ❏ ${prefix}miya
  ├─ ❏ ${prefix}glitch
  └─ ❏ ${prefix}motor

◪ Islam Menu
  │
  ├─ ❏ ${prefix}randomquran
  ├─ ❏ ${prefix}listsurah
  └─ ❏ ${prefix}quran

◪ Anime Menu
  │
  ├─ ❏ ${prefix}animehug
  ├─ ❏ ${prefix}loli
  ├─ ❏ ${prefix}peluk
  ├─ ❏ ${prefix}cium
  ├─ ❏ ${prefix}nangis
  ├─ ❏ ${prefix}shota
  ├─ ❏ ${prefix}otakulast
  ├─ ❏ ${prefix}waifu
  └─ ❏ ${prefix}husbu

◪ Anime Menu
  │
  ├─ ❏ ${prefix}ytmp3
  ├─ ❏ ${prefix}ytmp4
  ├─ ❏ ${prefix}yt2mp3
  ├─ ❏ ${prefix}yt2mp4
  ├─ ❏ ${prefix}tiktok
  ├─ ❏ ${prefix}joox
  ├─ ❏ ${prefix}play
  ├─ ❏ ${prefix}ig <link>
  └─ ❏ ${prefix}fb <link>
  
  ◪ Gabut Menu
  │
  ├─ ❏ ${prefix}apakah
  ├─ ❏ ${prefix}rate
  ├─ ❏ ${prefix}bolehkah
  └─ ❏ ${prefix}kapankah

◪ Media Menu
  │
  ├─ ❏ ${prefix}sticker
  ├─ ❏ ${prefix}stickergif
  ├─ ❏ ${prefix}ttp [teks]
  ├─ ❏ ${prefix}toimg <reply gambar>
  ├─ ❏ ${prefix}tomp3 <reply video>
  ├─ ❏ ${prefix}brainly
  ├─ ❏ ${prefix}spekhp
  ├─ ❏ ${prefix}heroml
  ├─ ❏ ${prefix}infogempa
  ├─ ❏ ${prefix}cuaca
  ├─ ❏ ${prefix}quotes
  ├─ ❏ ${prefix}quotesnime
  ├─ ❏ ${prefix}jadwaltv
  ├─ ❏ ${prefix}pantun
  ├─ ❏ ${prefix}darkjoke
  ├─ ❏ ${prefix}puisi
  ├─ ❏ ${prefix}zodiak
  ├─ ❏ ${prefix}listzodiak
  ├─ ❏ ${prefix}meme
  ├─ ❏ ${prefix}lirik
  ├─ ❏ ${prefix}artinama
  ├─ ❏ ${prefix}chord
  ├─ ❏ ${prefix}infonomor
  ├─ ❏ ${prefix}tts
  ├─ ❏ ${prefix}ocr
  ├─ ❏ ${prefix}pinterest <optional>
  ├─ ❏ ${prefix}googleimage <optional>
  ├─ ❏ ${prefix}wiki [teks]
  ├─ ❏ ${prefix}map [teks]
  ├─ ❏ ${prefix}kbbi [teks]
  ├─ ❏ ${prefix}nulis2
  ├─ ❏ ${prefix}nulis [teks]
  ├─ ❏ ${prefix}ytsearch [teks]
  ├─ ❏ ${prefix}igstalk <teks>
  ├─ ❏ ${prefix}ssweb <link>
  ├─ ❏ ${prefix}tinyurl <link>
  └─ ❏ ${prefix}howak

◪ Other Menu
  │
  ├─ ❏ ${prefix}addsticker <optional>
  ├─ ❏ ${prefix}getsticker <optional>
  ├─ ❏ ${prefix}liststicker
  ├─ ❏ ${prefix}addvn <optional>
  ├─ ❏ ${prefix}getvn <optional>
  ├─ ❏ ${prefix}listvn
  ├─ ❏ ${prefix}addvideo <optional>
  ├─ ❏ ${prefix}getvideo <optional>
  ├─ ❏ ${prefix}listvideo
  ├─ ❏ ${prefix}addimage <optional>
  ├─ ❏ ${prefix}getimage <optional>
  ├─ ❏ ${prefix}listimage
  ├─ ❏ ${prefix}info
  ├─ ❏ ${prefix}limit
  ├─ ❏ ${prefix}profile
  ├─ ❏ ${prefix}premiumlist
  ├─ ❏ ${prefix}listban
  ├─ ❏ ${prefix}listblock
  ├─ ❏ ${prefix}readme
  ├─ ❏ ${prefix}sewa
  ├─ ❏ ${prefix}daftar
  ├─ ❏ ${prefix}wa.me
  ├─ ❏ ${prefix}say
  ├─ ❏ ${prefix}ping
  ├─ ❏ ${prefix}rules
  ├─ ❏ ${prefix}qrcode
  ├─ ❏ ${prefix}botgroup
  ├─ ❏ ${prefix}creator
  ├─ ❏ ${prefix}runtime
  ├─ ❏ ${prefix}fordward
  ├─ ❏ ${prefix}fordward2
  ├─ ❏ ${prefix}hilih
  ├─ ❏ ${prefix}holoh
  ├─ ❏ ${prefix}blocklist
  └─ ❏ ${prefix}cekchat

◪ Owner Menu
  │
  ├─ ❏ ${prefix}bc
  ├─ ❏ ${prefix}listuser
  ├─ ❏ ${prefix}settarget
  ├─ ❏ ${prefix}setreply
  ├─ ❏ ${prefix}ban add/del
  ├─ ❏ ${prefix}dellprem
  ├─ ❏ ${prefix}block
  ├─ ❏ ${prefix}unblock
  ├─ ❏ ${prefix}setnumber
  ├─ ❏ ${prefix}setstatus
  ├─ ❏ ${prefix}readall
  └─ ❏ ${prefix}setprefix

 _JOIN GROUP TES BOT_: 
https://chat.whatsapp.com/BlztrC3AHsG3NPS59ycpAS

◩ 𝗕𝗼𝘁`
  try {
	anu = await client.getProfilePicture(sender)
	} catch {
      anu = 'https://i.ibb.co/XSQfPhN/ab73026ecbdc.jpg'
          }                         
	buffer = await getBuffer(anu)                                                
client.sendMessage(from, buffer, image, { contextInfo: {mentionedJid: [sender]}, caption: menunye, quoted : mek }, MessageType.text, bruhhhh)
	break
case 'tomp3':
     if (!isUser) return reply(mess.only.daftarB)
    var itsme = `${numbernye}@s.whatsapp.net`
	var split = `${fake}`
	// var taged = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
	const selepboy = {
	contextInfo: {
	participant: itsme,
	quotedMessage: {
	extendedTextMessage: {
	text: split,
			}
		   }
	    }
	}
          if (isLimit(sender)) return
    	 //if (args.length < 1) return client.sendMessage(from, 'Reply video yang ingin diambil audionya', MessageType.text, selepboy)
     reply('Sedang diproses,tunggu sebentar ya')
    client.updatePresence(from, Presence.composing) 
	encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
	media = await client.downloadAndSaveMediaMessage(encmedia)
	ran = getRandom('.mp3')
	exec(`ffmpeg -i ${media} ${ran}`, (err) => {
	fs.unlinkSync(media)
	if (err) return reply('Yahh emrror bruh:(')
	buffer = fs.readFileSync(ran)
    client.sendMessage(from, buffer, audio, {mimetype: 'audio/mp4', quoted: mek})
	fs.unlinkSync(ran)
        limitAdd(sender)
	})
	break
case 'getsticker':
	var itsme = `${numbernye}@s.whatsapp.net`
	var split = `*𝙎𝙏𝙄𝘾𝙆𝙀𝙍 𝙁𝙍𝙊𝙈 𝘿𝘼𝙏𝘼𝘽𝘼𝙎𝙀*`
	var selepbot = {
		contextInfo: {
		participant: itsme,
		quotedMessage: {
		extendedTextMessage: {
		text: split,
					}
				}
			}
		}
         if (!isUser) return reply(mess.only.daftarB)
         if (isLimit(sender)) return
	namastc = body.slice(12)
	result = fs.readFileSync(`./src/sticker/${namastc}.webp`)
	client.sendMessage(from, result, sticker, selepbot)
        limitAdd(sender)
	break
case 'stc':
       var itsme = `${numbernye}@s.whatsapp.net`
	var split = `*𝙎𝙏𝙄𝘾𝙆𝙀𝙍 𝙁𝙍𝙊𝙈 𝘿𝘼𝙏𝘼𝘽𝘼𝙎𝙀*`
	var selepbot = {
		contextInfo: {
		participant: itsme,
		quotedMessage: {
		extendedTextMessage: {
		text: split,
					}
				}
			}
		}
        if (!isUser) return reply(mess.only.daftarB)
	namastc = body.slice(5)
	result = fs.readFileSync(`./src/sticker/${namastc}.webp`)
	client.sendMessage(from, result, sticker, selepbot)
	break
case 'stickerlist':
case 'liststicker':
        if (!isUser) return reply(mess.only.daftarB)
	teks = 'Sticker List :\n'
	for (let awokwkwk of setiker) {
		teks += `- ${awokwkwk}\n`
	}
	teks += `Total : ${setiker.length}\n\nCara penggunaan : ${prefix}getsticker teks`
	client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": setiker}})
	break
case 'addsticker':
        var itsme = `${numbernye}@s.whatsapp.net`
					var split = `${fake}`
					// var taged = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
					const addstickerr = {
					contextInfo: {
					participant: itsme,
					quotedMessage: {
					extendedTextMessage: {
					text: split,
									}
								}
							}
						}
        if (!isUser) return reply(mess.only.daftarB)
        if (!isGroupAdmins) return reply(mess.only.admin)
	if (args.length < 1) return client.sendMessage(from, 'Reply stiker nya', MessageType.text, addstickerr)
	svst = body.slice(12)
	if (!svst) return reply('Nama sticker nya apa?')
	boij = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
	delb = await client.downloadMediaMessage(boij)
	setiker.push(`${svst}`)
	fs.writeFileSync(`./src/sticker/${svst}.webp`, delb)
	fs.writeFileSync('./src/stik.json', JSON.stringify(setiker))
	client.sendMessage(from, `Sukses Menambahkan Sticker\nCek dengan cara ${prefix}liststicker`, MessageType.text, addstickerr)
	break
case 'addvn':
        var itsme = `${numbernye}@s.whatsapp.net`
					var split = `${fake}`
					// var taged = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
					const yyey = {
					contextInfo: {
					participant: itsme,
					quotedMessage: {
					extendedTextMessage: {
					text: split,
									}
								}
							}
						}
        if (!isUser) return reply(mess.only.daftarB)
        if (!isGroupAdmins) return reply(mess.only.admin)
	if (args.length < 1) return client.sendMessage(from, 'Reply vn nya', MessageType.text, yyey)
	svst = body.slice(7)
	if (!svst) return reply('Nama audionya apa su?')
	boij = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
	delb = await client.downloadMediaMessage(boij)
	audionye.push(`${svst}`)
	fs.writeFileSync(`./src/audio/${svst}.mp3`, delb)
	fs.writeFileSync('./src/audio.json', JSON.stringify(audionye))
	client.sendMessage(from, `Sukses Menambahkan Vn\nCek dengan cara ${prefix}listvn`, MessageType.text, yyey)
	break
case 'getvn':
        if (!isUser) return reply(mess.only.daftarB)
         if (isLimit(sender)) return
	namastc = body.slice(7)
	buffer = fs.readFileSync(`./src/audio/${namastc}.mp3`)
	client.sendMessage(from, buffer, audio, {mimetype: 'audio/mp4', quoted: mek, ptt: true})
        limitAdd(sender)
	break
case 'v':
        var itsme = `${numbernye}@s.whatsapp.net`
					var split = `${fake}`
					// var taged = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
					const addvn1 = {
					contextInfo: {
					participant: itsme,
					quotedMessage: {
					extendedTextMessage: {
					text: split,
									}
								}
							}
						}
        if (!isUser) return reply(mess.only.daftarB)
        namastc = body.slice(3)
	buffer = fs.readFileSync(`./src/audio/${namastc}.mp3`)
	client.sendMessage(from, buffer, audio, {mimetype: 'audio/mp4', quoted: mek, ptt: true})
	break
case 'listvn':
case 'vnlist':
        if (!isUser) return reply(mess.only.daftarB)
	teks = 'List Vn:\n'
	for (let awokwkwk of audionye) {
	teks += `- ${awokwkwk}\n`
	}
	teks += `Total : ${audionye.length}\n\nCara penggunaan : ${prefix}getvn teks`
	client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": audionye}})
	break
case 'addimage':
        var itsme = `${numbernye}@s.whatsapp.net`
					var split = `${fake}`
					// var taged = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
					const addimg = {
					contextInfo: {
					participant: itsme,
					quotedMessage: {
					extendedTextMessage: {
					text: split,
									}
								}
							}
						}
        if (!isUser) return reply(mess.only.daftarB)
        if (!isGroupAdmins) return reply(mess.only.admin)
	if (args.length < 1) return client.sendMessage(from, 'Reply gambar', MessageType.text, addimg)
	svst = body.slice(10)
	if (!svst) return reply('Nama imagenya apa su?')
	boij = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
	delb = await client.downloadMediaMessage(boij)
	imagenye.push(`${svst}`)
	fs.writeFileSync(`./src/image/${svst}.jpeg`, delb)
	fs.writeFileSync('./src/image.json', JSON.stringify(imagenye))
	client.sendMessage(from, `Sukses Menambahkan Video\nCek dengan cara ${prefix}listimage`, MessageType.text, addimg)
	break
case 'getimage':
         if (!isUser) return reply(mess.only.daftarB)
         if (isLimit(sender)) return
	namastc = body.slice(10)
	buffer = fs.readFileSync(`./src/image/${namastc}.jpeg`)
	client.sendMessage(from, buffer, image, {quoted: mek, caption: `${namastc}`})
        limitAdd(sender)
	break
case 'imagelist':
case 'listimage':
        if (!isUser) return reply(mess.only.daftarB)
	teks = 'List Image:\n'
	for (let awokwkwk of imagenye) {
	teks += `- ${awokwkwk}\n`
	}
	teks += `Total : ${imagenye.length}\n\nCara penggunaan : ${prefix}getimage teks`
	client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": imagenye}})
	break
/*case 'asupan':
                                        if (!isUser) return reply(mess.only.daftarB)
                                        //if (!isOwner && !ben.key.fromMe && !isPremium) return reply(mess.only.premium)
                  anu = JSON.parse(fs.readFileSync('./src/asupan.json'))
                  let asupan = anu[Math.floor(Math.random() * anu.length)]
                  buffer = await getBuffer(asupan)
                  client.sendMessage(from, mess.wait, text, { quoted: {
    "key": {
      "remoteJid": "status@broadcast",
      "fromMe": false,
          "participant": `0@s.whatsapp.net`,
      "id": "0D5EAADD1166F55012EB42395DE58D61"
    },
    "message": {
      "productMessage": {
        "product": {
          "productImage": {
            "url": "https://mmg.whatsapp.net/d/f/AsFENZUsypKYO29kpNR2SrgcoBit6mDiApzGccFAPIAq.enc",
            "mimetype": "image/jpeg",
        "fileSha256": "iRrEuDPCvNe6NtOv/n+DARqlS1i2UbWqc25iw+qcwwo=",
        "fileLength": "19247",
        "height": 416,
        "width": 416,
        "mediaKey": "zvebSUI7DcnK9QHuUCJpNAtTsKai0MkvzrcNSYE5pHo=",
        "fileEncSha256": "t6pd+X7iNV/bwtti0KaOOjGBfOVhxPpnwnTs/QnD0Uw=",
        "directPath": "/v/t62.7118-24/29158005_1025181757972162_6878749864442314383_n.enc?oh=c97d5aea20257c3971a7248b339ee42d&oe=60504AC8",
        "mediaKeyTimestamp": "1613162019",
        "jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAvAAACAwEBAAAAAAAAAAAAAAAABQEDBAYCAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAADnZCwvqZrPp3oOWXdtzAuASQmpY4N8rzSt3VYgbKxISJExJ6dI2ku9mhatbOcc8mz4ILAj2Rpo0Su9/NsypC/VazkPRLfaHXmSEra0MbxUB25QAn//xAAlEAACAgEDAwUBAQAAAAAAAAABAgADEQQSIQUTIBAiMTJBI2H/2gAIAQEAAT8A9a1APIyYK7XC4Bj6S7GTLaCQAwxHUqcHwX5miQbsmJBg/ksqRwcia6ntt46RwGEF6LgGdxMZncRhwZ1NwSB4LNPQzgbY9SrVyeZsDUqP8ldLr+zX1rixvBTgzp7cmauxd6KTiIy7Fwc8QsMEzqVgyEHjoG9+Jape/wBy5lJ2gBazLLNlTMZY5dyxPjU5rKsJWi24dTzEGxckzqNv8uPAITMYirkSt7qfrKTbaoLNNUiNisx9MR9TGrdfkQVDEVeI1WZVhWwYEBQECJhE4GBLH3uWh9P/xAAbEQEBAAEFAAAAAAAAAAAAAAABEAACERIgMP/aAAgBAgEBPwDzerOLtAzUEJ//xAAaEQACAgMAAAAAAAAAAAAAAAAAARBBEiAw/9oACAEDAQE/AOaK0UZKGxMqf//Z"
                 },
          "productId": "3958959877488517",
          "title": "al",
          "description": "IMKAN",
          "currencyCode": "USD",
          "priceAmount1000": "999999999",
          "retailerId": "KYu",
          "url": "https://youtube.com/c/hidayat",
          "productImageCount": 2
        },
        "OwnerJid": "6285717337679@s.whatsapp.net"
      }
    },
    "messageTimestamp": "1613442626",
    "status": "PENDING"
                                        }})
                                        client.sendMessage(from, buffer, video, {mimetype: 'video/mp4', filename: `${asupan}.mp4`, quoted: mek, caption: 'Neh..'})
                                                        break*/
case 'addvideo':
        var itsme = `${numbernye}@s.whatsapp.net`
					var split = `${fake}`
					// var taged = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
					const addvid = {
					contextInfo: {
					participant: itsme,
					quotedMessage: {
					extendedTextMessage: {
					text: split,
									}
								}
							}
						}
        if (!isUser) return reply(mess.only.daftarB)
        if (!isGroupAdmins) return reply(mess.only.admin)
	if (args.length < 1) return client.sendMessage(from, 'Reply video nya', MessageType.text, addvid)
	svst = body.slice(10)
	if (!svst) return reply('Nama videonya apa su?')
	boij = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
	delb = await client.downloadMediaMessage(boij)
	videonye.push(`${svst}`)
	fs.writeFileSync(`./src/video/${svst}.mp4`, delb)
	fs.writeFileSync('./src/video.json', JSON.stringify(videonye))
	client.sendMessage(from, `Sukses Menambahkan Video\nCek dengan cara ${prefix}listvideo`, MessageType.text, {quoted: mek})
	break
case 'getvideo':
        if (!isUser) return reply(mess.only.daftarB)
         if (isLimit(sender)) return
	namastc = body.slice(10)
	buffer = fs.readFileSync(`./src/video/${namastc}.mp4`)
	client.sendMessage(from, buffer, video, {mimetype: 'video/mp4', quoted: mek})
        limitAdd(sender)
	break
case 'vid':
        if (!isUser) return reply(mess.only.daftarB)
        namastc = body.slice(5)
	buffer = fs.readFileSync(`./src/video/${namastc}.mp4`)
	client.sendMessage(from, buffer, video, {mimetype: 'video/mp4', quoted: mek})
	break
case 'listvideo':
case 'videolist':
        if (!isUser) return reply(mess.only.daftarB)
	teks = 'List Video:\n'
	for (let awokwkwk of videonye) {
	teks += `- ${awokwkwk}\n`
	}
	teks += `Total : ${videonye.length}\n\nCara penggunaan : ${prefix}getvideo teks`
	client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": videonye}})
	break
case 'howax':
case 'hoax':
case 'howak':
case 'hoak':
         if (!isUser) return reply(mess.only.daftarB)
         if (isLimit(sender)) return
	client.updatePresence(from, Presence.composing) 
	data = await fetchJson(`https://docs-jojo.herokuapp.com/api/infohoax`, {method: 'get'})
	teks = '────────────────────\n\n'
	for (let i of data.result) {
		teks += `*Title* : ${i.title}\n*Link* : ${i.link}\n*Tag* : ${i.tag}\n\n────────────────────\n`
	}
	reply(teks.trim())
        limitAdd(sender)
	breaking
case 'leave':
        if (!isUser) return reply(mess.only.daftarB)
        if (!isOwner) return reply(ind.ownerb())
        if (!isGroup) return reply(mess.only.group)
	anu = await client.groupLeave(from, 'See you........', groupId)
	break
case 'ssweb':
        var itsme = `${numbernye}@s.whatsapp.net`
					var split = `${fake}`
					// var taged = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
					const web1 = {
					contextInfo: {
					participant: itsme,
					quotedMessage: {
					extendedTextMessage: {
					text: split,
									}
								}
							}
						}
        if (!isUser) return reply(mess.only.daftarB)
	if (args.length < 1) return client.sendMessage(from, 'Urlnya mana?', MessageType.text, web1)
        if (isLimit(sender)) return
	teks = body.slice(7)
	reply(mess.wait)
	anu = await fetchJson(`https://mnazria.herokuapp.com/api/screenshotweb?url=${teks}`)
	buffri = await getBuffer(anu.gambar)
	client.sendMessage(from, buffri, image, {caption: `Result : ${teks}`, quoted: mek})
        limitAdd(sender)
	break
case 'chatlist':
case 'cekchat':
	client.updatePresence(from, Presence.composing)
	var itsme = `${numbernye}@s.whatsapp.net`
	var split = `*𝘾𝙀𝙆 𝘼𝙇𝙇-𝘾𝙃𝘼𝙏*`
	var selepbot = {
		contextInfo: {
		participant: itsme,
		quotedMessage: {
		extendedTextMessage: {
		text: split,
					}
				}
			}
		}
        if (!isUser) return reply(mess.only.daftarB)
	//teks = 'This is list of chat number :\n'
	// for (let all of totalchat) {
	//teks += `~> @${totalchat}\n`
	//}
	teks = `Total : ${totalchat.length}`
	client.sendMessage(from, teks, MessageType.text, selepbot)
	break
case 'speed':
case 'ping':
        if (!isUser) return reply(mess.only.daftarB)
	const timestamp = speed();
	const latensi = speed() - timestamp
	exec(`neofetch --stdout`, (error, stdout, stderr) => {
	const child = stdout.toString('utf-8')
	const teks = child.replace(/Memory:/, "Ram:")
	var itsme = `${numbernye}@s.whatsapp.net`
	var split = `*𝙋𝙞𝙣𝙜!*`
	const pingbro = {
	contextInfo: {
	participant: itsme,
	quotedMessage: {
	extendedTextMessage: {
	text: split,
				}
			}
		}
	}
	const pingnya = `${teks}\nSpeed: ${latensi.toFixed(4)} _Second_`
	client.sendMessage(from, `${teks}\nSpeed: ${latensi.toFixed(4)} _Second_`, MessageType.text, pingbro)
	})
	break
case 'term':
        if (!isUser) return reply(mess.only.daftarB)
	const cmd = body.slice(6)
	var itsme = `${numbernye}@s.whatsapp.net`
	var split = `${fake}`
	const term = {
	contextInfo: {
	participant: itsme,
	quotedMessage: {
	extendedTextMessage: {
	text: split,
				}
			}
		}
	}
	exec(cmd, (err, stdout) => {
	if(err) return client.sendMessage(from, `_*WhatsApp-Bot*_:~ ${err}`, text, { quoted: mek })
	if (stdout) {
	client.sendMessage(from, stdout, text, term)
		}
	})
	break
case 'payment':
case 'list':
case 'sewa':
        if (!isUser) return reply(mess.only.daftarB)
	var itsme = `${numbernye}@s.whatsapp.net`
	var split = `${fake}`
	var selepbot = {
	contextInfo: {
	participant: itsme,
	quotedMessage: {
	extendedTextMessage: {
	text: split,
				}
			}
		}
	}
	client.sendMessage(from, `List harga

1. Bot = 10K/Perbulan
2. Self Bot = 50K/Perbulan

Payment :
*-Gopay :* 081280387069
*-Pulsa Tsel :* 081280387069\n\nMore info?Chat owner\nwa.me/6285717337679`, MessageType.text, selepbot)
	break
case 'neko':
        var itsme = `${numbernye}@s.whatsapp.net`
					var split = `${fake}`
					// var taged = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
					const nekko = {
					contextInfo: {
					participant: itsme,
					quotedMessage: {
					extendedTextMessage: {
					text: split,
									}
								}
							}
						}
	{
        if (!isUser) return reply(mess.only.daftarB)
        if (isLimit(sender)) return
	var items = ["anime neko"];
	var nime = items[Math.floor(Math.random() * items.length)];
	var url = "https://api.fdci.se/rep.php?gambar=" + nime;
		
	axios.get(url)
	.then((result) => {
	var n = JSON.parse(JSON.stringify(result.data));
	var nimek =  n[Math.floor(Math.random() * n.length)];
	imageToBase64(nimek) 
	.then(
	(response) => {
	var buf = Buffer.from(response, 'base64'); 
	client.sendMessage(from, buf ,MessageType.image, nekko)
        limitAdd(sender)
		}
	)
	.catch(
	(error) => {
	console.log(error);
				}
			)
		});
	}
	break
case 'blocklist':
        if (!isUser) return reply(mess.only.daftarB) 
	teks = '𝗕𝗟𝗢𝗖𝗞 𝗟𝗜𝗦𝗧 :\n'
	for (let block of blocked) {
	teks += `┣➢ @${block.split('@')[0]}\n`
	}
	teks += `𝗧𝗼𝘁𝗮𝗹 : ${blocked.length}`
	client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": blocked}})
	break
case 'ocr': 
                                        if (!isUser) return reply(mess.only.daftarB)
				if (isLimit(sender)) return 
				if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await client.downloadAndSaveMediaMessage(encmedia)
						reply(ind.wait())
						await recognize(media, {lang: 'eng+ind', oem: 1, psm: 3})
							.then(teks => {
								reply(teks.trim())
								fs.unlinkSync(media)
							})
							.catch(err => {
								reply(err.message)
								fs.unlinkSync(media)
							})
					} else {
						reply(`𝗸𝗶𝗿𝗶𝗺 𝗳𝗼𝘁𝗼 𝗱𝗲𝗻𝗴𝗮𝗻 𝗰𝗲𝗽𝘁𝗶𝗼𝗻 ${prefix}𝗼𝗰𝗿`)
					}
					await limitAdd(sender)
				break
/*case 'stcwm':
                    //await client.reply(from, mess.wait, id)
                    const packname = q.substring(0, q.indexOf('|') - 1)
                    const author = q.substring(q.lastIndexOf('|') + 2)
                    exif.create(packname, author, `stc_${sender.id}`)
                    const encryptMedia = isQuotedImage ? quotedMsg : message
                    const mediaData = await decryptMedia(encryptMedia, uaOverride)
                    webp.buffer2webpbuffer(mediaData, 'jpg', '-q 100')
                        .then((res) => {
                            sharp(res)
                                .resize(512, 512)
                                .toFile(`./temp/stage_${sender.id}.webp`, async (err) => {
                                    if (err) return console.error(err)
                                    await exec(`webpmux -set exif ./temp/stc_${sender.id}.exif ./temp/stage_${sender.id}.webp -o ./temp/${sender.id}.webp`, { log: true })
                                    if (fs.existsSync(`./temp/${sender.id}.webp`)) {
                                        const data = fs.readFileSync(`./temp/${sender.id}.webp`)
                                        const base64 = `data:image/webp;base64,${data.toString('base64')}`
                                        await client.sendRawWebpAsSticker(from, base64)
                                        console.log(`Sticker processed for ${processTime(t, moment())} seconds`)
                                        fs.unlinkSync(`./temp/${sender.id}.webp`)
                                        fs.unlinkSync(`./temp/stage_${sender.id}.webp`)
                                        fs.unlinkSync(`stc_${sender.id}`)
                                    }
                                })
                        })
                        .catch(async (err) => {
                            console.error(err)
                            await client.reply(from, 'Error!', id)
                        })
                    break*/
					/*case 'stiker':
					case 'sticker':
					case 'stickergif':
					case 'stikergif':
                                              if (!isUser) return reply(mess.only.daftarB)
                                                var itsme = `${numbernye}@s.whatsapp.net`
	var split = `*𝙎𝙏𝙄𝘾𝙆𝙀𝙍 𝙁𝙍𝙊𝙈 𝘿𝘼𝙏𝘼𝘽𝘼𝙎𝙀*`
	var selepbot = {
		contextInfo: {
		participant: itsme,
		quotedMessage: {
		extendedTextMessage: {
		text: split,
					}
				}
			}
		}
						if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
							const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
							const media = await client.downloadAndSaveMediaMessage(encmedia)
							ran = getRandom('.webp')
							await ffmpeg(`./${media}`)
								.input(media)
								.on('start', function (cmd) {
									console.log(`Started : ${cmd}`)
								})
								.on('error', function (err) {
									console.log(`Error : ${err}`)
									fs.unlinkSync(media)
									reply(mess.error.stick)
								})
								.on('end', function () {
									console.log('Finish')
									client.sendMessage(from, fs.readFileSync(ran), sticker, selepbot)
									fs.unlinkSync(media)
									fs.unlinkSync(ran)
								})
								.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
								.toFormat('webp')
								.save(ran)
						} else if ((isMedia && mek.message.videoMessage.seconds < 11 || isQuotedVideo && mek.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.seconds < 11) && args.length == 0) {
							const encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
							const media = await client.downloadAndSaveMediaMessage(encmedia)
							ran = getRandom('.webp')
							await ffmpeg(`./${media}`)
								.inputFormat(media.split('.')[1])
								.on('start', function (cmd) {
									console.log(`Started : ${cmd}`)
								})
								.on('error', function (err) {
									console.log(`Error : ${err}`)
									fs.unlinkSync(media)
									tipe = media.endsWith('.mp4') ? 'video' : 'gif'
									reply(`❌ Gagal, pada saat mengkonversi ${tipe} ke stiker`)
								})
								.on('end', function () {
									console.log('Finish')
									client.sendMessage(from, fs.readFileSync(ran), sticker, selepbot)
									fs.unlinkSync(media)
									fs.unlinkSync(ran)
								})
								.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
								.toFormat('webp')
								.save(ran)
						} else if ((isMedia || isQuotedImage) && args[0] == 'nobg') {
							const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
							const media = await client.downloadAndSaveMediaMessage(encmedia)
							ranw = getRandom('.webp')
							ranp = getRandom('.png')
							keyrmbg = 'lpRnRItgawFrD1Dmp6xY'
							await removeBackgroundFromImageFile({path: media, apiKey: keyrmbg.result, size: 'auto', type: 'auto', ranp}).then(res => {
								fs.unlinkSync(media)
								let buffer = Buffer.from(res.base64img, 'base64')
								fs.writeFileSync(ranp, buffer, (err) => {
									if (err) return reply('Gagal, Terjadi kesalahan, silahkan coba beberapa saat lagi.')
								})
								exec(`ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${ranw}`, (err) => {
									fs.unlinkSync(ranp)
									if (err) return reply(mess.error.stick)
									client.sendMessage(from, fs.readFileSync(ranw), sticker, selepbot)
								})
							})
						} else if ((isMedia || isQuotedImage) && colors.includes(args[0])) {
							const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
							const media = await client.downloadAndSaveMediaMessage(encmedia)
							ran = getRandom('.webp')
							await ffmpeg(`./${media}`)
								.on('start', function (cmd) {
									console.log('Started :', cmd)
								})
								.on('error', function (err) {
									fs.unlinkSync(media)
									console.log('Error :', err)
								})
								.on('end', function () {
									console.log('Finish')
									fs.unlinkSync(media)
									client.sendMessage(from, fs.readFileSync(ran), sticker, selepbot)
									fs.unlinkSync(ran)
								})
								.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=${args[0]}@0.0, split [a][b]; [a] palettegen=reserve_transparent=off; [b][p] paletteuse`])
								.toFormat('webp')
								.save(ran)
						} else {
							reply(`Fitur image/Video to Sticker\nSilahkan reply gambar/gif/video pendek, yang ingin anda jadikan sticker\nUntuk gif/video maks 10 detik`)
						}
						break*/
						case 'stiker':
						case 'stickergif':
						case 'stikergif':
						case 's':
				case 'sticker':
				if (!isUser && !mek.key.fromMe) return reply(mess.only.daftarB)
					if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await client.downloadAndSaveMediaMessage(encmedia)
						ran = getRandom('.webp')
						await ffmpeg(`./${media}`)
							.input(media)
							.on('start', function (cmd) {
								console.log(`Started : ${cmd}`)
							})
							.on('error', function (err) {
								console.log(`Error : ${err}`)
								fs.unlinkSync(media)
								reply(mess.error.stick)
							})
							.on('end', function () {
								console.log('Finish')
								exec(`webpmux -set exif ${addMetadata('By', 'Bagas')} ${ran} -o ${ran}`, async (error) => {
									if (error) return reply(mess.error.stick)
									client.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
									fs.unlinkSync(media)	
									fs.unlinkSync(ran)	
								})
								/*client.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
								fs.unlinkSync(media)
								fs.unlinkSync(ran)*/
							})
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)
					} else if ((isMedia && mek.message.videoMessage.seconds < 11 || isQuotedVideo && mek.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.seconds < 11) && args.length == 0) {
						const encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await client.downloadAndSaveMediaMessage(encmedia)
						ran = getRandom('.webp')
						reply(mess.wait)
						await ffmpeg(`./${media}`)
							.inputFormat(media.split('.')[1])
							.on('start', function (cmd) {
								console.log(`Started : ${cmd}`)
							})
							.on('error', function (err) {
								console.log(`Error : ${err}`)
								fs.unlinkSync(media)
								tipe = media.endsWith('.mp4') ? 'video' : 'gif'
								reply(`❌ Gagal, pada saat mengkonversi ${tipe} ke stiker`)
							})
							.on('end', function () {
								console.log('Finish')
								exec(`webpmux -set exif ${addMetadata('By', 'Bagas')} ${ran} -o ${ran}`, async (error) => {
									if (error) return reply(mess.error.stick)
									client.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
									fs.unlinkSync(media)
									fs.unlinkSync(ran)
								})
								/*client.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
								fs.unlinkSync(media)
								fs.unlinkSync(ran)*/
							})
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)
					} else if ((isMedia || isQuotedImage) && args[0] == 'nobg') {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await client.downloadAndSaveMediaMessage(encmedia)
						ranw = getRandom('.webp')
						ranp = getRandom('.png')
						reply(mess.wait)
						keyrmbg = '5LXrQ1MAYDnE1iib6B6NaHMv'
						await removeBackgroundFromImageFile({path: media, apiKey: keyrmbg, size: 'auto', type: 'auto', ranp}).then(res => {
							fs.unlinkSync(media)
							let buffer = Buffer.from(res.base64img, 'base64')
							fs.writeFileSync(ranp, buffer, (err) => {
								if (err) return reply('Gagal, Terjadi kesalahan, silahkan coba beberapa saat lagi.')
							})
							exec(`ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${ranw}`, (err) => {
								fs.unlinkSync(ranp)
								if (err) return reply(mess.error.stick)
								exec(`webpmux -set exif ${addMetadata('By', 'Bagas')} ${ranw} -o ${ranw}`, async (error) => {
									if (error) return reply(mess.error.stick)
									client.sendMessage(from, fs.readFileSync(ranw), sticker, {quoted: mek})
									fs.unlinkSync(ranw)
								})
								//client.sendMessage(from, fs.readFileSync(ranw), sticker, {quoted: mek})
							})
						})
					/*} else if ((isMedia || isQuotedImage) && colors.includes(args[0])) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await client.downloadAndSaveMediaMessage(encmedia)
						ran = getRandom('.webp')
						await ffmpeg(`./${media}`)
							.on('start', function (cmd) {
								console.log('Started :', cmd)
							})
							.on('error', function (err) {
								fs.unlinkSync(media)
								console.log('Error :', err)
							})
							.on('end', function () {
								console.log('Finish')
								fs.unlinkSync(media)
								client.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
								fs.unlinkSync(ran)
							})
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=${args[0]}@0.0, split [a][b]; [a] palettegen=reserve_transparent=off; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)*/
					} else {
						reply(`Fitur image/Video to Sticker\nSilahkan reply gambar/gif/video pendek, yang ingin anda jadikan sticker\nUntuk gif/video maks 10 detik`)
					}
					break
				case 'gtts':	
				case 'tts':
                                        var itsme = `${numbernye}@s.whatsapp.net`
					var split = `${fake}`
					const mapinng = {
					contextInfo: {
					participant: itsme,
					quotedMessage: {
					extendedTextMessage: {
					text: split,
									}
								}
							}
						}
                                        if (!isUser) return reply(mess.only.daftarB)
					if (args.length < 1) return client.sendMessage(from, `Kirim perintah ${prefix}tts [kode bhs] teks\nContoh : ${prefix}tts id Bagas gans`, MessageType.text, mapinng)
                                        if (isLimit(sender)) return
					const gtts = require('./lib/gtts')(args[0])
					if (args.length < 2) return client.sendMessage(from, '𝗧𝗲𝗸𝘀 𝘆𝗮𝗻𝗴 𝗺𝗮𝘂 𝗱𝗶𝗷𝗮𝗱𝗶𝗶𝗻 𝘀𝘂𝗮𝗿𝗮 𝗺𝗮𝗻𝗮?`', MessageType.text, mapinng)
					dtt = body.slice(8)
					ranm = getRandom('.mp3')
					rano = getRandom('.ogg')
					dtt.length > 300
					? client.sendMessage(from, 'Teks terlalu panjang', MessageType.text, mapinng)
					: gtts.save(ranm, dtt, function() {
						exec(`ffmpeg -i ${ranm} -ar 48000 -vn -c:a libopus ${rano}`, (err) => {
							fs.unlinkSync(ranm)
							bufff = fs.readFileSync(rano)
							if (err) return client.sendMessage(from, '𝗬𝗲𝗮𝗵 𝗴𝗮𝗴𝗮𝗹 ;(, 𝘂𝗹𝗮𝗻𝗴𝗶 𝗹𝗮𝗴𝗶 𝘆𝗮𝗵 ^_^', MessageType.text, mapinng)
							client.sendMessage(from, bufff, audio, {quoted: mek, ptt:true})
							fs.unlinkSync(rano)
                                                      limitAdd(sender)
						})
					})
					break
			case 'setprefix':
                                         var itsme = `${numbernye}@s.whatsapp.net`
					var split = `${fake}`
					const pref = {
					contextInfo: {
					participant: itsme,
					quotedMessage: {
					extendedTextMessage: {
					text: split,
									}
								}
							}
						}
                                        if (!isUser) return reply(mess.only.daftarB)
                                        if (!isOwner) return reply('Fitur ini hanya untuk owner') 
					if (args.length < 1) return client.sendMessage(from, `Kirim perintah ${prefix}setprefix prefix\nContoh : ${prefix}setprefix !`, MessageType.text, pref)
					prefix = args[0]
					client.sendMessage(from, `𝗣𝗿𝗲𝗳𝗶𝘅 𝗯𝗲𝗿??𝗮𝘀𝗶𝗹 𝗱𝗶 𝘂𝗯𝗮𝗵 𝗺𝗲??𝗷𝗮𝗱𝗶 : ${prefix}`, MessageType.text, pref)
					break
				case 'dare':
                   if (!isUser) return reply(mess.only.daftarB)
                  if (isLimit(sender)) return
	    client.updatePresence(from, Presence.composing) 
		client.chatRead (from)
	    dare = [
        'makan 2 sendok nasi tanpa lauk apapun, kalo seret boleh minum',
        'spill orang yang bikin kamu jedag jedug',
        'telfon crush/pacar sekarang dan ss ke pemain',
        'drop emot "🦄💨" setiap ngetik di gc/pc selama 1 hari.',
        'ucapin kata "Selamat datang di Who Wants To Be a Millionaire!" ke semua grup yang kamu punya',
        'marah² ga jelas ke penonton sw kamu urutan 30',
        'telfon mantan bilang kangen',
        'yanyiin reff lagu yang terakhir kamu setel',
        'vn mantan/crush/pacar kamu, bilang hi (namanya), mau telfon dong, bentar ajaa. aku kangen🥺👉🏼👈🏼"',
        'kletekan di meja (yg ada dirumah) sampe lo dimarahin karena berisik',
        'belanjain (grab/gofood) buat salah satu pemain disini, terserah siapa. budget dibawah 25k',
        'Bilang ke random people  "Aku baru saja diberi tahu aku adalah kembaranmu dulu, kita dipisahkan, lalu aku menjalani operasi plastik. Dan ini adalah hal paling ciyussss "',
        'sebutin nama nama mantan',
        'buatin 1 pantun untuk pemain pertama!',
        'ss chat wa',
        'chat random people dengan bahasa alay lalu ss kesini',
        'ceritain hal memalukan versi diri sendiri',
        'tag orang yang dibenci',
        'Pura pura kerasukan, contoh : kerasukan maung, kerasukan belalang, kerasukan kulkas, dll.',
        'ganti nama jadi " BOWO " selama 24 jam',
        'teriak " anjimm gabutt anjimmm " di depan rumah mu',
        'snap/post foto pacar/crush',
        'sebutkan tipe pacar mu!',
        'bilang "i hv crush on you, mau jadi pacarku gak?" ke lawan jenis yang terakhir bgt kamu chat (serah di wa/tele), tunggu dia bales, kalo udah ss drop ke sini',
        'record voice baca surah al-kautsar',
        'prank chat mantan dan bilang " i love u, pgn balikan. " Tanpa ada kata dare!',
        'chat ke kontak wa urutan sesuai %batre kamu, terus bilang ke dia "i lucky to hv you!"',
        'ganti nama menjadi "gue anak lucinta luna" selama 5 jam',
        'ketik pake bahasa sunda 24 jam',
        'pake foto sule sampe 3 hari',
        'drop kutipan lagu/quote, terus tag member yang cocok buat kutipan itu',
        'kirim voice note bilang can i call u baby?',
        'ss recent call whatsapp',
        'Bilang "KAMU CANTIK BANGET NGGAK BOHONG" ke cowo!',
        'pap ke salah satu anggota grup'
    ]
drre = dare[Math.floor(Math.random() * (dare.length))]
client.sendMessage(from, drre, text, {quoted: mek})
limitAdd(sender)
                break
/*case 'anisa':
client.updatePresence(from, Presence.composing) 
anisa = [
'Dia sangean',
'Sadgirl tingkat dewa',
'Dia tiap hari nangis mulu,kamsian aowkw',
'Jomblo abadi',
'maybe dia lesbi',
'Bully nisa'
]
anis = anisa[Math.floor(Math.random() * (anisa.length))]
client.sendMessage(from, anis, text, {quoted: mek})
break*/

                                case 'wa.me':
				  case 'wame':
     if (!isUser) return reply(mess.only.daftarB)
    if (isLimit(sender)) return 
  client.updatePresence(from, Presence.composing) 
      options = {
          text: `「 *API WHATSAPP* 」\n\n_Request by_ : *@${sender.split("@s.whatsapp.net")[0]}\n\nYour link WhatsApp : *wa.me/${sender.split("@s.whatsapp.net")[0]}*\n*Or ( / )*\n*api.whatsapp.com/send?phone=${sender.split("@")[0]}*`,
          contextInfo: { mentionedJid: [sender] }
    }
    client.sendMessage(from, options, text, { quoted: mek } )
      limitAdd(sender)
				break
                                /*case 'tagme':
					var nom = mek.participant
					const tag = {
					text: `@${nom.split("@s.whatsapp.net")[0]} Ku tag kau sayang❤️🗿!`,
					contextInfo: { mentionedJid: [nom] }
					}
					mentions(teks, tag, text, {quoted: mek})
					break*/
				case 'tagall':
                                        if (!isUser) return reply(mess.only.daftarB)
					if (!isGroup) return reply(mess.only.group)
					if (!isOwner && !mek.key.fromMe && !isGroupAdmins) return reply(mess.only.admin)
					members_id = []
					teks = (args.length > 1) ? body.slice(8).trim() : ''
					teks += '\n\n'
					for (let mem of groupMembers) {
						teks += `*#* @${mem.jid.split('@')[0]}\n`
						members_id.push(mem.jid)
					}
					mentions(teks, members_id, true)
					break
				case 'clearall':
					if (!isOwner) return reply(ind.ownerb())
					anu = await client.chats.all()
					client.setMaxListeners(25)
					for (let _ of anu) {
						client.deleteChat(_.jid)
					}
					reply(ind.clears())
				break
			       case 'block':
			        if (!isUser) return reply(mess.only.daftarB) 
			        if (args.length < 1) return reply('Tag target')
					client.updatePresence(from, Presence.composing) 
					if (!isGroup) return reply(mess.only.group)
					if (!isOwner) return reply(mess.only.ownerB)
					client.blockUser (`${body.slice(8)}@c.us`, "add")
					client.sendMessage(from, `perintah Diterima, memblokir ${body.slice(8)}@c.us`, text)
					break
                   case 'unblock':
                   if (!isUser) return reply(mess.only.daftarB) 
                   if (args.length < 1) return reply('Tag target')
					if (!isGroup) return reply(mess.only.group)
					if (!isOwner) return reply(mess.only.ownerB)
				    client.blockUser (`${body.slice(10)}@c.us`, "remove")
					client.sendMessage(from, `𝗽𝗲𝗿𝗶𝗻𝘁𝗮𝗵 𝗗𝗶𝘁𝗲𝗿𝗶𝗺𝗮, 𝗺𝗲𝗺𝗯𝘂𝗸𝗮 ${body.slice(10)}@c.us`, text)
				break
				case 'leave':
                                  if (!isUser) return reply(mess.only.daftarB) 
				if (!isOwner) return reply(ind.ownerb())
                                        if (!isGroup) return reply(mess.only.group)
					if (!isBotGroupAdmins) return reply(mess.only.Badmin)
					//if (!isOwner) return reply(mess.only.ownerB)
				await client.client.leaveGroup(from, '𝗕𝘆𝗲𝗲', groupId)
                    break
                               case 'bcgc':
					client.updatePresence(from, Presence.composing) 
					if (!isOwner) return reply('Fitur ini hanya untuk owner')
					if (args.length < 1) return reply('.......')
					if (isMedia && !mek.message.videoMessage || isQuotedImage) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						buff = await client.downloadMediaMessage(encmedia)
						for (let _ of groupMembers) {
							client.sendMessage(_.jid, buff, image, {caption: `*「 BC GROUP 」*\n*Group* : ${groupName}\n\n${body.slice(6)}`})
						}
						reply('')
					} else {
						for (let _ of groupMembers) {
							sendMess(_.jid, `*「 BC GROUP 」*\n*Group* : ${groupName}\n\n${body.slice(6)}`)
						}
						reply('Suksess broadcast group')
					}
					break
				case 'bc': 
				  var itsme = `${numbernye}@s.whatsapp.net`
				  var split = `${fake}`
				  // var taged = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
				  const bcall = {
				    contextInfo: {
				      participant: itsme,
				      quotedMessage: {
				        extendedTextMessage: {
				          text: split,
				        }
				      }
				    }
				  }
                                         if (!isUser) return reply(mess.only.daftarB)
					if (!isOwner) return reply('Fitur ini hanya untuk owner') 
					if (args.length < 1) return client.sendMessage(from, `Buat broadcast kesemua chat\nContoh : ${prefix}bc Hai`, MessageType.text, bcall)
					anu = await client.chats.all()
					if (isMedia && !mek.message.videoMessage || isQuotedImage) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						buff = await client.downloadMediaMessage(encmedia)
						for (let _ of anu) {
							client.sendMessage(_.jid, buff, image, {caption: `❮ 𝙋𝙀𝙎𝘼𝙉 𝘽𝙍𝙊𝘼𝘿𝘾𝘼𝙎𝙏 ❯\n\n${body.slice(4)}`})
						}
						reply('𝙨𝙪𝙘𝙘𝙚𝙨𝙨 𝙗??𝙤𝙖𝙙𝙘𝙖𝙨𝙩 ')
					} else {
						for (let _ of anu) {
							sendMess(_.jid, `*Bot Broadcast!!*\n\n${body.slice(4)}`)
						}
						reply('𝙨𝙪𝙘*c*𝙚𝙨𝙨 𝙗𝙧𝙤𝙖𝙙𝙘𝙖𝙨𝙩 ')
					}
					break	
										case 'add':
								                case 'a':
								                      reply('Fitur ini sedang dibatasi')
								                    break
                                                                                        /*if (!isUser) return reply(mess.only.daftarB)
                                                                                        if (!isGroup) return reply(mess.only.group)
					                                                if (!isBotGroupAdmins) return reply(mess.only.Badmin)
                                                                                        if (!isGroupAdmins) return reply(mess.only.admin)
											if (args.length < 1) return reply(`Kirim perintah ${prefix}add 62xxx\nCotoh : ${prefix}add 6285717337679`)
											if (args[0].startsWith('08')) return reply('Gunakan kode negara mas')
									   try {
											num = `${args[0].replace(/ /g, '')}@s.whatsapp.net`
											client.groupAdd(from, [num])
											} catch (e) {
											console.log('Error :', e)
											return reply('Diprivate asu:v')
											}
											break*/
									   case 'kick':
								           case 'k':
                                                                                      if (!isUser) return reply(mess.only.daftarB)
				 						      if (!isGroup) return reply(mess.only.group)
					                            if (!isBotGroupAdmins) return reply(mess.only.Badmin)
                                                     if (!isOwner && !mek.key.fromMe && !isGroupAdmins) return reply(mess.only.admin) 
                                           //if (isGroupAdmins) return reply('Bot tidak bisa mengeluarkan admin group')       
											if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('Tag target yang ingin di tendang!')
											mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
											if (mentioned.length > 1) {
											teks = 'Perintah di terima, Menendang\n'
											for (let _ of mentioned) {
											teks += `@${_.split('@')[0]}\n`
											}
											mentions(teks, mentioned, true)
											client.groupRemove(from, mentioned)
											} else {
											mentions(`Success menendang ~> @${mentioned[0].split('@')[0]}`, mentioned, true)
											client.groupRemove(from, mentioned)
											}
											break  
											case 'promote':
                                                                                        if (!isUser) return reply(mess.only.daftarB)
												if (!isGroup) return reply(mess.only.group)
					                           if (!isBotGroupAdmins) return reply(mess.only.Badmin)
                                                 if (!isOwner && !mek.key.fromMe && !isGroupAdmins) return reply(mess.only.admin)
												if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('Tag target yang ingin di jadikan admin!')
												mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
												if (mentioned.length > 1) {
												teks = 'Perintah di terima, Promote :\n'
												for (let _ of mentioned) {
												teks += `@${_.split('@')[0]}\n`
												}
												mentions(teks, mentioned, true)
												client.groupMakeAdmin(from, mentioned)
												} else {
												mentions(`Perintah di terima, Promote : @${mentioned[0].split('@')[0]}`, mentioned, true)
												client.groupMakeAdmin(from, mentioned)
												}
												break
                                              /*case 'opromote':
                                                                                        if (!isUser) return reply(mess.only.daftarB)
												if (!isGroup) return reply(mess.only.group)
					                                                if (!isBotGroupAdmins) return 
                                                                                        if (!isOwner) return reply(mess.only.ownerB)
												if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('Tag target yang ingin di jadikan admin!')
												mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
												if (mentioned.length > 1) {
												tekss = 'Perintah di terima, Promote :\n'
												for (let _ of mentioned) {
												teks += `@${_.split('@')[0]}\n`
												}
												mentions(teks, mentioned, true)
												client.groupMakeAdmin(from, mentioned)
												} else {
												mentions(`Perintah Tuanku di terima, Promote : @${mentioned[0].split('@')[0]}`, mentioned, true)
												client.groupMakeAdmin(from, mentioned)
												}
												break     
      case 'odemote':
                                                                                        if (!isUser) return reply(mess.only.daftarB)
												if (!isGroup) return reply(mess.only.group)
					                                                if (!isBotGroupAdmins) return reply(mess.only.Badmin)
                                                                                        if (!isOwner) return reply(mess.only.ownerB)
												if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('Tag target yang ingin di turunkan jabatannya!')
												mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
												if (mentioned.length > 1) {
												tekss = 'Perintah di terima, Demote :\n'
												for (let _ of mentioned) {
												teks += `@${_.split('@')[0]}\n`
												}
												mentions(teks, mentioned, true)
												client.groupDemoteAdmin(from, mentioned)
												} else {
												mentions(`Perintah Tuanku di terima, Demote : @${mentioned[0].split('@')[0]}`, mentioned, true)
												client.groupDemoteAdmin(from, mentioned)
												}
												break*/                                                                    
											case 'demote':
                                                                                        if (!isUser) return reply(mess.only.daftarB)
												if (!isGroup) return reply(mess.only.group)
					                                                if (!isBotGroupAdmins) return reply(mess.only.Badmin)
                                               if (!isOwner && !mek.key.fromMe && !isGroupAdmins) return reply(mess.only.admin)
												if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('Tag target yang ingin di turunkan jabatannya!')
												mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
												if (mentioned.length > 1) {
												teks = 'Perintah di terima, Demote :\n'
												for (let _ of mentioned) {
												teks += `@${_.split('@')[0]}\n`
												}
												mentions(teks, mentioned, true)
												client.groupDemoteAdmin(from, mentioned)
												} else {
												mentions(`Perintah di terima, Demote : @${mentioned[0].split('@')[0]}`, mentioned, true)
												client.groupDemoteAdmin(from, mentioned)
												}
												break
				case 'listadmin':
                                        if (!isUser) return reply(mess.only.daftarB)
					if (!isGroup) return reply(mess.only.group)
					teks = `𝗟𝗶𝘀𝘁 𝗮𝗱𝗺𝗶𝗻 𝗼𝗳 𝗴𝗿𝗼𝘂𝗽 *${groupMetadata.subject}*\n𝗧𝗼𝘁𝗮𝗹 : ${groupAdmins.length}\n\n`
					no = 0
					for (let admon of groupAdmins) {
						no += 1
						teks += `[${no.toString()}] @${admon.split('@')[0]}\n`
					}
					mentions(teks, groupAdmins, true)
					break
				case 'toimg':
                                case 'toimage':
                                case 'image':
                                         var itsme = `${numbernye}@s.whatsapp.net`
	var split = `${fake}`
	var selepbot = {
		contextInfo: {
		participant: itsme,
		quotedMessage: {
		extendedTextMessage: {
		text: split,
					}
				}
			}
		}
                                        if (!isUser) return reply(mess.only.daftarB)
					if (!isQuotedSticker) return client.sendMessage(from, 'Reply sticker yang ingin dijadikan gambar', MessageType.text, selepbot)
                                        if (isLimit(sender)) return
					encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
					media = await client.downloadAndSaveMediaMessage(encmedia)
					ran = getRandom('.png')
					exec(`ffmpeg -i ${media} ${ran}`, (err) => {
						fs.unlinkSync(media)
						if (err) return reply('Khusus sticker biasa ya,bukan stickergif :)')
						buffer = fs.readFileSync(ran)
						client.sendMessage(from, buffer, image, selepbot)
						fs.unlinkSync(ran)
                                                limitAdd(sender)
					})
					break
				case 'simi':
                                        if (!isUser) return reply(mess.only.daftarB)
					if (args.length < 1) return reply('Textnya mana um?')
					teks = body.slice(5)
					anu = await simih(teks) //fetchJson(`https://mhankbarbars.herokuapp.com/api/samisami?text=${teks}`, {method: 'get'})
					//if (anu.error) return reply('Simi ga tau kak')
					reply(anu)
					break
				case 'simih':
                                        if (!isUser) return reply(mess.only.daftarB)
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (args.length < 1) return reply('ketik 1 untuk mengaktifkan fitur')
					if (Number(args[0]) === 1) {
						if (isSimi) return reply('Mode simi sudah aktif')
						samih.push(from)
						fs.writeFileSync('./src/simi.json', JSON.stringify(samih))
						reply('Sukses mengaktifkan mode simi di group ini ✔️')
					} else if (Number(args[0]) === 0) {
						samih.splice(from, 1)
						fs.writeFileSync('./src/simi.json', JSON.stringify(samih))
						reply('Sukes menonaktifkan mode simi di group ini ✔️')
					} else {
						reply('1 untuk mengaktifkan, 0 untuk menonaktifkan')
					}
					break
				case 'nsfw':
                                        if (!isUser) return reply(mess.only.daftarB)
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (args.length < 1) return reply('𝗧𝗼𝗱 :𝘃')
					if (Number(args[0]) === 1) {
						if (isNsfw) return reply('𝘀𝘂𝗱𝗮𝗵 𝗮𝗸𝘁𝗶𝗳 𝘁𝗼𝗱!!')
						nsfw.push(from)
						fs.writeFileSync('./src/nsfw.json', JSON.stringify(nsfw))
						reply('❬ 𝗦𝗨𝗞𝗦𝗘𝗦 ❭ 𝗠𝗲𝗻𝗴𝗮𝗸𝘁𝗶𝗳??𝗮𝗻 𝗳𝗶𝘁𝘂𝗿 𝗻𝘀𝗳𝘄 𝗱𝗶 𝗴𝗿𝗼𝘂𝗽 𝗶𝗻??')
					} else if (Number(args[0]) === 0) {
						nsfw.splice(from, 1)
						fs.writeFileSync('./src/nsfw.json', JSON.stringify(nsfw))
						reply('❬ 𝗦𝗨𝗞𝗦𝗘𝗦 ❭ 𝗠𝗲𝗻𝗼𝗻𝗮𝗸𝘁𝗶𝗳????𝗻 𝗳𝗶𝘁𝘂𝗿 𝗻𝘀𝗳𝘄 𝗱𝗶 𝗴𝗿𝗼𝘂𝗽 𝗶𝗻𝗶️')
					} else {
						reply(`𝗸𝗲𝘁𝗶𝗸 𝗽𝗲𝗿𝗶𝗻𝘁𝗮𝗵 𝟭 𝘂𝗻𝘁𝘂𝗸 𝗺𝗲𝗻𝗴𝗮𝗸𝘁𝗶𝗳𝗸𝗮??, 𝟬 𝘂𝗻𝘁𝘂𝗸 𝗺𝗲𝗻𝗼𝗻𝗮𝗸𝘁𝗶𝗳𝗸𝗮𝗻\n𝗰𝗼??𝘁𝗼𝗵: ??𝘀𝗳𝘄 𝟭`)
					}
					break
                /*case 'antilink':
                  if (!isUser) return reply(mess.only.daftarB)
                                	if (!isGroup) return reply(mess.only.group)
					if (!isOwner && !mek.key.fromMe && !isGroupAdmins) return reply(mess.only.admin)
					if (!isBotGroupAdmins) return reply(mess.only.Badmin)
					if (args.length < 1) return reply(`Ketik ${prefix}antilink 1 untuk mengaktifkan\nKetik ${prefix}antilink 0 untuk menonaktifkan`)
					if (Number(args[0]) === 1) {
						if (isAntilink) return reply('Anti link group sudah aktif')
						anlink.push(from)
						fs.writeFileSync('./src/antilink.json', JSON.stringify(anlink))
						reply('Sukses mengaktifkan anti link group di group ini ✔️')
						client.sendMessage(from,`Perhatian kepada seluruh member anti link group aktif apabila anda mengirim link group anda akan di kick dari group`, text)
					} else if (Number(args[0]) === 0) {
						if (!isAntilink) return reply('Mode anti link group sudah disable')
						var ini = anlink.indexOf(from)
						anlink.splice(ini, 1)
						fs.writeFileSync('./src/antilink.json', JSON.stringify(anlink))
						reply('Sukses menonaktifkan anti link group di group ini ✔️')
					} else {
						reply('1 untuk mengaktifkan, 0 untuk menonaktifkan')
					}
					break*/
					case 'antilink':
					if (!isUser) return reply(mess.only.daftarB)
				if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (!isBotGroupAdmins) return reply(mess.only.Badmin)
					if (args.length < 1) return reply(`Ketik ${prefix}antilink 1 untuk mengaktifkan\nKetik ${prefix}antilink 0 untuk menonaktifkan`)
					if ((args[0]) === '1') {
						if (isAntiLink) return reply('anti link sudah on')
						antilink.push(from)
						fs.writeFileSync('./src/antilink.json', JSON.stringify(antilink))
						reply(`\`\`\`✓Sukses mengaktifkan fitur anti link di group\`\`\` *${groupMetadata.subject}*`)
					} else if ((args[0]) === '0') {
						if (!isAntiLink) return reply('anti link sudah off')
						var ini = antilink.indexOf(from)
						antilink.splice(ini, 1)
						fs.writeFileSync('./src/antilink.json', JSON.stringify(antilink))
						reply(`\`\`\`✓Sukses menonaktifkan fitur anti link di group\`\`\` *${groupMetadata.subject}*`)
					} else {
						reply('1 untuk mengaktifkan, 0 untuk menonaktifkan')
					}
					break
				case 'welcome':
					if (!isGroup) return reply(mess.only.group)
                                        if (!isUser) return reply(mess.only.daftarB)
					if (!isOwner && !mek.key.fromMe && !isGroupAdmins) return reply(mess.only.admin)
					if (args.length < 1) return reply(`Ketik ${prefix}welcome 1 untuk mengaktifkan\n${prefix}welcome 0 untuk menonaktifkan`)
					if (Number(args[0]) === 1) {
						if (isWelkom) return reply('fitur sudah aktif')
						welkom.push(from)
						fs.writeFileSync('./database/json/welkom.json', JSON.stringify(welkom))
						reply('❬ SUCCSESS ❭ mengaktifkan fitur welcome di group ini')
					} else if (Number(args[0]) === 0) {
						if (!isWelkom) return reply('Fitur ini sudah di nonaktifkan kan')
						var ini = welkom.indexOf(from)
						welkom.splice(ini, 1)
						fs.writeFileSync('./database/json/welkom.json', JSON.stringify(welkom))
						reply('❬ SUCCSESS ❭ menonaktifkan fitur welcome di group ini')
					} else {
						reply('ketik 1 untuk mengaktifkan, 0 untuk menonaktifkan fitur')
					}
                                        break
				case 'clone':
                                        var itsme = `${numbernye}@s.whatsapp.net`
					var split = `${fake}`
					// var taged = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
					const clonne = {
					contextInfo: {
					participant: itsme,
					quotedMessage: {
					extendedTextMessage: {
					text: split,
									}
								}
							}
						}
                                        if (!isUser) return reply(mess.only.daftarB)
                                        if (!isUser) return reply(mess.only.daftarB)
					if (!isGroup) return reply(mess.only.group)
					if (args.length < 1) return client.sendMessage(from, '𝘁𝗮𝗴 𝘁𝗮𝗿𝗴𝗲𝘁 𝘆𝗮𝗻𝗴 𝗺𝗮𝘂 𝗱𝗶 𝗰𝗹𝗼𝗻𝗲!!!', MessageType.text, clonne)
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('Tag cvk')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
					let { jid, id, notify } = groupMembers.find(x => x.jid === mentioned)
					try {
						pp = await client.getProfilePicture(id)
						buffer = await getBuffer(pp)
						client.updateProfilePicture(botNumber, buffer)
						client.sendMessage(from, 'Foto profile Berhasil di perbarui', MessageType.text, clonne)
					} catch (e) {
						client.sendMessage(from, 'Gagal,mungkin dia ga pakai pp', MessageType.text, clonne)
					}
					break
case 'info':
                                        if (!isUser) return reply(mess.only.daftarB)
                                        me = client.user
					uptime = process.uptime()
					teks = `Nama: *${me.name}*\nNomor : @${me.jid.split('@')[0]}\nPrefix : *${prefix}*\nDevice : *Black Shark 3*\nRam : *8/128*\nJaringan : *Indihome*\nTotal Block : *${blocked.length}*\nBot Type : *Baileys*\nUser Terdaftar : *${user.length}*\n\n*Bot Telah Aktif Selama*\n*${kyun(uptime)}*`
					buffer = await getBuffer(me.imgUrl)
					client.sendMessage(from, buffer, image, {caption: teks, contextInfo:{mentionedJid: [me.jid]}})
					break
case 'groupinfo':
case 'ingfogc':
case 'infogc':
case 'gcingfo':
        if (!isUser) return reply(mess.only.daftarB)
	client.updatePresence(from, Presence.composing)
	if (!isGroup) return reply(mess.only.group)
	ppUrl = await client.getProfilePicture(from) // leave empty to get your own
	buffer = await getBuffer(ppUrl)
	client.sendMessage(from, buffer, image, {quoted: mek, caption: `*Name* : ${groupName}\n*Member* : ${groupMembers.length}\n*Admin* : ${groupAdmins.length}\n*Desc* : ${groupDesc}`})
	break
case 'ownergrup':
case 'ownergroup':
case 'ownergc':
        if (!isUser) return reply(mess.only.daftarB)
	client.updatePresence(from, Presence.composing) 
	var itsme = `${numbernye}@s.whatsapp.net`
	hayukkkk = {
	participant: itsme,
	text: `This Group Has been create by @${groupOwner.split("@")[0]}`,
						
	contextInfo: { mentionedJid: [groupOwner] }
	}
	client.sendMessage(from, hayukkkk, text, {quoted: { key: { fromMe: false, participant: `${itsme}`, ...(from ? { remoteJid: from } : {}) }, message: { conversation: `${fake}` }}})
	break
				case 'wait':
                                        var itsme = `${numbernye}@s.whatsapp.net`
					var split = `${fake}`
					// var taged = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
					const nekkko = {
					contextInfo: {
					participant: itsme,
					quotedMessage: {
					extendedTextMessage: {
					text: split,
									}
								}
							}
						}
                                        if (!isUser) return reply(mess.only.daftarB)
					if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
						client.sendMessage(from, 'Pastikan gambar adalah scene anime,sedang mencari', MessageType.text, nekkko)
                                                  if (isLimit(sender)) return
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						media = await client.downloadMediaMessage(encmedia)
						await wait(media).then(res => {
							client.sendMessage(from, res.video, video, {quoted: mek, caption: res.teks.trim()})
						}).catch(err => {
							reply(err)
						})
					} else {
						client.sendMessage(from, 'Reply gambar', MessageType.text, nekkko)
                                               limitAdd(sender)
					}
					break
case 'blocklist':
case 'listblock':
if (!isUser) return reply(mess.only.daftarB)
        teks = '𝗕𝗟𝗢𝗖𝗞 𝗟𝗜𝗦𝗧 :\n'
        for (let block of blocked) {
        teks += `┣➢ @${block.split('@')[0]}\n`
        }
        teks += `𝗧𝗼𝘁𝗮𝗹 : ${blocked.length}`
        client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": blocked}})
        break
case 'listban':
case 'banlist':
					client.updatePresence(from, Presence.composing) 
					if (!isUser) return reply(mess.only.daftarB)
					if (!isOwner) return reply(mess.only.ownerB)
					//if (!isOwner) return reply(mess.only.ownerB)    
					teks = `╭────「 *TOTAL BANLIST* 」\n`
					no = 0
					for (let hehehe of _ban) {
						no += 1
						teks += `[${no.toString()}] @${hehehe.split('@')[0]}\n`
					}
					teks += `│+ Total : ${_ban.length}\n╰──────*⎿ *BOT* ⏋*────`
					client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": _ban}})
					break 
case 'ban':
if (!isUser) return reply(mess.only.daftarB)
                if (!isOwner) return reply(mess.only.ownerB)
                                const arx = body.split(' ')
                if (arx[1] == 'add') {
                                           _ban.push(arx[2] + '@s.whatsapp.net')
                        fs.writeFileSync('./src/banned.json', JSON.stringify(_ban))
                        reply(`Sukses ban ${arx[2]}`)
                } else if (arx[1] == 'del') {
                	var ini = _ban.indexOf(arx[2])
                        _ban.splice(ini + '@s.whatsapp.net', 1)
                        fs.writeFileSync('./src/banned.json', JSON.stringify(_ban))
                        reply('Selesai~')
                } else {
                   reply('Format salah')
                }
            break

                                case 'public':
                                    if (!mek.key.fromMe) return
                                        if (banChats === false) return
                                        var itsme = `${numbernye}@s.whatsapp.net`
                                        var split = `${fake}`
                                        // var taged = ben.message.extendedTextMessage.contextInfo.mentionedJid[0]
                                        const publicc = {
                                        contextInfo: {
                                        participant: '0@s.whatsapp.net',
                                        quotedMessage: {
                                        extendedTextMessage: {
                                        text: split,
                                                                        }
                                                                }
                                                        }
                                                }
                                        banChats = false
                                        client.sendMessage(from, `「 *PUBLICMODE* 」`, text, { quoted: { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "image/jpeg", "caption": " _*SELFBOT - BAGAS*_ ", "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=", "fileLength": "28777", "height": 1080, "width": 1079, "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=", "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=", "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69", "mediaKeyTimestamp": "1610993486", "jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABERERESERMVFRMaHBkcGiYjICAjJjoqLSotKjpYN0A3N0A3WE5fTUhNX06MbmJiboyiiIGIosWwsMX46/j///8BERERERIRExUVExocGRwaJiMgICMmOiotKi0qOlg3QDc3QDdYTl9NSE1fToxuYmJujKKIgYiixbCwxfjr+P/////CABEIADoAUQMBIgACEQEDEQH/xAAsAAEAAwEBAQAAAAAAAAAAAAAAAgMFBAYBAQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAADwYAAAAAEo2EoeggYctbsPMX7XIZPycABZWNvLoHTfnjTo4x0c4AAAAAAAf//EAC0QAAMAAgEDAwIDCQAAAAAAAAECAwQRAAUSMRMhImGSFCCRJEBBQlBRUmOx/9oACAEBAAE/AP3dFLsqjW2IA2QB+p5PHvUoJxdy7FU7VJ7iPcgcM6AMxRtKwVjrwT4B4Y2Hdub/ABRXb28K2tE/Q74+Nead7yZV+BHcNbDglSPodcKsp0wIOgf14mLeisyKCFAJII/ipf8A4vCrKFJBAYbH1Hj8kXWdFdpJUD+RywB+0g8z8N4dXtiQgHxlo5STuyy2qbbmXTHxhjt2SZ6I4yISuzy/17IZudWImmKoT0bvH9pkHc+DpAQxbma/bTqUE2hwEAlUO/eQjiXMARsnTUvAX/EZxgS7vtUQIAF03OjXcdSxJnbLS0kPzddbPbsFCOUFQQKBge1dBv8AEjY/JJ1m4ZpJQDfwbYB+0g8yOvXybpZ8eHm21AfTesgRuXrOpUpjzj9ELnf3luWyTe+Tek0L2ZmPkBSx3teX6lW4uTKS0v7Wou9v7huY/VDj+l24sG9K5vLff8GOv7NzEy/wl43WEneWivd3a7g2w3sRzKyGybeqyKnwRAq70AihB5/on//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQIBAT8AR//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQMBAT8AR//Z", "scansSidecar": "1W0XhfaAcDwc7xh1R8lca6Qg/1bB4naFCSngM2LKO2NoP5RI7K+zLw==" } } } })
                                        break
                                case 'self':
                                    if (!mek.key.fromMe) return
                                        if (banChats === true) return
                                        var itsme = `${numbernye}@s.whatsapp.net`
                                        var split = `${fake}`
                                        // var taged = ben.message.extendedTextMessage.contextInfo.mentionedJid[0]
                                        const selff = {
                                        contextInfo: {
                                        participant: '0@s.whatsapp.net',
                                        quotedMessage: {
                                        extendedTextMessage: {
                                        text: split,
                                                                        }
                                                                }
                                                        }
                                                }
                                        banChats = true
client.sendMessage(from, `「 *SELFMODE* 」`, text, { quoted: { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "image/jpeg", "caption": " _*SELFBOT - BAGAS*_ ", "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=", "fileLength": "28777", "height": 1080, "width": 1079, "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=","fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=", "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69", "mediaKeyTimestamp": "1610993486", "jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABERERESERMVFRMaHBkcGiYjICAjJjoqLSotKjpYN0A3N0A3WE5fTUhNX06MbmJiboyiiIGIosWwsMX46/j///8BERERERIRExUVExocGRwaJiMgICMmOiotKi0qOlg3QDc3QDdYTl9NSE1fToxuYmJujKKIgYiixbCwxfjr+P/////CABEIADoAUQMBIgACEQEDEQH/xAAsAAEAAwEBAQAAAAAAAAAAAAAAAgMFBAYBAQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAADwYAAAAAEo2EoeggYctbsPMX7XIZPycABZWNvLoHTfnjTo4x0c4AAAAAAAf//EAC0QAAMAAgEDAwIDCQAAAAAAAAECAwQRAAUSMRMhImGSFCCRJEBBQlBRUmOx/9oACAEBAAE/AP3dFLsqjW2IA2QB+p5PHvUoJxdy7FU7VJ7iPcgcM6AMxRtKwVjrwT4B4Y2Hdub/ABRXb28K2tE/Q74+Nead7yZV+BHcNbDglSPodcKsp0wIOgf14mLeisyKCFAJII/ipf8A4vCrKFJBAYbH1Hj8kXWdFdpJUD+RywB+0g8z8N4dXtiQgHxlo5STuyy2qbbmXTHxhjt2SZ6I4yISuzy/17IZudWImmKoT0bvH9pkHc+DpAQxbma/bTqUE2hwEAlUO/eQjiXMARsnTUvAX/EZxgS7vtUQIAF03OjXcdSxJnbLS0kPzddbPbsFCOUFQQKBge1dBv8AEjY/JJ1m4ZpJQDfwbYB+0g8yOvXybpZ8eHm21AfTesgRuXrOpUpjzj9ELnf3luWyTe+Tek0L2ZmPkBSx3teX6lW4uTKS0v7Wou9v7huY/VDj+l24sG9K5vLff8GOv7NzEy/wl43WEneWivd3a7g2w3sRzKyGybeqyKnwRAq70AihB5/on//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQIBAT8AR//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQMBAT8AR//Z", "scansSidecar": "1W0XhfaAcDwc7xh1R8lca6Qg/1bB4naFCSngM2LKO2NoP5RI7K+zLw==" } } } })
                                        break
/*ase 'addprem':
					if (!mek.key.fromMe && !isOwner) return      
					addp = body.slice(9)
					_premium.push(`${addp}@s.whatsapp.net`)
					fs.writeFileSync('./database/user/premium.json', JSON.stringify(_premium))
					reply(`Berhasil Menambahkan ${addp} Ke Daftar Premium`)
					break
				case 'dellprem':
					if (!mek.key.fromMe && !isOwner) return      
					oh = body.slice(10)
					var index = _premium.indexOf(oh)
					_premium.splice(index, 1)
					fs.writeFileSync('./database/user/premium.json', JSON.stringify(_premium))
					reply(`Berhasil Menghapus ${oh} Dari Daftar Premium`)
					break
case 'premiumlist':
					client.updatePresence(from, Presence.composing) 
                     if (!mek.key.fromMe && !isOwner) return      
                    if (!isUser) return reply(mess.only.daftarB)
					teks = `╭─「 *JUMLAH USER PREMIUM* 」\n`

					no = 0

					for (let prem of _premium) {

						no += 1

						teks += `│「${no.toString()}」 @${prem.split('@')[0]}\n`

					}

					teks += `│ Jumlah User Premium : ${_premium.length}\n╰──────「 *Bot R* 」`

					client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": _premium}})

					break*/
/*case 'premiumlist':
//if (!isRegistered) return reply(mess.only.Registered)
        teks = '_*PREMIUM LIST*_ :\n'
        for (let tod of _premium) {
        teks += `┣➢ +${_premium}\n`
        }
        teks += `𝗧𝗼𝘁𝗮𝗹 : ${_premium.length}`
        client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": _premium}})
        break*/
                       /*case 'premium':                                 
                               if (!isUser && !mek.key.fromMe) return reply(mess.only.daftarB)                                                                                            
                             if (!mek.key.fromMe && !isOwner) return      
                             const ar = body.split(' ')                                    
                             if (ar[1] == 'add') {                                                      
                            premium.addPremiumUser(args[1] + '@s.whatsapp.net', args[1], _premium)                                                                             
                             reply(`*「 PREMIUM ADDED 」*\n\n➸ *ID*: ${args[2]}@s.whatsapp.net\n➸ *Expired*: ${ms(toMs(args[2])).days} day(s) ${ms(toMs(args[2])).hours} hour(s) ${ms(toMs(args[2])).minutes} minute(s)`)     
                          } else if (ar[1] == 'del') {
                              _premium.splice(premium.getPremiumPosition(args[1] + '@s.whatsapp.net', _premium), 1)
                        fs.writeFileSync('./src/premium.json', JSON.stringify(_premium))              
                                   reply('Sudah selesai')                            
                                } else {                                                         
                                       reply('Format salah!')                                                              }                                                       
                                  break*/
                                case 'status':
                                    var itsme = `${numbernye}@s.whatsapp.net`
                                    var split = `_*SELFMODE Status*_`
                                    client.sendMessage(from, `「 *SELFMODE* 」 *Status:* ${banChats}`, text, { quoted: {
    "key": {
      "remoteJid": "status@broadcast",
      "fromMe": false,
          "participant": `0@s.whatsapp.net`,
      "id": "0D5EAADD1166F55012EB42395DE58D61"
    },
    "message": {
      "productMessage": {
        "product": {
          "productImage": {
            "url": "https://mmg.whatsapp.net/d/f/AsFENZUsypKYO29kpNR2SrgcoBit6mDiApzGccFAPIAq.enc",
            "mimetype": "image/jpeg",
        "fileSha256": "iRrEuDPCvNe6NtOv/n+DARqlS1i2UbWqc25iw+qcwwo=",
        "fileLength": "19247",
        "height": 416,
        "width": 416,
        "mediaKey": "zvebSUI7DcnK9QHuUCJpNAtTsKai0MkvzrcNSYE5pHo=",
        "fileEncSha256": "t6pd+X7iNV/bwtti0KaOOjGBfOVhxPpnwnTs/QnD0Uw=",
        "directPath": "/v/t62.7118-24/29158005_1025181757972162_6878749864442314383_n.enc?oh=c97d5aea20257c3971a7248b339ee42d&oe=60504AC8",
        "mediaKeyTimestamp": "1613162019",
        "jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAvAAACAwEBAAAAAAAAAAAAAAAABQEDBAYCAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAADnZCwvqZrPp3oOWXdtzAuASQmpY4N8rzSt3VYgbKxISJExJ6dI2ku9mhatbOcc8mz4ILAj2Rpo0Su9/NsypC/VazkPRLfaHXmSEra0MbxUB25QAn//xAAlEAACAgEDAwUBAQAAAAAAAAABAgADEQQSIQUTIBAiMTJBI2H/2gAIAQEAAT8A9a1APIyYK7XC4Bj6S7GTLaCQAwxHUqcHwX5miQbsmJBg/ksqRwcia6ntt46RwGEF6LgGdxMZncRhwZ1NwSB4LNPQzgbY9SrVyeZsDUqP8ldLr+zX1rixvBTgzp7cmauxd6KTiIy7Fwc8QsMEzqVgyEHjoG9+Jape/wBy5lJ2gBazLLNlTMZY5dyxPjU5rKsJWi24dTzEGxckzqNv8uPAITMYirkSt7qfrKTbaoLNNUiNisx9MR9TGrdfkQVDEVeI1WZVhWwYEBQECJhE4GBLH3uWh9P/xAAbEQEBAAEFAAAAAAAAAAAAAAABEAACERIgMP/aAAgBAgEBPwDzerOLtAzUEJ//xAAaEQACAgMAAAAAAAAAAAAAAAAAARBBEiAw/9oACAEDAQE/AOaK0UZKGxMqf//Z"
                 },
          "productId": "3958959877488517",
          "title": "@_BagasAlvi_",
          "description": "Kepoluah",
          "currencyCode": "USD",
          "priceAmount1000": "999999999",
          "retailerId": "Kepolu",
          "url": "https://youtube.com/c/bennyhidayat",
          "productImageCount": 2
        },
        "businessOwnerJid": "6289636006352@s.whatsapp.net"
      }
    },
    "messageTimestamp": "1613442626",
    "status": "PENDING"
                                        }})
                                        break
/*case 'setprefix':
                                if (!isUser) return reply(mess.only.daftarB)
                                        if (args.length < 1) return
                                        prefix = args[0]
                                        client.sendMessage(from, `Prefix berhasil di ubah menjadi : ${prefix}`, text, { quoted: { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "image/jpeg", "caption": " _*SELFBOT - BEN*_ ", "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=", "fileLength": "28777", "height": 1080, "width": 1079, "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=", "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=", "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69", "mediaKeyTimestamp": "1610993486", "jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABERERESERMVFRMaHBkcGiYjICAjJjoqLSotKjpYN0A3N0A3WE5fTUhNX06MbmJiboyiiIGIosWwsMX46/j///8BERERERIRExUVExocGRwaJiMgICMmOiotKi0qOlg3QDc3QDdYTl9NSE1fToxuYmJujKKIgYiixbCwxfjr+P/////CABEIADoAUQMBIgACEQEDEQH/xAAsAAEAAwEBAQAAAAAAAAAAAAAAAgMFBAYBAQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAADwYAAAAAEo2EoeggYctbsPMX7XIZPycABZWNvLoHTfnjTo4x0c4AAAAAAAf//EAC0QAAMAAgEDAwIDCQAAAAAAAAECAwQRAAUSMRMhImGSFCCRJEBBQlBRUmOx/9oACAEBAAE/AP3dFLsqjW2IA2QB+p5PHvUoJxdy7FU7VJ7iPcgcM6AMxRtKwVjrwT4B4Y2Hdub/ABRXb28K2tE/Q74+Nead7yZV+BHcNbDglSPodcKsp0wIOgf14mLeisyKCFAJII/ipf8A4vCrKFJBAYbH1Hj8kXWdFdpJUD+RywB+0g8z8N4dXtiQgHxlo5STuyy2qbbmXTHxhjt2SZ6I4yISuzy/17IZudWImmKoT0bvH9pkHc+DpAQxbma/bTqUE2hwEAlUO/eQjiXMARsnTUvAX/EZxgS7vtUQIAF03OjXcdSxJnbLS0kPzddbPbsFCOUFQQKBge1dBv8AEjY/JJ1m4ZpJQDfwbYB+0g8yOvXybpZ8eHm21AfTesgRuXrOpUpjzj9ELnf3luWyTe+Tek0L2ZmPkBSx3teX6lW4uTKS0v7Wou9v7huY/VDj+l24sG9K5vLff8GOv7NzEy/wl43WEneWivd3a7g2w3sRzKyGybeqyKnwRAq70AihB5/on//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQIBAT8AR//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQMBAT8AR//Z", "scansSidecar": "1W0XhfaAcDwc7xh1R8lca6Qg/1bB4naFCSngM2LKO2NoP5RI7K+zLw==" } } } })
                                        break*/
                                /*case 'meme':
                                if (!isRegistered) return reply(mess.only.Registered)
                                        anj = await fetchJson(`https://api.zeks.xyz/api/memeindo?apikey=apivinz`, {method: 'get'})
                                        beffer = await getBuffer(anj.result)
                                        benny.sendMessage(from, beffer, image, { quoted: { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "image/jpeg", "caption": " _*SELFBOT - BEN*_ ", "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=", "fileLength": "28777", "height": 1080, "width": 1079, "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=", "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=", "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69", "mediaKeyTimestamp": "1610993486", "jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABERERESERMVFRMaHBkcGiYjICAjJjoqLSotKjpYN0A3N0A3WE5fTUhNX06MbmJiboyiiIGIosWwsMX46/j///8BERERERIRExUVExocGRwaJiMgICMmOiotKi0qOlg3QDc3QDdYTl9NSE1fToxuYmJujKKIgYiixbCwxfjr+P/////CABEIADoAUQMBIgACEQEDEQH/xAAsAAEAAwEBAQAAAAAAAAAAAAAAAgMFBAYBAQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAADwYAAAAAEo2EoeggYctbsPMX7XIZPycABZWNvLoHTfnjTo4x0c4AAAAAAAf//EAC0QAAMAAgEDAwIDCQAAAAAAAAECAwQRAAUSMRMhImGSFCCRJEBBQlBRUmOx/9oACAEBAAE/AP3dFLsqjW2IA2QB+p5PHvUoJxdy7FU7VJ7iPcgcM6AMxRtKwVjrwT4B4Y2Hdub/ABRXb28K2tE/Q74+Nead7yZV+BHcNbDglSPodcKsp0wIOgf14mLeisyKCFAJII/ipf8A4vCrKFJBAYbH1Hj8kXWdFdpJUD+RywB+0g8z8N4dXtiQgHxlo5STuyy2qbbmXTHxhjt2SZ6I4yISuzy/17IZudWImmKoT0bvH9pkHc+DpAQxbma/bTqUE2hwEAlUO/eQjiXMARsnTUvAX/EZxgS7vtUQIAF03OjXcdSxJnbLS0kPzdbPbsFCOUFQQKBge1dBv8AEjY/JJ1m4ZpJQDfwbYB+0g8yOvXybpZ8eHm21AfTesgRuXrOpUpjzj9ELnf3luWyTe+Tek0L2ZmPkBSx3teX6lW4uTKS0v7Wou9v7huY/VDj+l24sG9K5vLff8GOv7NzEy/wl43WEneWivd3a7g2w3sRzKyGybeqyKnwRAq70AihB5/on//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQIBAT8AR//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQMBAT8AR//Z", "scansSidecar": "1W0XhfaAcDwc7xh1R8lca6Qg/1bB4naFCSngM2LKO2NoP5RI7K+zLw==" } } } })
                         break*/
                                /*case 'dare':
                                if (!isRegistered) return reply(mess.only.Registered)
            benny.updatePresence(from, Presence.composing)
                benny.chatRead (from)
            dare = [
        'makan 2 sendok nasi tanpa lauk apapun, kalo seret boleh minum',
        'spill orang yang bikin kamu jedag jedug',
        'telfon crush/pacar sekarang dan ss ke pemain',
        'drop emot "🦄💨" setiap ngetik di gc/pc selama 1 hari.',
        'ucapin kata "Selamat datang di Who Wants To Be a Millionaire!" ke semua grup yang kamu punya',
        'marah² ga jelas ke penonton sw kamu urutan 30',
        'telfon mantan bilang kangen',
        'yanyiin reff lagu yang terakhir kamu setel',
        'vn mantan/crush/pacar kamu, bilang hi (namanya), mau telfon dong, bentar ajaa. aku kangen� 👉🏼👈🏼"',
        'kletekan di meja (yg ada dirumah) sampe lo dimarahin karena berisik',
        'belanjain (grab/gofood) buat salah satu pemain disini, terserah siapa. budget dibawah 25k',
        'Bilang ke random people  "Aku baru saja diberi tahu aku adalah kembaranmu dulu, kita dipisahkan, lalu aku menjalani operasi plastik. Dan ini adalah hal paling ciyussss "',
        'sebutin nama nama mantan',
        'buatin 1 pantun untuk pemain pertama!',
        'ss chat wa',
        'chat random people dengan bahasa alay lalu ss kesini',
        'ceritain hal memalukan versi diri sendiri',
        'tag orang yang dibenci',
        'Pura pura kerasukan, contoh : kerasukan maung, kerasukan belalang, kerasukan kulkas, dll.',
        'ganti nama jadi " BOWO " selama 24 jam',
        'teriak " anjimm gabutt anjimmm " di depan rumah mu',
        'snap/post foto pacar/crush',
        'sebutkan tipe pacar mu!',
        'bilang "i hv crush on you, mau jadi pacarku gak?" ke lawan jenis yang terakhir bgt kamu chat (serah di wa/tele), tunggu dia bales, kalo udah ss drop ke sini',
        'record voice baca surah al-kautsar',
        'prank chat mantan dan bilang " i love u, pgn balikan. " Tanpa ada kata dare!',
        'chat ke kontak wa urutan sesuai %batre kamu, terus bilang ke dia "i lucky to hv you!"',
        'ganti nama menjadi "gue anak lucinta luna" selama 5 jam',
        'ketik pake bahasa sunda 24 jam',
        'pake foto sule sampe 3 hari',
        'drop kutipan lagu/quote, terus tag member yang cocok buat kutipan itu',
        'kirim voice note bilang can i call u baby?',
        'ss recent call whatsapp',
        'Bilang "KAMU CANTIK BANGET NGGAK BOHONG" ke cowo!',
        'pap ke salah satu anggota grup'
    ]
drre = dare[Math.floor(Math.random() * (dare.length))]
benny.sendMessage(from, drre, text, {quoted: ben})
                break*/
/*case 'memeindo':
                                                                if (!isRegistered) return reply(mess.only.Registered)
                                        memein = await kagApi.memeindo()
                                        buffer = await getBuffer(`https://imgur.com/${memein.hash}.jpg`)
                                        benny.sendMessage(from, buffer, image, {quoted: ben, caption: '.......'})
                                        break*/
                                /*case 'tagme':
                                                                if (!isUser) return reply(mess.only.daftarB)
                                        var nom = ben.participant
                                        const tag = {
                                        text: `@${nom.split("@s.whatsapp.net")[0]} Ku tag kau sayang❤️🗿!`,
                                        contextInfo: { mentionedJid: [nom] }
                                        }
                                        client.sendMessage(from, tag, text, {quoted: ben})
                                        break*/
                                case 'tagall':
                                if (!isUser) return reply(mess.only.daftarB)
                                        if (!isGroup) return reply(mess.only.group)
                                        if (!isGroupAdmins) return reply(mess.only.admin)
                                        members_id = []
                                        teks = (args.length > 1) ? body.slice(8).trim() : ''
                                        teks += '\n\n'
                                        for (let mem of groupMembers) {
                                                teks += `*#* @${mem.jid.split('@')[0]}\n`
                                                members_id.push(mem.jid)
                                        }
                                        mentions(teks, members_id, true)
                                        break
                                /*case 'kickall':
                                if (!isUser) return reply(mess.only.daftarB)
                                        if (!isGroup) return reply(mess.only.group)
                                        if (!isGroupAdmins) return reply(mess.only.admin)
                                        if (!isBotGroupAdmins) return reply(mess.only.Badmin)
                                        const allMem = groupMembers
                                        for (let i = 0; i < allMem.length; i++) {
                    benny.groupRemove(groupId, allMem[i])
                                        }
                                        mentions(`Success menendang ~> @${members_id[0].split('@')[0]}`, mentioned, true)
                                        client.groupRemove(from, allMem[i])
                                        break*/
                                case 'clearall':
                                if (!isUser) return reply(mess.only.daftarB)
                                        if (!isOwner) return reply('lu siapa?')
                                        anu = await benny.chats.all()
                                        benny.setMaxListeners(25)
                                        for (let _ of anu) {
                                                client.deleteChat(_.jid)
                                        }
                                        reply('clear all sukses :)')
                                        break
                               case 'block':
                                   if (!isUser) return reply(mess.only.daftarB)
                                        if (!isGroup) return reply(mess.only.group)
                                        if (!isOwner) return reply(mess.only.ownerB)
                                        client.blockUser (`${body.slice(7)}@c.us`, "add")
                                        client.sendMessage(from, `Perintah Diterima, memblokir ${body.slice(7)}@c.us`, text, { quoted: { key:{ fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "image/jpeg", "caption": " _*SELFBOT - BEN*_ ", "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=", "fileLength": "28777", "height": 1080, "width": 1079, "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=", "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=", "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69", "mediaKeyTimestamp": "1610993486", "jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABERERESERMVFRMaHBkcGiYjICAjJjoqLSotKjpYN0A3N0A3WE5fTUhNX06MbmJiboyiiIGIosWwsMX46/j///8BERERERIRExUVExocGRwaJiMgICMmOiotKi0qOlg3QDc3QDdYTl9NSE1fToxuYmJujKKIgYiixbCwxfjr+P/////CABEIADoAUQMBIgACEQEDEQH/xAAsAAEAAwEBAQAAAAAAAAAAAAAAAgMFBAYBAQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAADwYAAAAAEo2EoeggYctbsPMX7XIZPycABZWNvLoHTfnjTo4x0c4AAAAAAAf//EAC0QAAMAAgEDAwIDCQAAAAAAAAECAwQRAAUSMRMhImGSFCCRJEBBQlBRUmOx/9oACAEBAAE/AP3dFLsqjW2IA2QB+p5PHvUoJxdy7FU7VJ7iPcgcM6AMxRtKwVjrwT4B4Y2Hdub/ABRXb28K2tE/Q74+Nead7yZV+BHcNbDglSPodcKsp0wIOgf14mLeisyKCFAJII/ipf8A4vCrKFJBAYbH1Hj8kXWdFdpJUD+RywB+0g8z8N4dXtiQgHxlo5STuyy2qbbmXTHxhjt2SZ6I4yISuzy/17IZudWImmKoT0bvH9pkHc+DpAQxbma/bTqUE2hwEAlUO/eQjiXMARsnTUvAX/EZxgS7vtUQIAF03OjXcdSxJnbLS0kPzddbPbsFCOUFQQKBge1dBv8AEjY/JJ1m4ZpJQDfwbYB+0g8yOvXybpZ8eHm21AfTesgRuXrOpUpjzj9ELnf3luWyTe+Tek0L2ZmPkBSx3teX6lW4uTKS0v7Wou9v7huY/VDj+l24sG9K5vLff8GOv7NzEy/wl43WEneWivd3a7g2w3sRzKyGybeqyKnwRAq70AihB5/on//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQIBAT8AR//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQMBAT8AR//Z", "scansSidecar": "1W0XhfaAcDwc7xh1R8lca6Qg/1bB4naFCSngM2LKO2NoP5RI7K+zLw==" } } } })
                                        break
                    /*'case 'unblock':
                                        if (!isUser) return reply(mess.only.daftarB)
                                        if (!isGroup) return reply(mess.only.group)
                                        if (!isOwner) return reply(mess.only.ownerB)
                                    client.blockUser (`${body.slice(9)}@c.us`, "remove")
                                        client.sendMessage(from, `𝗽𝗲𝗿𝗶𝗻𝘁𝗮𝗵 𝗗𝗶𝘁𝗲𝗿𝗶𝗺𝗮, 𝗺𝗲𝗺𝗯𝘂??𝗮 ${body.slice(9)}@c.us`, text)
                                break'*/
                               /* case 'leave':
                                if (!isRegistered) return reply(mess.only.Registered)
                                if (!isGroup) return reply(mess.only.group)
                                        if (!isOwner) return reply(mess.only.ownerB)
                                        sendMessage(from, 'Dadah', text, { quoted: { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "image/jpeg", "caption": " _*SELFBOT - BEN*_ ", "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=", "fileLength": "28777", "height": 1080, "width": 1079, "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=", "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=", "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69", "mediaKeyTimestamp": "1610993486", "jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABERERESERMVFRMaHBkcGiYjICAjJjoqLSotKjpYN0A3N0A3WE5fTUhNX06MbmJiboyiiIGIosWwsMX46/j///8BERERERIRExUVExocGRwaJiMgICMmOiotKi0qOlg3QDc3QDdYTl9NSE1fToxuYmJujKKIgYiixbCwxfjr+P/////CABEIADoAUQMBIgACEQEDEQH/xAAsAAEAAwEBAQAAAAAAAAAAAAAAAgMFBAYBAQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAADwYAAAAAEo2EoeggYctbsPMX7XIZPycABZWNvLoHTfnjTo4x0c4AAAAAAAf//EAC0QAAMAAgEDAwIDCQAAAAAAAAECAwQRAAUSMRMhImGSFCCRJEBBQlBRUmOx/9oACAEBAAE/AP3dFLsqjW2IA2QB+p5PHvUoJxdy7FU7VJ7iPcgcM6AMxRtKwVjrwT4B4Y2Hdub/ABRXb28K2tE/Q74+Nead7yZV+BHcNbDglSPodcKsp0wIOgf14mLeisyKCFAJII/ipf8A4vCrKFJBAYbH1Hj8kXWdFdpJUD+RywB+0g8z8N4dXtiQgHxlo5STuyy2qbbmXTHxhjt2SZ6I4yISuzy/17IZudWImmKoT0bvH9pkHc+DpAQxbma/bTqUE2hwEAlUO/eQjiXMARsnTUvAX/EZxgS7vtUQIAF03OjXcdSxJnbLS0kPzddbPbsFCOUFQQKBge1dBv8AEjY/JJ1m4ZpJQDfwbYB+0g8yOvXybpZ8eHm21AfTesgRuXrOpUpjzj9ELnf3luWyTe+Tek0L2ZmPkBSx3teX6lW4uTKS0v7Wou9v7huY/VDj+l24sG9K5vLff8GOv7NzEy/wl43WEneWivd3a7g2w3sRzKyGybeqyKnwRAq70AihB5/on//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQIBAT8AR//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQMBAT8AR//Z", "scansSidecar": "1W0XhfaAcDwc7xh1R8lca6Qg/1bB4naFCSngM2LKO2NoP5RI7K+zLw==" } } } })
                                await benny.benny.leaveGroup(from, '𝗕𝘆𝗲𝗲', groupId)
                    break*/
                                /*case 'bc':
                                if (!isRegistered) return reply(mess.only.Registered)
                                        if (!isOwner) return reply('𝙡𝙪 𝙨𝙞𝙖𝙥𝙖 𝙩𝙤𝙙?')
                                        if (args.length < 1) return reply('.......')
                                        anu = await benny.chats.all()
                                        if (isMedia && !ben.message.videoMessage || isQuotedImage) {
                                                const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(ben).replace('quotedM','m')).message.extendedTextMessage.contextInfo : ben
                                                buff = await benny.downloadMediaMessage(encmedia)
                                                for (let _ of anu) {
                                                        benny.sendMessage(_.jid, buff, image, {caption: `❮ 𝙋𝙀𝙎𝘼𝙉 ??𝙍𝙊𝘼𝘿𝘾𝘼𝙎𝙏 ❯\n\n${body.slice(4)}`})
                                                }
                                                reply('𝙨????𝙘𝙚𝙨𝙨 𝙗𝙧𝙤𝙖𝙙𝙘𝙖𝙨𝙩 ')
                                        } else {
                                                for (let _ of anu) {
                                                        sendMess(_.jid, `*SELF Broadcast!!*\n\n${body.slice(4)}`)
                                                }
                                                reply('𝙨𝙪𝙘𝙘𝙚𝙨𝙨 𝙗𝙧𝙤𝙖𝙙𝙘𝙖𝙨𝙩 ')
                                        }
                                        break*/
/*case 'add':
                                                                                if (!ben.key.fromMe) return
                                                                                if (!isRegistered) return reply(mess.only.Registered)
                                                                                        if (!isGroup) return reply(mess.only.group)
                                                                                        if (!isBotGroupAdmins) return reply(mess.only.Badmin)
                                                                                        if (args.length < 1) return reply('Yang mau di add jin ya?')
                                                                                        if (args[0].startsWith('08')) return reply('Gunakan kode negara mas')
                                                                           try {
                                                                                        num = `${args[0].replace(/ /g, '')}@s.whatsapp.net`
                                                                                        benny.groupAdd(from, [num])
                                                                                        } catch (e) {
                                                                                        console.log('Error :', e)
                                                                                        return reply('Diprivate asu:v')
                                                                                        }
                                                                                        break
                                                                           case 'kick':
                                                                           if (!isRegistered) return reply(mess.only.Registered)
                                                                                        if (!isGroup) return reply(mess.only.group)
                                                                                        if (!isBotGroupAdmins) return reply(mess.only.Badmin)
                                                                                        if (ben.message.extendedTextMessage === undefined ||ben.message.extendedTextMessage === null) return reply('Tag target yang ingin di tendang!')
                                                                                        mentioned = ben.message.extendedTextMessage.contextInfo.mentionedJid
                                                                                        if (mentioned.length > 1) {
                                                                                        teks = 'Perintah di terima, Menendang\n'
                                                                                        for (let _ of mentioned) {
                                                                                        teks += `@${_.split('@')[0]}\n`
                                                                                        }
                                                                                        mentions(teks, mentioned, true)
                                                                                        benny.groupRemove(from, mentioned)
                                                                                        } else {
                                                                                        mentions(`Success menendang ~> @${mentioned[0].split('@')[0]}`, mentioned, true)
                                                                                        benny.groupRemove(from, mentioned)
                                                                                        }
                                                                                        break
                                                                                        case 'promote':
                                                                                        if (!isRegistered) return reply(mess.only.Registered)
                                                                                                if (!isGroup) return reply(mess.only.group)
                                                                                                if (!isBotGroupAdmins) return reply(mess.only.Badmin)
                                                                                                if (ben.message.extendedTextMessage === undefined || ben.message.extendedTextMessage === null) return reply('Tag target yang ingin di tendang!')
                                                                                                mentioned = ben.message.extendedTextMessage.contextInfo.mentionedJid
                                                                                                if (mentioned.length > 1) {
                                                                                                teks = 'Perintah di terima, Promote :\n'
                                                                                                for (let _ of mentioned) {
                                                                                                teks += `@${_.split('@')[0]}\n`
                                                                                                }
                                                                                                mentions(teks, mentioned, true)
                                                                                                benny.groupMakeAdmin(from, mentioned)
                                                                                                } else {
                                                                                                mentions(`Perintah di terima, Promote : @${mentioned[0].split('@')[0]}`, mentioned, true)
                                                                                                benny.groupMakeAdmin(from, mentioned)
                                                                                                }
                                                                                                break
                                                                                        case 'demote':
                                                                                        if (!isRegistered) return reply(mess.only.Registered)
                                                                                                if (!isGroup) return reply(mess.only.group)
                                                                                                if (!isBotGroupAdmins) return reply(mess.only.Badmin)
                                                                                                if (ben.message.extendedTextMessage === undefined || ben.message.extendedTextMessage === null) return reply('Tag target yang ingin di tendang!')
                                                                                                mentioned = ben.message.extendedTextMessage.contextInfo.mentionedJid
                                                                                                if (mentioned.length > 1) {
                                                                                                teks = 'Perintah di terima, Demote :\n'
                                                                                                for (let _ of mentioned) {
                                                                                                teks += `@${_.split('@')[0]}\n`
                                                                                                }
                                                                                                mentions(teks, mentioned, true)
                                                                                                benny.groupDemoteAdmin(from, mentioned)
                                                                                                } else {
                                                                                                mentions(`Perintah di terima, Demote : @${mentioned[0].split('@')[0]}`, mentioned, true)
                                                                                                benny.groupDemoteAdmin(from, mentioned)
                                                                                                }
                                                                                                break
                                case 'listadmin':
                                if (!isRegistered) return reply(mess.only.Registered)
                                        if (!isGroup) return reply(mess.only.group)
                                        teks = `𝗟𝗶𝘀𝘁 𝗮𝗱𝗺𝗶𝗻 𝗼𝗳 𝗴𝗿𝗼𝘂𝗽 *${groupMetadata.subject}*\n𝗧𝗼𝘁𝗮𝗹 : ${groupAdmins.length}\n\n`
                                        no = 0
                                        for (let admon of groupAdmins) {
                                                no += 1
                                                teks += `[${no.toString()}] @${admon.split('@')[0]}\n`
                                        }
                                        mentions(teks, groupAdmins, true)
                                        break
                                case 'toimg':
                                if (!isRegistered) return reply(mess.only.Registered)
                                        if (!isQuotedSticker) return reply('stickernya mana anjeng')
                                        benny.sendMessage(from, mess.wait, text, { quoted: {
                                        "key": {
      "remoteJid": "status@broadcast",
      "fromMe": false,
          "participant": `0@s.whatsapp.net`,
      "id": "0D5EAADD1166F55012EB42395DE58D61"
    },
    "message": {
      "productMessage": {
        "product": {
          "productImage": {
            "url": "https://mmg.whatsapp.net/d/f/AsFENZUsypKYO29kpNR2SrgcoBit6mDiApzGccFAPIAq.enc",
            "mimetype": "image/jpeg",
        "fileSha256": "iRrEuDPCvNe6NtOv/n+DARqlS1i2UbWqc25iw+qcwwo=",
        "fileLength": "19247",
        "height": 416,
        "width": 416,
        "mediaKey": "zvebSUI7DcnK9QHuUCJpNAtTsKai0MkvzrcNSYE5pHo=",
        "fileEncSha256": "t6pd+X7iNV/bwtti0KaOOjGBfOVhxPpnwnTs/QnD0Uw=",
        "directPath": "/v/t62.7118-24/29158005_1025181757972162_6878749864442314383_n.enc?oh=c97d5aea20257c3971a7248b339ee42d&oe=60504AC8",
        "mediaKeyTimestamp": "1613162019",
        "jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAvAAACAwEBAAAAAAAAAAAAAAAABQEDBAYCAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAADnZCwvqZrPp3oOWXdtzAuASQmpY4N8rzSt3VYgbKxISJExJ6dI2ku9mhatbOcc8mz4ILAj2Rpo0Su9/NsypC/VazkPRLfaHXmSEra0MbxUB25QAn//xAAlEAACAgEDAwUBAQAAAAAAAAABAgADEQQSIQUTIBAiMTJBI2H/2gAIAQEAAT8A9a1APIyYK7XC4Bj6S7GTLaCQAwxHUqcHwX5miQbsmJBg/sqRwcia6ntt46RwGEF6LgGdxMZncRhwZ1NwSB4LNPQzgbY9SrVyeZsDUqP8ldLr+zX1rixvBTgzp7cmauxd6KTiIy7Fwc8QsMEzqVgyEHjoG9+Jape/wBy5lJ2gBazLLNlTMZY5dyxPjU5rKsJWi24dTzEGxckzqNv8uPAITMYirkSt7qfrKTbaoLNNUiNisx9MR9TGrdfkQVDEVeI1WZVhWwYEBQECJhE4GBLH3uWh9P/xAAbEQEBAAEFAAAAAAAAAAAAAAABEAACERIgMP/aAAgBAgEBPwDzerOLtAzUEJ//xAAaEQACAgMAAAAAAAAAAAAAAAAAARBBEiAw/9oACAEDAQE/AOaK0UZKGxMqf//Z"
                 },
          "productId": "3958959877488517",
          "title": "@_benny_hidayat_",
          "description": "Kepoluah",
          "currencyCode": "USD",
          "priceAmount1000": "999999999",
          "retailerId": "Kepolu",
          "url": "https://youtube.com/c/bennyhidayat",
          "productImageCount": 2
        },
        "businessOwnerJid": "6289636006352@s.whatsapp.net"
      }
    },
    "messageTimestamp": "1613442626",
    "status": "PENDING"
                                        }})
                                        encmedia = JSON.parse(JSON.stringify(ben).replace('quotedM','m')).message.extendedTextMessage.contextInfo
                                        media = await benny.downloadAndSaveMediaMessage(encmedia)
                                        ran = getRandom('.png')
                                        exec(`ffmpeg -i ${media} ${ran}`, (err) => {
                                                fs.unlinkSync(media)
                                                if (err) return reply('Error om')
                                                buffer = fs.readFileSync(ran)
                                                benny.sendMessage(from, buffer, image, {quoted: ben, caption: 'Dah jdi nih bang'})
                                                fs.unlinkSync(ran)
                                        })
                                        break
                                case 'simi':
                                if (!isRegistered) return reply(mess.only.Registered)
                                        if (args.length < 1) return reply('𝗸𝗮𝘀𝗶𝗵 𝘁𝗲𝗸𝘀 𝗹𝗮𝗵 𝘁𝗼𝗱!!!')
                                        teks = body.slice(5)
                                        anu = await fetchJson(`https://vinz.zeks.xyz/api/sim?q=${teks}&apikey=apivinz`, {method: 'get'})
                                        if (anu.error) return reply('Simi ga tau kak')
                                        benny.sendMessage(from, `${anu.result.success}`, text, { quoted: { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "image/jpeg", "caption": " _*SimSimi*_ ", "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=", "fileLength": "28777", "height": 1080, "width": 1079, "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=", "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=", "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69", "mediaKeyTimestamp": "1610993486", "jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABERERESERMVFRMaHBkcGiYjICAjJjoqLSotKjpYN0A3N0A3WE5fTUhNX06MbmJiboyiiIGIosWwsMX46/j///8BERERERIRExUVExocGRwaJiMgICMmOiotKi0qOlg3QDc3QDdYTl9NSE1fToxuYmJujKKIgYiixbCwxfjr+P/////CABEIADoAUQMBIgACEQEDEQH/xAAsAAEAAwEBAQAAAAAAAAAAAAAAAgMFBAYBAQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAADwYAAAAAEo2EoeggYctbsPMX7XIZPycABZWNvLoHTfnjTo4x0c4AAAAAAAf//EAC0QAAMAAgEDAwIDCQAAAAAAAAECAwQRAAUSMRMhImGSFCCRJEBBQlBRUmOx/9oACAEBAAE/AP3dFLsqjW2IA2QB+p5PHvUoJxdy7FU7VJ7iPcgcM6AMxRtKwVjrwT4B4Y2Hdub/ABRXb28K2tE/Q74+Nead7yZV+BHcNbDglSPodcKsp0wIOgf14mLeisyKCFAJII/ipf8A4vCrKFJBAYbH1Hj8kXWdFdpJUD+RywB+0g8z8N4dXtiQgHxlo5STuyy2qbbmXTHxhjt2SZ6I4yISuzy/17IZudWImmKoT0bvH9pkHc+DpAQxbma/bTqUE2hwEAlUO/eQjiXMARsnTUvAX/EZxgS7vtUQIAF03OjXcdSxJnbLS0kPzddbPbsFCOUFQQKBge1dBv8AEjY/JJ1m4ZpJQDfwbYB+0g8yOvXybpZ8eHm21AfTesgRuXrOpUpjzj9ELnf3luWyTe+Tek0L2ZmPkBSx3teX6lW4uTKS0v7Wou9v7huY/VDj+l24sG9K5vLff8GOv7NzEy/wl43WEneWivd3a7g2w3sRzKyGybeqyKnwRAq70AihB5/on//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQIBAT8AR//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQMBAT8AR//Z", "scansSidecar": "1W0XhfaAcDwc7xh1R8lca6Qg/1bB4naFCSngM2LKO2NoP5RI7K+zLw==" } } } })
                        break
                                case 'simih':
                                if (!isRegistered) return reply(mess.only.Registered)
                                        if (!isGroup) return reply(mess.only.group)
                                        if (!isGroupAdmins) return reply(mess.only.admin)
                                        if (args.length < 1) return reply('𝗧𝗼𝗱 :??')
                                        if (Number(args[0]) === 1) {
                                                if (isSimi) return reply('𝘀𝘂𝗱𝗮𝗵 𝗮𝗸𝘁𝗶𝗳 𝘁𝗼𝗱!!!')
                                                samih.push(from)
                                                fs.writeFileSync('./src/simi.json', JSON.stringify(samih))
                                                reply('❬ 𝗦𝗨𝗞𝗦𝗘𝗦 ❭ 𝗠𝗲𝗻𝗴𝗮𝗸𝘁𝗶𝗳𝗸𝗮𝗻 𝗳𝗶𝘁𝘂𝗿 𝘀𝗶𝗺𝗶 𝗱𝗶 𝗴𝗿????𝗽 𝗶𝗻𝗶️')
                                        } else if (Number(args[0]) === 0) {
                                                samih.splice(from, 1)
                                                fs.writeFileSync('./src/simi.json', JSON.stringify(samih))
                                                reply('❬ 𝗦𝗨𝗞𝗦𝗘𝗦 ❭ 𝗠𝗲𝗻𝗼𝗻𝗮𝗸𝘁𝗶𝗳𝗸𝗮𝗻 𝗳𝗶𝘁𝘂𝗿 𝘀𝗶𝗺𝗶 ??𝗶 𝗴𝗿𝗼𝘂𝗽 𝗶𝗻𝗶️️')
                                        } else {
                                                reply('𝗸𝗲𝘁𝗶𝗸 𝗽𝗲𝗿𝗶𝗻𝘁𝗮𝗵 𝟭 𝘂𝗻𝘁𝘂𝗸 𝗺𝗲𝗻𝗴𝗮𝗸𝘁𝗶𝗳𝗸𝗮𝗻, 𝟬 𝘂𝗻??𝘂𝗸 𝗺𝗲𝗻𝗼𝗻𝗮𝗸𝘁𝗶𝗳𝗸𝗮𝗻\n𝗰𝗼𝗻𝘁𝗼𝗵: 𝘀𝗶𝗺𝗶𝗵 𝟭')
                                        }
                                        break*/
                                case 'antidelete':
                                reply('Premium fitur,chat me to buy wa.me/6285717337679')
                                        break
                                break                     
                                case 'antivirtext':
                                if (!isUser) return reply(mess.only.daftarB)
                                        if (!isGroup) return reply(mess.only.group)
                                        if (!isBotGroupAdmins) return reply('Jadikan bot admin terlebih dahulu!')
                                            if (!isOwner && !mek.key.fromMe && !isGroupAdmins) return reply(mess.only.admin)
                                        if (args.length < 1) return reply(`Kirim perintah ${prefix}antivirtext 1 untuk mengaktifkan\nKetik ${prefix}antivirtext 0 untuk menonaktifkan`)
                                        const argt = body.split(' ')
                                        if (argt[1] == '1') {
                                                if (isKasar) return reply('Sudah aktif')
                                                kasar.push(from)
                                                fs.writeFileSync('./src/antibadword.json', JSON.stringify(kasar))
                                                reply('Success Enable Anti virus!')
                                        } else if (argt[1] == '0') {
                                        	if (!isKasar) return reply('Fitur ini sudah di nonaktifkan')
                                            var ini = kasar.indexOf(from)
                                                kasar.splice(ini, 1)
                                                fs.writeFileSync('./src/antibadword.json', JSON.stringify(kasar))
                                                reply('Success Disable Anti virus!')
                                        } else {
                                                reply(`Ketik perintah 1 untuk mengaktifkan,0 untuk menonaktifkan\nContoh : ${prefix}antivirtext 1`)
                                        }
                                       break
                                default:
                                if (body.startsWith(`${prefix}${command}`)) {
                  reply(`Maaf *${pushname}*, Command *${prefix}${command}* Tidak Terdaftar Di Dalam *${prefix}menu*!`)
                  }
                      if (isGroup && isSimi && budy != undefined) {
                                                console.log(budy)
                                                muehe = await simih(budy)
                                                console.log(muehe)
                                                reply(muehe)
                                        } else {
                                                console.log(color('[SELF-BOT]', 'green'), 'Any Message ? ', color(sender.split('@')[0]))
                                        }
                                }
        } catch (e) {
                        console.log('Message : %s', color(e, 'green'))
                }
        })


/*
*Thanks For 𝗠𝗵𝗮𝗻𝗸𝗕𝗮𝗿𝗕𝗮𝗿
*Thanks For Nafiz
*/